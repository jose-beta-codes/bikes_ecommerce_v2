<?php

$product_name= $image= $key_features= $description= $ball_size= $condition= $price= $add_product="";
$product_name_err= $image_err= $key_features_err= $description_err= $ball_size_err= $condition_err= $price_err= $add_product_err="";
require "piccsz.php";

if(isset($_POST['submit'])){
    if(empty(trim($_POST["product_name"]))){
        $product_name_err="Please fill in the products name";
    }else{
        $product_name=trim($_POST['product_name']);
    }

    if(empty($_POST['key_features'])){
        $key_features_err="Input the product's key features";
    }else{
        $key_features=$_POST['key_features'];
    }

    if(empty($_POST['description'])){
        $description_err="Input the product description";
    }else{
        $description=$_POST['description'];
    }

    if(empty(trim($_POST['ball_size']))){
        $ball_size_err="Fill in the ball sizes available";
    }else{
        $ball_size=trim($_POST['ball_size']);
    }
   

    if(empty(trim($_POST['price']))){
        $price_err="Enter the balls price";
    }else{
        $price=trim($_POST['price']);
    }

    $condition="Brand new";
    $stock="in stock";
    $product_likes="1";
    $bike_size="N/A";
    $bike_color="N/A";


    $filename=$_FILES['image']['name'];
    $filetmp_name=$_FILES['image']['tmp_name'];
    $filesize=$_FILES['image']['size'];
    $fileerror=$_FILES['image']['error'];
    $filetype=$_FILES['image']['type'];
    if(empty($filesize)){
        $image_err="Please select the image of the product";
    }else{
        

        if( $fileerror=="0"){
            //check where the file is an image use xplode function
            $filetypecheck=explode("/",$filetype);
            if($filetypecheck[0]=="image"){
                $filename_ar=explode(".", $filename);
                $file_ext=strtolower(end($filename_ar));//ready
                // $Actual_file_ext=".".$file_ext;
                $actual_filename=preg_replace('/.'.$file_ext.'/','${1}', $filename);
                //use actual_file_name and cartinate with username(this to be the location of the file in the db -> this is the name of the file in the folder)
                //but actual file name to be in separate coloumn in the db(refer to this when displaying its name and while downloading file)
                $file_in_folder_name=uniqid().".".$actual_filename.".".$file_ext;

                $file_destination="images/".$file_in_folder_name;
                $return=move_uploaded_file($filetmp_name, $file_destination);
                if($return== true){
                    //success...indert the product
//here the file_destination is ready now
                    $file_destination_final=$file_destination;
                    echo $file_destination_final ."KABISA KABISA!!"; ///use this in the db
                    //here

                        //now ready to feeed in  the db

                    if(empty($product_name_err) && empty($image_err) && empty($key_features_err) && empty($description_err) && empty($ball_size_err) && empty($condition_err) && empty($price_err)){
                        $sql="INSERT INTO products(product_name, images, key_features, description, price, product_condition, bike_color, stock, product_likes, bike_size, ball_size) VALUES(?,?,?,?,?,?,?,?,?,?,?)";
                        if($stmt=mysqli_prepare($conn,$sql)){
                            mysqli_stmt_bind_param($stmt, "sssssssssss", $param_name, $param_images, $param_keyf, $param_descr, 
                            $param_price, $param_condition, $param_color, $param_stock, $param_productlikes, $param_bikesize, $param_ballsize);
                            $param_name=$product_name;
                            $param_images=$file_destination_final;
                            $param_keyf=$key_features;
                            $param_descr=$description;
                            $param_price=$price;
                            $param_condition=$condition;
                            $param_color=$bike_color;
                            $param_stock=$stock;
                            $param_productlikes=$product_likes;
                            $param_bikesize=$bike_size;
                            $param_ballsize=$ball_size;


                            if(mysqli_stmt_execute($stmt)){
                            $add_product="
                            <div class='alert alert-success'>
                                <strong><i class='fas fa-check'></i> Success!</strong> Ball added to the customers page
                                </div>";
                                
                            }else{
                                $add_product_err="
                                <div alert alert-danger'>
                                <strong><i class='fas fa-xmark'></i> Failed!</strong> An error occurred, try again later
                                </div>";
                            }
                            mysqli_stmt_close($stmt);
                        }

                    }



                }else{
                    $image_err="Failed to upload the image, try again later";
                }


            }else{
                $image_err="Error retrieving the selected file. please try another file";
            }
        

        }else{
            $image_err="Only image files are accepted";
        }



    }




}else{
    echo "";
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Add a ball</title>
    <style>
        .text{
            display: flex;
            justify-content: flex-start;
            font-size: small;
        }
    </style>
</head>
<body>
<?php include "admin_header.php";?>
</br>

<center>
<div class="container">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
        <legend class="text-danger" style="text-decoration:underline double;"><h2><i class="fab fa-n"></i>ew  <i class="fab fa-bimobject"></i>all <i class="fas fa-futbol"></i></h2></legend>
        <span class="text">add a ball to the shop; fill in all fields</span>
        <h5 class="text-danger"><?php echo (!empty($add_product_err)) ? $add_product_err : ''; ?></h5>
        <h5 class="text-success"><?php echo (!empty($add_product)) ? $add_product : ''; ?></h5>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($product_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $product_name; ?>" id="product_name" placeholder="Enter product name"  name="product_name">
            <label for="product_name">Product name</label>
            <span class="invalid-feedback"><?php echo $product_name_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="file" class="form-control <?php echo (!empty($image_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $image; ?>" id="file" placeholder="product image"  name="image">
            <label for="file">Product image</label>
            <span class="invalid-feedback"><?php echo $image_err; ?></span>
            </div>


        <div class="form-group mb-3 mt-3">
            <textarea rows="3" class="form-control <?php echo (!empty($key_features_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $key_features; ?>" id="key_features" placeholder="Enter key features of the product"  name="key_features"></textarea>
            <span class="invalid-feedback"><?php echo $key_features_err; ?></span>
            </div>

        <div class="form-group mb-3 mt-3">
            <textarea  rows="4"  class="form-control <?php echo (!empty($description_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $description; ?>" id="username" placeholder="Enter product description"  name="description"></textarea>
            <span class="invalid-feedback"><?php echo $description_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
        <select class="form-select <?php echo (!empty($ball_size_err)) ? 'is-invalid' : ''; ?>"  value="<?php echo $ball_size; ?>" id="username" placeholder="Enter the ball sizes available e.g 24/26/27.5/29 inch"  name="ball_size">
            <option>size 5 - senior football</option>
            <option>Size 4 - age: Under 14</option>
            <option>size 3 - age: Under 9</option>
            <option>size 2 - age: Under 5</option>
            <option>All sizes 5,4,3,2 available</option>
            </select>
            <span class="invalid-feedback"><?php echo $ball_size_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($price_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $price; ?>" id="price" placeholder="Enter price in Ksh"  name="price">
            <label for="price">Price in Ksh e.g 5,000</label>
            <span class="invalid-feedback"><?php echo $price_err; ?></span>
            </div>
         
        <input type="reset" class="btn btn-danger"  value="Reset" style="margin-right: 50px;">
        <input type="submit" class="btn btn-primary" name="submit" value="Add product " >    

    </form>

</div>



</center>
 
</br>
<?php include "footer.php"; ?>
</body>
</html>