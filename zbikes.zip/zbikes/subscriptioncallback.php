<?php
// header("Content-Type: application/json");

// $stkCallbackResponse = file_get_contents('php://input');
// $logFile = "subscriptionResponse.json";
// $log = fopen($logFile, "a");
// fwrite($log, $stkCallbackResponse);

$stkCallbackResponse='{"Body":{"stkCallback":{"MerchantRequestID":"118511-73923808-1","CheckoutRequestID":
    "ws_CO_12122022090650696703615240","ResultCode":0,"ResultDesc":"The service request is processed successfully."
    ,"CallbackMetadata":{"Item":[{"Name":"Amount","Value":1500},{"Name":"MpesaReceiptNumber","Value":"QLC1YNTEEH"},
    {"Name":"Balance"},{"Name":"TransactionDate","Value":20230313090658},{"Name":"PhoneNumber","Value":254703615240}
    ]},"TinyPesaID":"29ed7630-79e3-11ed-8504-b1ece0454f53","ExternalReference":1500,
    "Amount":1,"Msisdn":"254703615240"}}}';

    
    
$callbackContent = json_decode($stkCallbackResponse);

$ResultCode = $callbackContent->Body->stkCallback->ResultCode;
$CheckoutRequestID = $callbackContent->Body->stkCallback->CheckoutRequestID;
$Amount = $callbackContent->Body->stkCallback->CallbackMetadata->Item[0]->Value;
$Transactioncode = $callbackContent->Body->stkCallback->CallbackMetadata->Item[1]->Value;
$PhoneNumber = $callbackContent->Body->stkCallback->CallbackMetadata->Item[4]->Value;
$TransactionDate = $callbackContent->Body->stkCallback->CallbackMetadata->Item[3]->Value;
$trans_ref_months = $callbackContent->Body->stkCallback->ExternalReference;


// echo "oyah 1";


    if ($ResultCode == 0) {
        $transaction_status="completed";
        // echo "oyah 2";
        require "piccsz.php"; 

        if($Amount % 1500 == 0){
            $transaction_status="completed";
        }else{
            $transaction_status="Error";
        }


    $sql="SELECT deadline FROM subscription ORDER BY id DESC LIMIT 1;";
    if($stmt=mysqli_prepare($conn, $sql)){
        
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);

            if(mysqli_stmt_num_rows($stmt)>0){
                mysqli_stmt_bind_result($stmt, $param_deadline);
                mysqli_stmt_fetch($stmt);
                $deadline_db=$param_deadline;
                $date=date_create($deadline_db);
                $days=$trans_ref_months*30 ." days";
                $deadline_new=date_add($date, date_interval_create_from_date_string($days));
                $deadline=date_format($deadline_new, "Y-m-d");
                mysqli_stmt_close($stmt);

                $warn=date_create($deadline);
                $warning_date=date_sub($warn,date_interval_create_from_date_string("5 days"));
                $warning=date_format($warning_date,"Y-m-d");
                //now lets insert in db
                $sql="INSERT INTO subscription(transaction_code, phone_number, transaction_date, time_allocated, deadline, warning_date, amount, transaction_status) 
                VALUES(?,?,?,?,?,?,?,?)";
                 if($stmtt=mysqli_prepare($conn, $sql)){
                    mysqli_stmt_bind_param($stmtt,"ssssssss", $param_code, $param_phone, $param_date, $param_time_allo, $param_deadline, $param_warning, $param_ammount, $param_status);
                    $param_code=$Transactioncode;
                    $param_phone=$PhoneNumber;
                    $param_date=$TransactionDate;
                    $param_time_allo=$trans_ref_months;
                    $param_deadline=$deadline;
                    $param_warning=$warning;
                    $param_ammount=$Amount;
                    $param_status=$transaction_status;
    
                    if(mysqli_stmt_execute($stmtt)){
                        mysqli_stmt_close($stmtt);
    
                    }
                }

            }else{
                //insert new
                $date=date_create($TransactionDate);
                $days=$trans_ref_months*30 ." days";
                $deadline=date_add($date, date_interval_create_from_date_string($days));
                $deadline=date_format($deadline, "Y-m-d");

                $warn=date_create($deadline);
                $warning_date=date_sub($warn,date_interval_create_from_date_string("5 days"));
                $warning=date_format($warning_date,"Y-m-d");
               
                 $sql="INSERT INTO subscription(transaction_code, phone_number, transaction_date, time_allocated, deadline, warning_date, amount, transaction_status) 
            VALUES(?,?,?,?,?,?,?,?)";
             if($stmtt=mysqli_prepare($conn, $sql)){
                mysqli_stmt_bind_param($stmtt,"ssssssss", $param_code, $param_phone, $param_date, $param_time_allo, $param_deadline, $param_warning, $param_ammount, $param_status);
                $param_code=$Transactioncode;
                $param_phone=$PhoneNumber;
                $param_date=$TransactionDate;
                $param_time_allo=$trans_ref_months;
                $param_deadline=$deadline;
                $param_warning=$warning;
                $param_ammount=$Amount;
                $param_status=$transaction_status;

                if(mysqli_stmt_execute($stmtt)){
                    mysqli_stmt_close($stmtt);

            }

                
  
    }
}

}else{
   echo "error recording the transaction";
}

}
}
// fclose($log);
