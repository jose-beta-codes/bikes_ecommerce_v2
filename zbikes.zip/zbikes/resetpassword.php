<?php
require "piccsz.php";
$session_key=mysqli_real_escape_string($conn, $_GET['key']);
$password_err=$confirm_password_err=$update_feedback="";
$reset="yes";
$sql="SELECT email, expirely_date FROM password_reset WHERE reset_key=?;";
if($stmt=mysqli_prepare($conn, $sql)){
  mysqli_stmt_bind_param($stmt, "s", $param_unikey);
  $param_unikey=$session_key;
  if(mysqli_stmt_execute($stmt)){
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)>0){
      mysqli_stmt_bind_result($stmt, $param_email, $param_date_exp);
      mysqli_stmt_fetch($stmt);
      $email=$param_email;
      $date_expirely=$param_date_exp;
     
      $check_date=new DateTime($date_expirely);
      $currentt=date("Y-m-d");
      $current=new DateTime($currentt);
      if($check_date>=$current){
        $reset="yap";
      }else{
        header("location: unauthorised");
      }
        
  
    }else{
      header("location: unauthorised");
    }

  }mysqli_stmt_close($stmt);
 

}


if(isset($_POST['reset'])){
  if(strlen(trim($_POST["password"])) < 6){
    $password_err="Password has to be atleast 6 characters";

  }else{
    $password=mysqli_real_escape_string($conn, $_POST['password']);
  }
  if(!trim($_POST['confirm_password'])==$password){
    $confirm_password_err="Password didn't match";
  }else{
    $confirm_password=trim($_POST['confirm_password']);
  }

  if(empty($password_err) && empty($confirm_password_err) && $reset=="yap"){
    $sql="UPDATE customers SET passkey=? WHERE email='$email';";
    if($stmtt=mysqli_prepare($conn, $sql)){
      mysqli_stmt_bind_param($stmtt, "s", $param_pass);
      $param_pass=password_hash($password, PASSWORD_DEFAULT);
      if(mysqli_stmt_execute($stmtt)){
        $update_feedback="<div class='container' style='width:85%;'>
        <div class='alert alert-success alert-dismissible fade show'>
        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
        <strong>Success! </strong> you have reset your password.
      </div>
        </div>";
      }else{
        $update_feedback="<div class='container' style='width:85%;'>
        <div class='alert alert-danger alert-dismissible fade show'>
        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
        <strong>Error! </strong> failed to reset your password, try again later
      </div>
        </div>";
      }
      mysqli_stmt_close($stmtt);
    }

  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Reset password</title>
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
    }

  .buttons{
    display: flex;
    justify-content:space-between;
  }
</style>
</head>
<body>
<?php include "header" ?>
<center>
    <h1>
        <u class="text-success">Reset your password</u>
    </h1>
</center>
<p>finish the password reset process. Your account will be ready in a few.</p>

<diV class="flex-container">
<?php echo(!empty($update_feedback)? $update_feedback: ""); ?>
<div class="card">
      <div class="card-body" style="padding:25px;">
        <h4 class="card-title">Reset Password</h4>
        <p class="card-text text-danger">Almost done</p>
        <form method="POST" action="">
        <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="" id="username" placeholder="Enter new password"  name="password" required>
            <label for="username">Enter new password</label>
            <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>

            <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="" id="username" placeholder="Confirm your password"  name="confirm_password" required>
            <label for="username">Confirm your password</label>
            <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
            </div>
             <div class="buttons">
            <input type="reset" value="Cancel" class="btn btn-danger btn-sm"/>
            <input type="submit" name="reset" value="Apply Changes" class="btn btn-success btn-sm"/></div>
        </form>
      </div>
    </div>

</diV>


</br>
<?php include "footer.php" ?>
</body>
</html>