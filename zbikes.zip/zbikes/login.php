<?php
session_start();

if(isset($_SESSION["loggedin"]) && isset($_SESSION["id"]) && isset($_SESSION["username"])){
    header("location: indexx.php");
    exit;
}

require_once "piccsz.php";

$username = $passkey = "";
$username_err = $passkey_err = $login_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    if(empty(trim($_POST["passkey"]))){
        $passkey_err = "Please enter your password.";
    } else{
        $passkey = trim($_POST["passkey"]);
    }
    
    if(empty($username_err) && empty($passkey_err)){
        $sql = "SELECT id, username, passkey FROM customers WHERE username = ?;";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = $username;
            
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_passkey);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($passkey, $hashed_passkey)){
                            session_start();
                            
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            header("location: home");
                        } else{
                            // Passkey is not valid, display a generic error message
                            $login_err = "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($conn);
}




?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>login bicycle shop</title>
</head>
<body>
    <?php include "customer_header.php"; ?>
</br>
<div class="container">
<p>Welcome dear customer, login with your credentials below</p>
</div>
<center>
    <div class="container">
    <?php 
        if(!empty($login_err)){
            echo '<div class="alert alert-danger">' . $login_err . '</div>';
        }        
        ?>
       <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <legend class="text-danger" style="text-decoration:underline double;"><h2><i class="fas fa-l"></i>ogin</h2></legend>
        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>" id="username" placeholder="Enter username"  name="username">
            <label for="username">username</label>
            <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($passkey_err)) ? 'is-invalid' : ''; ?>"  id="security passkey" placeholder="Enter security passkey"  name="passkey">
            <label for="security passkey">Password</label>
            <span class="invalid-feedback"><?php echo $passkey_err; ?></span>
            </div>

            <p><small>Do not have an account? </small><a href="register">Register here</a></p>

            <input type="reset" class="btn btn-danger"  value="Cancel" style="margin-right: 50px;">
        <input type="submit" class="btn btn-primary" name="submit" value="Let's go">    
       </form> 
    </div>
    </br>
    <a href="forgot-password">forgot password?</a>
</center>
</br></br>
    <?php include "footer.php"; ?>
</body>
</html>
