<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintance state Zbikes Kenya</title>
    <style>
        .flex-container{
            display:flex;
            justify-content: center;
            align-items: center;
        }
    </style>
</head>
<body>
    </br> </br> </br> </br>
    <div class="flex-container">
        <h2>
            We are temporarily maintaining our services, please come back later.
        </h2>
    </div>
</body>
</html>