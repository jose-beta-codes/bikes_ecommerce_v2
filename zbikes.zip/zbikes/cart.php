<?php
session_start();
require "piccsz.php";

$cart= $cart_err= $login_err= $item_key=$delete_message="";


$sql="SELECT deadline, warning_date FROM subscription ORDER BY id DESC LIMIT 1;";
if($stmt=mysqli_prepare($conn, $sql)){
    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt)>0){
            mysqli_stmt_bind_result($stmt, $param_deadline, $param_warning);
            mysqli_stmt_fetch($stmt);
            $deadline=$param_deadline;
            $warning_date=$param_warning;
            $deadline_check=new DateTime($deadline);
            $warning_check=new DateTime($warning_date);
            $currentt=date("Y-m-d");
            $current=new DateTime($currentt);
            if($current>$deadline_check){
                header("location: error.php");
            }

        }else{
            header("location:  error.php");
        }
    }
    mysqli_stmt_close($stmt);
}


// here check whether the user is logged in or not dispaly a login form if the user is not logged in else sisplay his account details''
if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){

    $sql="SELECT cart FROM customers WHERE username = '$_SESSION[username]';";
    $result=mysqli_query($conn, $sql);
    $row=mysqli_fetch_assoc($result);
    $the_row=$row['cart'];

    if($the_row=="0"){
        //create the cart table then
        $sql="CREATE TABLE $_SESSION[username](
            id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
             name_product VARCHAR(255) NOT NULL,
            image VARCHAR(255) NOT NULL,
            unique_key VARCHAR(255) NOT NULL,
            colour VARCHAR(255) NOT NULL,
            price VARCHAR(10) NOT NULL,
            product_condition VARCHAR(20) NOT NULL,
            quantity VARCHAR(20) NOT NULL,
            key_features VARCHAR(255) NOT NULL,
            size VARCHAR(10) NOT NULL,
            product_weight VARCHAR(25) NOT NULL);";

        if(mysqli_query($conn, $sql)){
             
            $sql="UPDATE customers SET cart='1' WHERE username= '$_SESSION[username]';";
            if(mysqli_query($conn, $sql)){
                echo "";
            }else{
                echo "Error finding your cart, please try again later!";
            }
        }
 
    }

    if(isset($_SESSION['add_to_cart']) && isset($_SESSION['quantity'])){
       
        $item_key=$_SESSION['add_to_cart'];
        

        //fetch the item in debate from products

        $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products WHERE unique_key='$item_key' ORDER BY id DESC LIMIT 8;";
        $result=mysqli_query($conn, $sql);
       $rows=mysqli_num_rows($result);
      
       if($rows > 0){
            $row=mysqli_fetch_assoc($result);
               $name=$row['product_name'];
               $image=$row['images'];
               $unique_key=$row['unique_key'];
               $key_features=$row['key_features'];
               $description=$row['description'];
               $product_condition=$row['product_condition'];
               $color=$row['bike_color'];
               $price=$row['price'];
               $stock=$row['stock'];
               $size=$row['bike_size'];
               $weight=$row['product_weight'];
               $quantity=$_SESSION['quantity'];
       }

        //check whether user has a cart table
        $sql="SELECT cart FROM customers WHERE username = '$_SESSION[username]';";
        $result=mysqli_query($conn, $sql);
        $row=mysqli_fetch_assoc($result);
        $the_row=$row['cart'];

        if($the_row=="0"){
            //create the cart table then
            $sql="CREATE TABLE $_SESSION[username](
                id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
                 name_product VARCHAR(255) NOT NULL,
                image VARCHAR(255) NOT NULL,
                unique_key VARCHAR(255) NOT NULL,
                colour VARCHAR(255) NOT NULL,
                price VARCHAR(10) NOT NULL,
                product_condition VARCHAR(20) NOT NULL,
                quantity VARCHAR(20) NOT NULL,
                key_features VARCHAR(255) NOT NULL,
                size VARCHAR(10) NOT NULL,
                product_weight VARCHAR(25) NOT NULL);";

            if(mysqli_query($conn, $sql)){
                 
                $sql="UPDATE customers SET cart='1' WHERE username= '$_SESSION[username]';";
                if(mysqli_query($conn, $sql)){
                    
                        
                        //now feed the item data into his cart
                        $sql="INSERT INTO $_SESSION[username](name_product, image, unique_key, colour, price, product_condition, quantity, key_features, size, bike_weight)
                        VALUES('$name','$image','$unique_key','$color','$price','$product_condition', '$quantity', '$key_features', '$size', '$weight');
                        ";
                        if(mysqli_query($conn, $sql)){
                            $cart="<center>
                            <div class='container'>
                            <div class='alert alert-success alert-dismissible fade show'>
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong><i class='fas fa-check'></i>Success!</strong> Item added to your cart 
                        </div>
                            </div>
                        </center>";
                        }
                    }    



                }
        }else{
            

            $sql="SELECT id FROM $_SESSION[username] WHERE unique_key='$item_key';";
                $output=mysqli_query($conn, $sql);
                $row=mysqli_num_rows($output);
                if($row == "0" ){
                    //just add to his cart
                    $sql="INSERT INTO $_SESSION[username](name_product, image, unique_key, colour, price, product_condition, quantity, key_features, size, product_weight)
                    VALUES('$name','$image','$unique_key','$color','$price','$product_condition', '$quantity', '$key_features', '$size', '$weight');";

                    if(mysqli_query($conn, $sql)){
                        
                        $cart="<center>
                        <div class='container'>
                        <div class='alert alert-success alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong><i class='fas fa-check'></i>Success!</strong> Item added to your cart 
                    </div>
                        </div>
                    </center>";

                    unset($_SESSION['add_to_cart']);
                    unset($_SESSION['quantity']);
                    }else{
                        $cart_err="<center>
                        <div class='container' style='width:95% ;'>
                        <div class='alert alert-danger alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong><i class='fas fa-xmark'></i> Error!</strong> Unable to add the item to your cart, try again later!
                    </div>
                        </div>
                    </center>";
                    }

            
                }else{
                    $cart="<center>
                    <div class='container' style='width:95% ;'>
                    <div class='alert alert-success alert-dismissible fade show'>
                    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                    <strong><i class='fas fa-check'></i>Already exists!</strong> Item already in your cart
                </div>
                    </div>
                </center>";

                unset($_SESSION['add_to_cart']);
                unset($_SESSION['quantity']);
                
                }
                
            }
        }



        //cart remove

        if(isset($_POST['remove'])){
            $item_key_form=$_POST['item_key_form'];

            $sql="DELETE FROM $_SESSION[username] WHERE unique_key='$item_key_form';";
            if(mysqli_query($conn, $sql)){
                $delete_message="<center>
                <div class='container' style='width:95% ;'>
                <div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Removed!</strong> Item successifully removed from your cart
              </div>
                </div>
            </center>";
            unset($_SESSION['add_to_cart']);
                unset($_SESSION['quantity']);
            }else{
                $delete_message="<center>
                <div class='container' style='width:95% ;'>
                <div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Failed!</strong> An error occured while removing the item, try again later
              </div>
                </div>
            </center>";
    
            }
        }




        if(isset($_POST['Order_individual'])){
            $_SESSION['clicked_item_order_now_cart']=$_POST['item_key'];
            $_SESSION['clicked_item_quantity_order_now_cart']=$_POST['quantity'];
            $_SESSION['page']="2";
            header("location: order-now");
        }



}else{
    $login_err= "<center>
    <div class='container' style='width:95% ;'>
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login! <i class='fas fa-cart-arrow-down'></i></strong> login here see your cart contents  <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
    </div>
</center>";
}






?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>my cart bike shop Kenya Mombasa</title>

    <style>
    .flex-container {
  display: flex;
  flex-direction: column;
margin-left: 8px;
margin-right: 8px;
  justify-content: center;
  align-items: center;
}

.flex-box{
    display: flex;
  justify-content: space-around;
}

    </style>

</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Offcanvas navbar large">
        <div class="container-fluid">

        <a class="navbar-brand">
            <img src="logo.jpg" alt="Logo" style="width:50px;" class="rounded-pill">
        </a>

        <span class="text-light " style="font-weight: bold;"><i class="fas fa-bicycle"></i> Bicycle shop</span>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="offcanvas offcanvas-end text-white bg-dark" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
            <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Bicycle shop <i class="fas fa-bicycle"></i></h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="home"> <button class="btn btn-outline-primary"><i class="fas fa-house-user"></i> Home</button></a>
                </li>
                <li class="nav-item">
                <a class="nav-link " href="cart"><button type="button" class="btn  btn-primary"  data-bs-toggle="tooltip" title="Programming career and projects" style="text-decoration: underline double red;"> <i class="fas fa-cart-arrow-down"></i> My Cart</button></a>
                </li>

                <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="orders"> <button class="btn btn-outline-danger"><i class="fas fa-truck-fast"></i> My Orders</button></a>
                </li>

               
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="offcanvasNavbarLgDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                    <button class="btn btn-danger"> <i class="fas fa-bars"></i> Menu</button>
                </a>
                <ul class="dropdown-menu" aria-labelledby="offcanvasNavbarLgDropdown" style="background-image:linear-gradient(to bottom, dodgerblue , grey);">
                <li><a href="account"  style="text-decoration:none ;"><button style="border:none;" type="button"  data-bs-toggle="modal" data-bs-target="#mylife" class="dropdown-item btn" ><i class="fas fa-user"></i> My account</button></a></li>
                <li><a href="https://maps.app.goo.gl/3NTeE3XcAgUJQo3BA" style="text-decoration: none;"><button style="border:none;" type="button"  data-bs-toggle="modal" data-bs-target="#mylife" class="dropdown-item btn" ><i class="fas fa-map-location-dot"></i> Shop location and directions</button></a></li>
                    <!-- <li><button type="button" data-bs-toggle="modal" data-bs-target="#education" class="dropdown-item btn">Contacts</button></li> -->
                    <li><a href="happy_customers" style="text-decoration: none;"><button type="button" class="dropdown-item"><i class="fas fa-circle-check"></i> Happy customers</button></a></li>

                    <li>
                    <hr class="dropdown-divider">
                    </li>
                    <li><a href="notifications_and_offers" style="text-decoration: none;"><button  class="dropdown-item btn" ><i class="fas fa-star-half" style="color:orange;"></i>Offers and notifications</button></a></li>
                    <li><a href="about"  style="text-decoration:none ;"><button type="button"  class="dropdown-item btn" >About Us</button></a></li>
                    <li><button type="button" data-bs-toggle="modal" data-bs-target="#contact" class="dropdown-item btn" >Contact</button></li>
                    <?php echo (isset($_SESSION["username"])? "<li><form method='post' action='logout'><button type='submit' name='logout'data-bs-toggle='modal' data-bs-target='contact' class='dropdown-item btn' ><i class='fas fa-door-open'></i> Logout</button></form></li>": ""); ?>
                </ul>
                </li>
            </ul>
            </div>
        </div>
        </div>
    </nav>

<center>
    <div class="container">
        <h2 style="text-decoration:underline double ; color: orange;"><b>My Cart</b></h2>
        <p><?php echo(isset($cart)? $cart: ""); ?></p>
        <p><?php echo(isset($cart_err)? $cart_err: ""); ?></p>
        <p><?php echo(isset($login_err)? $login_err: ""); ?></p>
        <p><?php echo(isset($delete_message)? $delete_message: ""); ?></p>
    </div>
</center>
<p>Riding is fun and healthy</p>
<div class="container">
   

<?php

if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
    $subtotal=0;
    //check all items in the cart
    $sql="SELECT name_product, image, unique_key, colour, price, product_condition, quantity, key_features, size, product_weight FROM  $_SESSION[username];";
    $result=mysqli_query($conn, $sql);
    $rows=mysqli_num_rows($result);
    if($rows > 0){
        for($i=0;$i<$rows;$i++){
            $data=mysqli_fetch_assoc($result);
            $name_product=$data['name_product'];
            $image=$data['image'];
            $unique_key=$data['unique_key'];
            $color=$data['colour'];
            $price=$data['price'];
            $condition=$data['product_condition'];
            $quantity=$data['quantity'];
            $key_features=$data['key_features'];
            $size=$data['size'];
            $weight=$data['product_weight'];


            
            $price_int=explode(",",$price);
            $price2=(isset($price_int[1])? $price_int[1]: "");
            $price3=(isset($price_int[2])? $price_int[2]: "");
            $price_all= $price_int[0].$price2.$price3;
            $total_item_cost=(int)$price_all*(int)$quantity;
            $subtotal=$subtotal+$total_item_cost;
            $total_item_cost_display=number_format($total_item_cost);
            $subtotal_display=number_format($subtotal);

            $keyf=explode("##", $key_features);
            $count=count($keyf);
            $key1=($count>0? $keyf[0]." ": "");
            $key2=($count>1? $keyf[1]." ": "");
            $key3=($count>2? $keyf[2]." ": "");
            $key4=($count>3? $keyf[3]." ": "");
            $allkeyf=$key1.$key2.$key3.$key4;


            echo "<div class='flex-container'>
            <div class='card' style='max-width: 600px;'>
            <div class='row g-0'>
                <div class='col-5'>
                    <img src='$image' class='card-img-top h-100' alt='bike image kenya Mombasa' style='object-fit:fill;'>
                </div>
                <div class='col-7' style='background: #868e9630;'>
                    <div class='card-body'>
                        <h5 class='card-title' style='margin:0;padding:0;'>$name_product</h5>
                        <small style='text-decoration: underline;'>Key features</small>
                        <p class='card-text ' style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis; font-size:x-small; margin:0 ;padding:0;'>$allkeyf </p>
                        <p style='font-size:x-small; margin:0 ;padding:0;'><b>Color: </b>$color  
                        <b>  Condition: </b>$condition</p>
                        <p style='font-size:x-small; margin:0 ;padding:0;'><b>Size: </b>$size inches 
                        <b>  Weight(kg): </b> $weight</p>
                        <p style='font-size:x-small; margin:0 ;padding:0;'><b>no. of pieces:  </b>$quantity  
                        <b>  Product cost &times1: </b>$price</p>
                        <small style='font-size:x-small;'><b>Total Cost: </b><span style='text-decoration:underline;'>$total_item_cost_display</span></small></br>

                      <div class='flex-box'>
                      <div>
                      <form method='POST' action=''>
                        <input type='hidden' name='item_key_form' value='$unique_key'>
                        <button type='submit' name='remove' class='btn btn-danger btn-sm'><small style='font-size:x-small;'>Remove from cart</small></button>
                      </form>
                        </div>

                        <div>
                          <form method='POST' action=''>
                          <input type='hidden' name='item_key' value='$unique_key'/>
                          <input type='hidden' name='quantity' value='$quantity'/>
                            <button type='submit' name='Order_individual' class='btn btn-primary btn-sm'><small style='font-size:x-small;'>Order now</small></button>
                        </form>
                        </div>
                    </div>

                    </div>
                </div>
            </div>
        </div></div></br>";

        
        }







    }else{
        echo "<center>
        <div class='container'>
        <div class='alert alert-primary alert-dismissible fade show'>
        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
        <strong>Nothing yet! <i class='fas fa-cart-arrow-down'></i></strong> Your cart is empty, go to home page and select items to add to your cart.
    </div>
        </div>
    </center>";
    }

}

?>


</div>

<?php
if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
    if($rows > 0){
   
   
   
   
    echo "<div class='container-fluid' style='background-image:linear-gradient(to right, dodgerblue , grey);'>
 
    <center>
        <p style='padding-top:5px;'><b class='text-dark'>Total items <small>(in your cart)</small>: </b><span style='background-color: white; width:fit-content; padding-left: 5px;padding-right:5px;'>$rows</span></p>
        <p style=' padding-top:5px;'><b class='text-dark'>Total items Cost: </b><span style='background-color: white; width:fit-content; padding-left: 5px;padding-right:5px; text-decoration: underline double;'> $subtotal_display Ksh</span></p>
            <button name='checkout' data-bs-toggle='modal' data-bs-target='#check_out' class='btn btn-success '><b>Check out</b></button></br>
</br>
    </center>

</div>";
    }

}
?>

<div class="modal" id="check_out">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title"><b class="text-primary">Check Out</b></h4>
        
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <center>
        <p>Hello Dear customer, For orders involving more than one type of product call us directly for best discounts and other services</p>
              <a href="tel:0717734372" class="text-primary"><b><i class="fas fa-phone-volume"></i><span> Call us on 0717734372</span></b></a></br></br>
        </center>
      </div>

    </div>
  </div>
</div> 



<div class="modal" id="contact">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Contact Us</h4>
        
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <center>
        <b>You can reach us through the following contacts</br>call us: <u>0717734372</u></b>
</br><small>use this links to see our social media </small><h1>&#128578</h1>

              <a  href="https://www.instagram.com/invites/contact/?i=zwvi3q5xee6j&utm_content=nr51ctr" ><b><i class="fab fa-instagram" style="color:rgba(245, 34, 118, 0.67);""></i><span style="color:rgba(245, 34, 118, 0.67);"> Instagram</span></b></a></br>
              <a  href="https://m.facebook.com/story.php?story_fbid=pfbid02aAzTopvwhrQVxJcdih7cLLko9GtyfG4Gqcm9iS2xLtcMCvJ3Qsw3sfWELmrnZBWAl&id=100075273326784"><b><i class="fab fa-facebook text-primary"></i><span style="color:dodgerblue"> Facebook</span></b></a></br>
              <a href="https://wa.me/+254717734372?text=Hello%20ZBIKESS%20i%20saw%20this%20on%20your%20site," class=""><b><i class="fab fa-whatsapp text-success"></i><span class="text-success"> Whatsapp</span></b></a></br>
              <a href="tel:0717734372" class="text-primary"><b><i class="fas fa-phone-volume"></i><span> Call us</span></b></a></br>
        </center>
      </div>

    </div>
  </div>
</div>

</br>
<?php include "footer.php" ?>
</body>
</html>