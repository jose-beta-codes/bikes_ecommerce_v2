<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>unauthorised access</title>
    <style>
        .flex-container{
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 20%;
            
        }
    </style>
</head>
<body>
    <div class="flex-container">
        <h1>unauthorised access !</h1>
    </div>
</body>
</html>