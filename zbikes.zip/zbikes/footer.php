<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Bicycle shop footer</title>
    <style>
        .flex-footer-container{
            display: flex;
            justify-content:space-evenly ;
            border-radius: 20px;
            /* border-color: wheat; */
            border-style: inset;
            flex-direction: row;
        }
        .flex-footer-container >div >div {
            align-items: center;
        }
        @media (max-width: 480px){
            .flex-footer-container{
                flex-direction: column;
            }
        }
        .flex-footer-items{
            display: flex;
            justify-content: space-between;
            flex-direction: row;
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container-fluid bg-dark" >
        <div class="text-light" style="padding-bottom:3px ;">
        
        <center>
            <p>Our social media</p>
              <div class="flex-footer-container">
                <div class="flex-footer-items">
              <div style="margin-right:15px;"><a href="tel:0717734372" class=""><b><i class="fas fa-phone-volume"></i><span style="color:white;"> Call us</span></b></a></div>
              <div><a  href="https://www.instagram.com/invites/contact/?i=zwvi3q5xee6j&utm_content=nr51ctr" ><b><i class="fab fa-instagram" style="color:rgba(245, 34, 118, 0.67);"></i><span style="color:rgba(245, 34, 118, 0.67);"> Instagram</span></b></a></div>
              </div>
              <div class="flex-footer-items">
              <div style="margin-right:15px;"><a  href="https://m.facebook.com/story.php?story_fbid=pfbid02aAzTopvwhrQVxJcdih7cLLko9GtyfG4Gqcm9iS2xLtcMCvJ3Qsw3sfWELmrnZBWAl&id=100075273326784"><b><i class="fab fa-facebook text-primary"></i><span style="color:dodgerblue"> Facebook</span></b></a></div>
              <div><a href="https://wa.me/254717734372?text=Hello%20ZBIKESS%20i%20saw%20this%20on%20your%20site," class=""><b><i class="fab fa-whatsapp text-success"></i><span class="text-success"> Whatsapp</span></b></a></div>
              </div>
              </div>
              </center></br>
        <p>Bikes for everyone, riding is both fun and healthy! <b>@ZBIKES KENYA</b></p>
        <p>Website built by <b class="text-success">Fahari Codes org.</b> <a  href="mailto:josephmwangi2w@gmail.com?subject=Fahari codes services" class="primary">email developer</a></p>
        <center><p>&copy; <?php echo date("Y"); ?> copyright privacy policy reserved</p></center>
        </div>    
    </div>
    </div>
</body>
</html>