<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE pre_orders(
    id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    customer_location VARCHAR(50) NOT NULL,
    customer_id VARCHAR(255) NOT NULL,
    pre_order_key VARCHAR(255) NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    quantity VARCHAR(5) NOT NULL,
    product_key VARCHAR(255) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes pre-orders successifully created!";
}
else{
    die ("Error creating table bana! ");
}