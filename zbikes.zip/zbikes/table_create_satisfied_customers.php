<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE satisfied_customers(
    id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
   customer_image VARCHAR(255) NOT NULL,
    remarks VARCHAR(255) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes satisfied customers successifully created!";
}
else{
    die ("Error creating table bana! ");
}