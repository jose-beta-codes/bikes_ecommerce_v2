<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE subscription(
    id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
   transaction_code VARCHAR(255) NOT NULL,
   phone_number VARCHAR(15) NOT NULL,
   transaction_date VARCHAR(16) NOT NULL,
   time_allocated INT(3) NOT NULL,
   deadline VARCHAR(16) NOT NULL,
   warning_date VARCHAR(16) NOT NULL,
   amount VARCHAR(20) NOT NULL,
   transaction_status VARCHAR(12) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes subscription successifully created!";
}
else{
    die ("Error creating table bana! ");
}