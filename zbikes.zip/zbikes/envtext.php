<?php

require_once realpath(__DIR__. "/envvendor/autoload.php");
use Dotenv\Dotenv;
$dotenv=Dotenv::createImmutable(__DIR__);
$dotenv->load();
