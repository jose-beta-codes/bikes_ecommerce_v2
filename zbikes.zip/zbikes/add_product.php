<?php
session_start();
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: admin_login");
        exit;
    }


}else{
    header("location:  admin_login");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>add a product advert</title>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Offcanvas navbar large">
        <div class="container-fluid">

        <a class="navbar-brand" href="logo.jpg">
            <img src="logo.jpg" alt="Logo" style="width:50px;" class="rounded-pill">
        </a>

        <span class="text-danger " style="font-weight: bold;"> Administrator mode <i class="fas fa-gears"></i></span>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="offcanvas offcanvas-end text-white bg-dark" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
            <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Bicycle shop <i class="fas fa-bicycle"></i></h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="administrator"> <button class="btn btn-outline-primary" ><i class="fas fa-house-user"></i> Home page</button></a>
                </li>
                <li class="nav-item">
                <a class="nav-link " href="product_add"><button type="button" class="btn  btn-primary"  data-bs-toggle="tooltip" style="text-decoration:underline double Red"> <i class="fas fa-plus"></i> Add Product</button></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="customer_orders"><button type="button" class="btn  btn-outline-danger"  data-bs-toggle="tooltip"> <i class="fas fa-cart-arrow-down"></i> Orders</button></a>
                    </li>
               
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="offcanvasNavbarLgDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                    <button class="btn btn-danger"> <i class="fas fa-bars"></i> More Options </button>
                </a>
                <ul class="dropdown-menu bg-primary" aria-labelledby="offcanvasNavbarLgDropdown" style="background-image:linear-gradient(to bottom, dodgerblue , grey);">
                <li><a href="stock_manager" style="text-decoration: none;"><button style="border:none;" type="button"  class="dropdown-item btn" > Stock Manager</button></a></li>
                <li><a href="send_notification" style="text-decoration: none;"><button style="border:none;" type="button"   class="dropdown-item btn" > Send Notifications</button></a></li>
                    
                    <li><a href="satisfied_clients" style="text-decoration: none;"><button type="button"  class="dropdown-item">Add Happy customer</button></a></li>
                    <li><a href="customer_accounts" style="text-decoration: none;"><button type="button"  class="dropdown-item btn" >Customer Accounts</button></a></li>
                    <!-- <li><button type="button"  class="dropdown-item btn">Customer Messages</button></li> -->
                    <li><a href="home" style="text-decoration: none;"><button type="button"  class="dropdown-item">Go to Customer mode</button></a></li>

                    <li>
                    <hr class="dropdown-divider">
                    </li>
                    <!-- <li><a href="subscription.php" style="text-decoration: none;"><button type="button"  class="dropdown-item btn">My Subscription</button></a></li> -->
                    <li><form method="POST" action=""><button type="submit" name="exit" class="dropdown-item"><i class="fas fa-door-open "></i>Exit admin mode</button></form></li>
                    <li><a href="user_guide" style="text-decoration: none;"><button type="button"  class="dropdown-item btn">User Guide <i class="fas fa-book-open-reader"></i></button></a></li>
                </ul>
                </li>
            </ul>
            </div>
        </div>
        </div>
    </nav>
</br>
<div class="container-fluid">
    <p>Welcome back, This page allows you to add a product advert where it will be viewed by customers visiting this site in customer mode. </p>
    <!-- <p><b>NOTE: be sure to fill in all the spaces to avoid missing info. in the product advert.</b> </p> -->
    
</div>


<div class="container">
    <h4><b>Select the type of product you want to add <i class="fas fa-plus"></i>;</b></h4>

    <!-- cards....for bikes, balls, add product configaration  -->
    <div class="row gy-3 ">
        <div class="col-12 col-md-6 col-lg-4 ">
            <div class="box h-100 d-flex flex-column rounded border border-grey " >
                <img src="logo.jpg" alt="Mtb logo" class="card-img-top">
                <div class="p-2">
                    <h4 class="card-title">Bikes</h4>
                    <p class="card-text">
                       This section contains a form about bicycle features and it allows adding of new bike to the customers face page.
                       <p>Click <span class="text-danger">continue</span> to Add a bike</p>
                    <a href="bikes"><button class="btn btn-primary">Continue</button></a>
                    </p>
                </div>
                    

                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-4 ">
                <div class="box h-100 d-flex flex-column rounded border border-grey" >
                    <img src="add-ball.jpg" alt="ball" class="card-img-top">
                    <div class="p-2">
                        <h4 class="card-title">Balls</h4>
                        <p class="card-text">
                           This section contains a form about balls features and it allows you to add them in the customers page.
                           <p>Click <span class="text-primary">continue</span> to Add a ball</p>
                        
                           <a href="ball"><button class="btn btn-danger">Continue</button></a>
                        </p>
                    </div>
    
                       
    
                    </div>
    </div>

    <div class="col-12 col-md-6 col-lg-4 ">
        <div class="card" >
            
            <div class="card-body ">
                <!-- <h4 class="card-title">New product configaration</h4> -->
                <p class="card-text">
                    <button class="btn btn-secondary" disabled><h2><i class="fas fa-plus"></i>Add new product configarations</h2></button>
                   Add new configaration of a product's features to be able to add products of that configaration.
                <p> Click on <span class="text-danger">next </span>to add new product configarations</p>
                   
                    <button type="submit"  name="add_configaration" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#configaration" style='background-image:linear-gradient(to left, dodgerblue , grey);'>Next</button>
                   
                </p>

                </div>

            </div>
</div>

</div>
</div>


<div class="modal" id="configaration">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">New product configaration</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        Kindly contact the developer for new product configarations via email;
        <center>
        <a href="mailto:josephmwangi2w@gmail.com?subject=Welcome to Fahari-beta code org.where we make your dream a reality. Let's grow together.">
                    <button class="btn btn-success"><i class="fas fa-envelope"></i> Email Here</button></a>
        </center>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>























</br>
    <?php  include "footer.php";?>
</body>
</html>