<?php
session_start();
require "piccsz.php";
$login_err= $orders_message="";

if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: admin_login");
        exit;
    }

    if(isset($_POST['order_completed'])){
        $item_keyy=$_POST['item_key'];
        $sql="UPDATE orders SET order_status='0' WHERE item_key='$item_keyy';";
        if(mysqli_query($conn,$sql)){
            $orders_message="<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-success alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong><i class='fas fa-check'></i>Success!</strong> order successifully reverted to new order. 
        </div>
            </div>
        </center>";
        }
    }
    
  
  
  }else{
    header("location:  admin_login");
  }





?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Complete orders bicycle shop KENYA</title>
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;
margin-left: 8px;
margin-right: 8px;
  justify-content: center;
  align-items: center;
}

.flex-box{
    display: flex;
  justify-content: center;
}

    </style>
</head>
<body>
    <?php include "admin_header.php" ?>
</br>
    <center>
    <div class="container">
        <h2 class="text-success"><u><i class="fas fa-circle-check"></i> Complete Orders</i></u></h2>
    </div>
    </center>

    <div class="container">
        <p>All the orders that are complete (i.e item already sent and received by client) will appear here . you can reverse their state back to new order when needed</p>
    </div>

    <div class="container">
        <?php
        if(isset($_SESSION["loggedinadmn"]) && !empty($_SESSION["idadmn"])){
            $sql="SELECT product_name, customer_id, customer_name, customer_location, quantity, amount, transaction_code, transaction_date, phone_no, item_key, transaction_status FROM orders WHERE order_status='1';";
            $result=mysqli_query($conn, $sql);
            $rows=mysqli_num_rows($result);
       
            if($rows > 0){
                for($i=0; $i<$rows; $i++){
                    $row=mysqli_fetch_assoc($result);
                    $name=$row['product_name'];
                    $customer_id=$row['customer_id'];
                    $customer_name=$row['customer_name'];
                    $customer_location=$row['customer_location'];
                    $quantity=$row['quantity'];
                    $amount=$row['amount'];
                    $transaction_code=$row['transaction_code'];
                    $transaction_date=$row['transaction_date'];
                    $phone_no=$row['phone_no'];
                    $item_key=$row['item_key'];
                    $transaction_status=$row['transaction_status'];

                    $sqll="SELECT  images, bike_color, product_condition, key_features, bike_size, product_weight FROM  products WHERE unique_key='$item_key';";
                    $resultz=mysqli_query($conn, $sqll);
                    $rowz=mysqli_num_rows($resultz);
                    if($rowz > 0){
                            $data=mysqli_fetch_assoc($resultz);
                            $image=$data['images'];
                            $color=$data['bike_color'];
                            $condition=$data['product_condition'];
                            $key_features=$data['key_features'];
                            $size=$data['bike_size'];
                            $weight=$data['product_weight'];
                
                            $keyf=explode("##", $key_features);
                            $count=count($keyf);
                            $key1=($count>0? $keyf[0]." ": "");
                            $key2=($count>1? $keyf[1]." ": "");
                            $key3=($count>2? $keyf[2]." ": "");
                            $key4=($count>3? $keyf[3]." ": "");
                            $allkeyf=$key1.$key2.$key3.$key4;

                            $trans_date=date_create($transaction_date);
                            $transaction_date=date_format($trans_date,"Y/m/d H:i:s");

                    echo "<div class='flex-container'>
                    <div class='card' style='max-width: 600px;'>
                    <div class='row g-0'>
                        <div class='col-5'>
                            <img src='$image' class='card-img-top h-100' alt='bike image kenya Mombasa' style='object-fit:fill;'>
                        </div>
                        <div class='col-7' style='background: #868e9675;'>
                            <div class='card-body'>
                                <h5 class='card-title' style='margin:0;padding:0;'>Customer name: <b>$customer_name</b></h5>
                                <p style='text-decoration:underline;margin:0;padding:0;'><b>Order Details</b></p>
                                <p style='margin:0;padding:0;'><small><b>Item ordered: </b><u>$name</u></small></p>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>Color: </b>$color  
                                <b>  Condition: </b>$condition</p>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>Size: </b>$size inches 
                                <b>  Weight(kg): </b> $weight</p>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>no. of pieces:  </b>$quantity  
                                <b>Product ID: </b>$item_key</p>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>Transaction Code: </b>$transaction_code 
                                <b>Amount paid: </b>$amount</p>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>Transaction Date: </b>$transaction_date</p>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>Payment status: </b><span class='bg-success p-1 rounded-pill text-light'><i class='fas fa-circle-check'></i> $transaction_status </span></p>
                                </hr>
                                <p style='font-size:small; margin:0 ;padding:0;'><b>Customer Location: </b>$customer_location
                                <b>Customer phone number: </b><u>$phone_no</u></p>
                            <div class='flex-box'>
                                <div>
                                <form method='POST' action=''>
                                <input type='hidden' name='item_key' value='$item_key'/>
                                <button type='submit' name='order_completed' class='btn btn-danger btn-sm' ><small>Reverse to new order</small></button>
                                </form>
                                </div>
                            </div>

                            </div>
                        </div>
                    </div>
                    </div></div></br>";



                    }else{
                        $orders_message= "<center>
                        <div class='container' style='width:70% ;'>
                        <div class='alert alert-danger alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong>Item Not Found!</strong> The product with the specified key was not found, there must be an error with the key 
                      </div>
                        </div>
                    </center>";
                    }

                }
            }else{
                $orders_message= "<center>
                <div class='container' style='width:70% ;'>
                <div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>No complete orders found!</strong> There are no complete orders at the moment.
              </div>
                </div>
            </center>";

            }


        }else{
            $login_err= "<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Login!</strong> to access this page you must be logged in  <a href='admin entry.php' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
          </div>
            </div>
        </center>";
        }


?>
<div class="container">
    <?php echo(!empty($login_err)? $login_err: ""); ?>
    <?php echo(!empty($orders_message)? $orders_message: ""); ?>
</div>

    </div>


    <?php include "footer.php" ?>
</body>
</html>