<?php
session_start();
require "piccsz.php";
$delete_message="";
if(isset($_POST['delete_remark'])){
$remark_id=$_POST['id'];

$sql="DELETE FROM satisfied_customers WHERE id='$remark_id';";
$results=mysqli_query($conn, $sql);
    if($results){

        $delete_message="<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Deleted!</strong> removed the remark permanently
          </div>
            </div>
        </center>";
        }else{
            $delete_message="<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Failed!</strong> An error occured while deleting the remark, try again later
          </div>
            </div>
        </center>";
        }
    }

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Happy customers bicycle shop kenya </title>
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
}

    </style>
</head>
<body>
    <?php include "admin_header.php"; ?>

<center>
    <div class="container">
        <h2 class="text-danger"><u><i class="fas fa-wrench"></i> Edit Satisfied Customers</u></h2>
    </div>
</center>
<div class="container">
    <?php echo(!empty($delete_message)? $delete_message: ''); ?>
</div>
<div class="container" style="font-size: small;">
    <p>The data below is one that you entered at happy customers page, you can delete a post(s) if needed</p>
    <p class="bg-warning"><strong>WARNING:</strong> action performed on data in this page is irreversible, if you accidentally delete a post you will have to re-add it again at happy customer page.</p>
</div>

<div class="container">
    <a href="satisfied_clients"><button class="btn btn-primary btn-sm">Happy customer page</button></a>
</div>
<div class="flex-container">
    

    <!-- get the data -->
    <?php
    $sql="SELECT id, customer_image, remarks FROM satisfied_customers ORDER BY id DESC;";
    $result=mysqli_query($conn, $sql);
    $rows=mysqli_num_rows($result);
    if($rows>0){
        for($i=0; $i<$rows; $i++){
            $row=mysqli_fetch_assoc($result);
            $id=$row['id'];
            $customer_image=$row['customer_image'];
            $remarks=$row['remarks'];

            echo "<div class='card' style='max-width: 500px;'>
                    <div class='row g-0'>
                        <div class='col-5' style='background: #868e96;'>
                            <img src='$customer_image' class='card-img-top h-100' alt='customer photo'>
                        </div>
                        <div class='col-7'>
                            <div class='card-body'>
                                <small class='card-text'>$remarks</small>
                                <p class='text-muted' style='font-size:x-small;'>It was an honour doing business with you</p>
                              <form action='' method='POST'>
                                <input type='hidden' name='id' value='$id'/>
                                <input type='submit' name='delete_remark' class='btn btn-danger btn-sm' value='Delete'/>
                              </form>
                               
                            </div>
                        </div>
                    </div>
                </div> <br>";
        }
        
    }else{
        echo "<div class='alert alert-primary alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>No data yet!</strong> Oops! we could not find any information on this page, come back later.
                </div>";
    }


?>

</div>



</br>
<?php include "footer.php"; ?>
    
</body>
</html>