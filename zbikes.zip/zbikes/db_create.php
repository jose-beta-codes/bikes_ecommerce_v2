<?php
$servername="localhost";
$dbusername="root";
$dbpassword="";

$conn=mysqli_connect($servername, $dbusername, $dbpassword);
$sql="CREATE DATABASE Zbikes;";
if(mysqli_query($conn,$sql)){
    echo("Successifully created the Zbikes db");
}

else{
    die ("Unknown error bana");
}

?>