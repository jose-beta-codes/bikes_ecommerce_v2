<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE products(
    id INT(25) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    product_name VARCHAR(25) NOT NULL,
    images VARCHAR(255) NOT NULL,
    unique_key VARCHAR(255) NOT NULL,
    key_features TEXT NOT NULL,
    description LONGTEXT NOT NULL,
    price TEXT NOT NULL,
    product_condition VARCHAR(25) NOT NULL,
    bike_color VARCHAR(25) NOT NULL,
    stock VARCHAR(25) NOT NULL,
    product_likes INT(255) NOT NULL,
    bike_size VARCHAR(25) NOT NULL,
    ball_size VARCHAR(25) NOT NULL,
    product_weight VARCHAR(25) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes products successifully created!";
}
else{
    echo "Error creating table bana! ";
}