<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>About bicycle shop KENYA</title>
</head>
<body>
    <?php include "customer_header.php" ?>
</br>
<center>
<div class="container">
    <h2 style="color:orange;text-decoration:underline;"><b>About Zbikes <i class="fas fa-bicycle" style="color:orange;"></i></b></h2>
</div>
</center>
<p>Welcome to our Bicycle shop, </p>

<div class="container">
        <div class="row gy-3">


        <div class="col-lg-3 col-md-3 col-12">
            <div class="box h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
              <!-- <img src="..\zbikess\pics\zbikess.ke-20220811-0077.jpg" alt="image test" > -->
              <h4 class="text-danger"><u>Summary</u></h4>
              <ul>
              <li>This is a <b>bicycle shop</b>, we deal with bikes of all sorts: <b>Mountain bikes, BMX bikes, kids bikes, Road bikes.</b></li>
              <li>New and second hand bikes are available.We are proud to have a good reputation of selling quality bikes and accessories to our customers.</li>
              <li>Delivery country wide is available.</li>
              <li>Riding is fun and healthy!</li>
              </ul>
                <a href="index.php" class="btn btn-danger rounded-pill mt-auto">See satisfied customers</a>

            </div>
          </div>
          
          <div class="col-lg-3 col-md-3 col-12">
            <div class="box h-100 d-flex p-3 flex-column rounded bg-warning">
              <h4 >Our Location <i class="fas fa-map-location-dot"></i></h4>
              <p>We are located at <b>Mombasa along hospital street , opposite Pentaloon</b></p>

              <p>We arrange a delivery to our clients country wide</p>
              <p>Reach to us for more info: Whatsapp or call ->Tel:0717734372</p>
                
                
                 
              <a href="index.php" class="btn btn-primary rounded-pill mt-auto">See location on map</a>
            

            </div>
          </div>

          

    

          <div class="col-lg-3 col-md-3 col-12">
            <div class="box  h-100 d-flex p-3 flex-column rounded" style='background-image:linear-gradient(to right, rgba(30, 143, 255, 0.569) , rgba(128, 128, 128, 0.549));'>
              <h4>Social media</h4>
              <p>follow us on our official social media platforms;</p>
              <center>
              <div style="border-style:inset; border-color:wheat; border-radius:30px;">
              <a href="tel:0717734372" class=""><b><i class="fas fa-phone-volume"></i><span style="color:white;"> Call us</span></b></a></br></br>
              <a  href="https://www.instagram.com/invites/contact/?i=zwvi3q5xee6j&utm_content=nr51ctr" ><b><i class="fab fa-instagram" style="color:rgba(245, 34, 118, 0.67);"></i><span style="color:rgba(245, 34, 118, 0.67);"> Instagram</span></b></a></br></br>
              <a  href="https://m.facebook.com/story.php?story_fbid=pfbid02aAzTopvwhrQVxJcdih7cLLko9GtyfG4Gqcm9iS2xLtcMCvJ3Qsw3sfWELmrnZBWAl&id=100075273326784"><b><i class="fab fa-facebook text-primary"></i><span style="color:dodgerblue"> Facebook</span></b></a></br></br>
              <a href="https://wa.me/+254717734372?text=Hello%20ZBIKESS%20i%20saw%20this%20on%20your%20site," class=""><b><i class="fab fa-whatsapp text-success"></i><span class="text-success"> Whatsapp</span></b></a></br></br>
              </div>
              </center>
</br>
              <a href="index.php" class="btn btn-primary rounded-pill mt-auto">Home</a>
               

            </div>
          </div>

          <div class="col-lg-3 col-md-3 col-12">
            <div class="box  h-100 d-flex p-3 flex-column rounded" style="background-image:linear-gradient(to right, rgba(255, 166, 0, 0.624), rgba(30, 143, 255, 0.618));">
              <h4>About this site</h4>
              <p>This website was designed and developed by <a href="" class="text-danger">Fahari-beta code org.</a> to help our
               customers have an easier way to see and explore the wide variety of bikes that we have in stock, 
               order and also get quality bike accessories easily.</p>
               <p>Want a website like this one? reach out the developer by clicking button below <i class="fas fa-code text-danger"></i></p>
                <a href="#" class="btn btn-danger rounded-pill mt-auto">Developer</a>

            </div>
          </div>

        </div>
    </div>



</br>
    <?php include "footer.php" ?>
    
</body>
</html>