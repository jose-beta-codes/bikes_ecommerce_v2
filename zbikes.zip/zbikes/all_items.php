
<?php
session_start();
require "piccsz.php";
$delete_message="";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){


    if(isset($_POST['remove_item'])){
        //delete item
        $item_key=$_POST['item_key'];

        $sql="DELETE FROM products WHERE unique_key='$item_key';";
        if(mysqli_query($conn, $sql)){
            $delete_message="<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Deleted!</strong> Item successifully removed from the shop
          </div>
            </div>
        </center>";
        }else{
            $delete_message="<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Failed!</strong> An error occured while deleting the item, try again later
          </div>
            </div>
        </center>";

        }
    }

}



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="../bootstrap/css/all.css">
    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <title>All items bicycle shop KE</title>

    <style>
    .flex-container {
  display: flex;
  flex-direction: column;
margin-left: 8px;
margin-right: 8px;
  justify-content: center;
  align-items: center;
}


    </style>

</head>
<body>
<?php include "admin_header.php" ?>
<center>
<div class="container">
        <h2><u><b>All items in e-shop</b></u></h2>
    </div>
</center>
<div class="container">
    <?php echo(!empty($delete_message)? $delete_message : ''); ?>
</div>
<?php 
$sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size FROM products ORDER BY id DESC;";
$result=mysqli_query($conn, $sql);
$rows_total=mysqli_num_rows($result);

?>
<p>These are all the total items you have feed in the e-shop: </p>
<p><b>sorted as: </b><small>the last item you added will appear first, (NEWEST FIRST) <b class="bg-success p-1 rounded">Total items: <?php echo(isset($rows_total)? $rows_total: '' ); ?></b></small></p>
    <!-- spit out data in table  -->
    
        <div class="container">
            <?php
        if(isset($_SESSION["loggedinadmn"]) && !empty($_SESSION["idadmn"])){
            //load the data from db and display in cards: name, image, key-features (3) , condition, price, stock
         $sql="SELECT product_name, images, unique_key, key_features, product_condition, bike_color, price, stock, bike_size FROM products ORDER BY id DESC;";
         $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
        if($rows > 0){
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                // $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                
               
              
                
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;


       

        
echo "<div class='flex-container'>
<div class='card' style='max-width: 600px;'>
<div class='row g-0'>
    <div class='col-5'>
        <img src='$image_path' class='card-img-top h-100' alt='bike image kenya Mombasa' style='object-fit:fill;'>
    </div>
    <div class='col-7' style='background: #868e9675;'>
        <div class='card-body' >
            <h5 class='card-title' style='margin:0;padding:0;'>$name</h5>
            <small style='text-decoration: underline;'><b>Key features</b></small>
            <p class='card-text ' style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis; font-size:small; margin:0 ;padding:0;'>$allkeyf </p>
            <p style='font-size:small; margin:0 ;padding:0;'><b>Color: </b>$color  
            <b>  Condition: </b>$product_condition</p>
            <p style='font-size:small; margin:0 ;padding:0;'><b>Size: </b>$size inches 
            <b>Product ID: </b> $unique_key</p>
            <p style='font-size:small; margin:0 ;padding:0;'><b>Availability:</b> $stock</p>
            <p style='font-size:small; margin:0 ;padding:0;'><b>Price: </b>$price</p>
           

        </div>
    </div>
</div>
</div></div></br>";



            }

            
            }else{
                echo " <div class='alert alert-danger'>
                <strong><i class='fas fa-xmark'></i> No data!! </strong> Oops! nothing is uploaded  yet, come back later
                </div>";
            }

        }else{
        echo "<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Login!</strong> to access this page you must be logged in  <a href='admin entry.php' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
          </div>
            </div>
        </center>";
        }
?>

        </div>







</br>
<?php include "footer.php" ?>

</body>
</html>