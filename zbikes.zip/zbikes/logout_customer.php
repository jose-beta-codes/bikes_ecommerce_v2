<?php

session_start();
if($_SESSION["loggedin"]==true || !empty($_SESSION["id"])){
    if(isset($_POST['logout'])){
        $_SESSION = array();
        session_destroy();
        header("location: home");
        exit;
    }


}else{
    header("location:  login");
}

?>