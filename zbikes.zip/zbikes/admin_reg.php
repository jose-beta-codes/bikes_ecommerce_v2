<?php
session_start();
require_once "piccsz.php";
$full_name= $username= $email= $passkey= $confirm_passkey="";
$full_name_err= $username_err= $email_err= $passkey_err= $confirm_passkey_err="";

if($_SERVER["REQUEST_METHOD"]=="POST"){


    if(empty(trim($_POST['full_name']))){
        $full_name_err="Please enter your full name!";

    }
    else{
        $full_name=trim($_POST['full_name']);
    }

    if(empty(trim($_POST["username"]))){
        $username_err="Please enter a username.";
    }
    elseif(!preg_match('/^[a-zA-Z0-9_]+$/',trim($_POST["username"]))){
        $username_err="Full name can only contain letters, numbers and underscores.";
    }
    else{
       
        $sql="SELECT id from admins WHERE username =?";
        if($stmt=mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s",$param_username);
            $param_username=trim($_POST["username"]);
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt)==1){
                    $username_err="This username is already taken.";
                }else{
                    $username=trim($_POST["username"]);
                }
            }else{
                echo "<h3 class='text-danger'>Oops! Something went wrong. Please try again later.</h3>";
                
            }
        }mysqli_stmt_close($stmt);
    }
    if(empty(trim($_POST["email"]))){
        $email_err="Email is required.";
    }    
    elseif(filter_var($email, FILTER_VALIDATE_EMAIL)){
        $email_err="Please enter a valid email address.";
    }
    else{
        $email=trim($_POST["email"]);
        // $environment_status=0;
        // $storage_given="5GB";
    }
    if(empty(trim($_POST["passkey"]))){
        $passkey_err="Please enter a passkey.";
    }elseif(strlen(trim($_POST["passkey"])) < 6){
        $passkey_err="Password must have atleast 6 characters.";
    }else{
        $passkey=trim($_POST["passkey"]);
    }

    if(empty(trim($_POST["confirm_passkey"]))){
        $confirm_passkey_err="Please confirm your passkey.";
    }else{
        $confirm_passkey=trim($_POST["confirm_passkey"]);
        if(empty($confirm_passkey_err) && ($passkey !=$confirm_passkey)){
            $confirm_passkey_err="Passkey didn't match.";
        }
    }
 
    if(empty($username_err)&& empty($email_err)&&  empty($passkey_err)&& empty($confirm_passkey_err)){
        
        $sql="INSERT INTO admins(full_name, username, email, passkey) VALUES(?,?,?,?)";
        if($stmt=mysqli_prepare($conn,$sql)){
            mysqli_stmt_bind_param($stmt, "ssss",$param_full_name, $param_username, $param_email, $param_passkey);
            $param_full_name=$full_name;
            $param_username=$username;
            $param_email=$email;
            $param_passkey=password_hash($passkey, PASSWORD_DEFAULT);

            if(mysqli_stmt_execute($stmt)){
                $id="2_5_4";
                $_SESSION["loggedinadmn"] = true;
                $_SESSION["idadmn"] = $id;
                $_SESSION["usernameadmn"] = $username;
                header("location: administrator.php");
                
            }else{
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }

    }
    mysqli_close($conn);

}



?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Administrator login</title>
</head>
<body>
    <?php include "customer_header.php"; ?>
</br>
<center>
    <div class="container">
       <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <legend class="text-danger" style="text-decoration:underline double;"><h2>Administrator Entry</h2></legend>
        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($full_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $full_name; ?>" id="full name" placeholder="Enter full name"  name="full_name">
            <label for="full name">full name (in order of; first middle last)</label>
            <span class="invalid-feedback"><?php echo $full_name_err; ?></span>
            </div>
        
        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>" id="username" placeholder="Enter username"  name="username">
            <label for="username">username</label>
            <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>" id="email" placeholder="Enter your email"  name="email">
            <label for="email">email</label>
            <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($passkey_err)) ? 'is-invalid' : ''; ?>" value="" id="security passkey" placeholder="Enter security passkey"  name="passkey">
            <label for="security passkey">security passkey</label>
            <span class="invalid-feedback"><?php echo $passkey_err; ?></span>
            </div>

            <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($confirm_passkey_err)) ? 'is-invalid' : ''; ?>" value="" id="security passkey" placeholder="Enter security passkey"  name="confirm_passkey">
            <label for="security passkey">confirm security passkey</label>
            <span class="invalid-feedback"><?php echo $confirm_passkey_err; ?></span>
            </div>

            <input type="reset" class="btn btn-danger"  value="Cancel" style="margin-right: 50px;">
        <input type="submit" class="btn btn-primary" name="submit" value="Register">    
       </form> 
    </div>
</center>
</br></br>
    <?php include "footer.php"; ?>
</body>
</html>