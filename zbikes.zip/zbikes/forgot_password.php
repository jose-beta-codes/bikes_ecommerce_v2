<?php
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
        use PHPMailer\PHPMailer\Exception;

require_once "envtext.php";
require "piccsz.php";
$messo="";
if(isset($_POST['check_account'])){
  //the email
  $email=mysqli_real_escape_string($conn,$_POST['email']);
  //sql
  $sql="SELECT username, email FROM customers WHERE email=?;";
  if($stmt=mysqli_prepare($conn, $sql)){
    mysqli_stmt_bind_param($stmt, "s", $param_email);
    $param_email=$email;
    if(mysqli_stmt_execute($stmt)){
      mysqli_stmt_store_result($stmt);
      $rownum=mysqli_stmt_num_rows($stmt);
      if($rownum>0){
        mysqli_stmt_bind_result($stmt, $result_username, $result_email);
        mysqli_stmt_fetch($stmt);
        $mailusername=$result_username;
        $mailto=$result_email;
        $key=uniqid().uniqid();
        $url="http://localhost/zbikess/zbikess/resetpassword.php?key=".$key;
        $date_recordedd=date_create(date("Ymdhis"));
        $date_recorded=date_format($date_recordedd,"Y-m-d");
        $date_expirelyy=date_add($date_recordedd, date_interval_create_from_date_string("1 days"));
        $date_expirely=date_format($date_expirelyy,"Y-m-d");

        
      $sql="INSERT INTO password_reset(email, reset_key, time_generated, expirely_date) VALUES(?, ?, ?, ?);";
      if($stmt=mysqli_prepare($conn, $sql)){
          mysqli_stmt_bind_param($stmt, "ssss", $param_email, $param_key, $param_date_generated, $param_expirely);
          $param_email=$mailto;
          $param_key=$key;
          $param_date_generated=$date_recorded;
          $param_expirely=$date_expirely;

          if(mysqli_stmt_execute($stmt)){

            $message="Hello, your request to reset password has been received and processed. Use the link provided 
            below to reset your password. ".$url." Thank You.";

            require_once("vendor\phpmailer\phpmailer\src\PHPMailer.php");
            require_once("vendor\phpmailer\phpmailer\src\SMTP.php");
            require_once('vendor\autoload.php');



            $mail = new PHPMailer(true);
            try {
            // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = $_ENV['MAILER_ACCOUNT'];                     //SMTP username
            $mail->Password   =  $_ENV['MAILER_PASSWORD'];                               //SMTP password
            $mail->SMTPSecure = PHPMAILER::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
            $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

            //Recipients
            $mail->setFrom( $_ENV['MAILER_ACCOUNT'], 'ZBIKES KENYA');
            $mail->addAddress($mailto, $mailusername);     //Add a recipient
            // $mail->addAddress('ellen@example.com');               //Name is optional
            $mail->addReplyTo('noreply@example.com', 'No reply');
            // $mail->addCC('cc@example.com');
            // $mail->addBCC('bcc@example.com');

            //Attachments
            //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
            // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

            //Content
            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = 'Password Reset';
            $mail->Body    = $message;
            $mail->AltBody = strip_tags($message);

            $mail->send();

            $messo= "<div class='container' style='width:85%;'>
                <div class='alert alert-success alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Success! </strong> a password reset email has been sent. Check your inbox.
              </div>
                </div>";
            } catch (Exception $e) {
            $messo= "<div class='container' style='width:85%;'>
                <div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Error! </strong> Failed to send the email, please try again or contact us Tel: 0717734372
                </div>
                </div>";
            }

        }mysqli_stmt_close($stmt);
      }




      }else{
        $messo= "<div class='container' style='width:85%;'>
        <div class='alert alert-danger alert-dismissible fade show'>
        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
        <strong>Unknown email! </strong> we could not find your account with the email provided, kindly input the correct email.
        </div>
        </div>";
      }


    }
  
  }
}




?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Forgot password Zbikes bicycle shop Kenya</title>
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
    }

  .buttons{
    display: flex;
    justify-content:space-between;


  }
</style>
</head>
<body>
    <?php include "customer_header.php" ?>
<center><h1><u>Zbikes Kenya</u></h1></center>
<p>forgot your password? Reset it here now</p>
<diV class="flex-container">
  <?php echo($messo); ?>
<div class="card" >
      <!-- <img class="card-img-top" src="..." alt="Card image cap"> -->
      <div class="card-body" style="padding:25px;">
        <h5 class="card-title text-success">Reset Password</h5>
        <p class="card-text">Provide your email address</p>
        <form method="POST" action="">
        <!-- <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control" value="" id="username" placeholder="Enter username"  name="username" required>
            <label for="username">username</label>
            <span class="invalid-feedback"></span>
            </div> -->

            <div class="form-floating mb-3 mt-3">
            <input type="email" class="form-control" value="" id="username" placeholder="Enter email"  name="email" required>
            <label for="username">Email</label>
            <span class="invalid-feedback"></span>
            </div>
             <div class="buttons">
            <input type="reset" value="Cancel" class="btn btn-danger btn-sm"/>
            <input type="submit" name="check_account" value="Continue" class="btn btn-success btn-sm"/></div>
        </form>
      </div>
    </div>

</diV>




</br>
<?php include "footer.php" ?>
</body>
</html>