<?php
session_start();
require "piccsz.php";
require_once "envtext.php";
$width=$diff="";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: admin_login");
        exit;
    }

    $button= $due_amount=$tmessage="";
    if(isset($_POST['add_subscription'])){
        $months=$_POST['months'];
        $_SESSION['months']=$months;
        $due_amountt=1500*$_SESSION['months'];
        $due_amount=number_format($due_amountt);
        $_SESSION['due']=$due_amountt;
        $button="1";
    }

    if(isset($_POST['pay_subscription'])){
        $phone_no=$_POST['phone_no'];

        //pay here 

        $amount = $_SESSION['due'];
        $amount=1; 
                    $phonenumber = $phone_no;
                    
                    $Account_no = $_SESSION['months']; 
                    $url = 'https://tinypesa.com/api/v1/express/initialize';
                    $data = array(    
                        'amount' => $amount,
                        'msisdn' => $phonenumber,
                        'account_no'=>$Account_no
                    );
                    $headers = array(
                        "Content-Type: application/x-www-form-urlencoded",
                        "ApiKey: $_ENV[SUBSCRIPTION_API_KEY]"
                    );
                    $info = http_build_query($data);
                    
                    $curl = curl_init();
                    curl_setopt($curl, CURLOPT_URL, $url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $info);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                    $resp = curl_exec($curl);
                    $msg_resp = json_decode($resp);
                    
                    
                    
                    if ($msg_resp ->success == 'true') {
                        $tmessage= "<div class='alert alert-success alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong><i class='fas fa-check'></i> Success!</strong> stk push sent to your phone, enter your mpesa pin to complete the subscription.
                        </div>";
                        
                    } else {
                        $tmessage= "
                        <div class='alert alert-danger  alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong><i class='fas fa-xmark'></i> Failed!</strong> An error occurred, please try again
                        </div>
                        ";
                    
                    
                            }
        

    }

    //date calculations
    $sql="SELECT deadline FROM subscription ORDER BY id DESC LIMIT 1;";
    if($stmt=mysqli_prepare($conn, $sql)){
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt)>0){
                mysqli_stmt_bind_result($stmt, $param_deadline);
                mysqli_stmt_fetch($stmt);
                //$the_deadline="";
                $the_deadline=$param_deadline;
                $current=date_create(date("Y-m-d"));
                $diff_deadline=date_create($the_deadline);
                $diff=date_diff( $current,$diff_deadline);
                $arr=explode("+", $diff->format('%R%a'));
                if($arr[1] >= 30) {
                    $width="100%";
                }elseif($arr[1] >= 15){
                    $width="70%";
                }elseif($arr[1] >= 8){  
                    $width="30%";
                }elseif($arr[1] < 5){  
                    $width="5%";
                }else{
                }
            }
        } mysqli_stmt_close($stmt);
    }



}else{
    header("location:  admin_login");
}




?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>My Subscription</title>

    <style>
    .flex-container {
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
}

    </style>

</head>
<body>
    <?php include "admin_header.php"; ?>
    <center>
        <div class="container">
            <h2 class="text-success"><u>My Subscription</u></h2>
        </div>
    </center>
    <div class="container">
        <p style="margin:0 ;padding:0;">Due to continuous maintainance that is necessary for proper running of this web application, we are charging <b>1500 KSH</b> per month. </p>
        <p style="margin:0 ;padding:0;"><b>The first 2 months are completely free</b></p>
        <!-- <p style="margin:0 ;padding:0;">We catter for everything including <b>Domain name</b> NOTE: Later we might change the domain of the site to a more suitable one if needed</p> -->
</div>
</br>
<center>
    <div class="container">
        <?php echo(!empty($tmessage)? $tmessage :''); ?>
    </div>
</center>

<div class="flex-container">
    <div class='card' style='max-width: 95%;'>
        <div class='row g-0'>
            <div class='col-5' style='background: #868e96;'>
                <img src='growth.jpeg' class='card-img-top h-100' alt='maintainance photo'>
            </div>
            <div class='col-7'>
                <div class='card-body'>
                    <p class='card-text'  style="margin:0 ;padding:0;"><u><b>Subscription Dashboard</b></u></p>
                    <p style="font-size: x-small; ">Our focus is  continous growth of your shop and security of its data</p>
                    <p style="font-size: x-small; margin:0 ;padding:0;"><b><u>Time left</u></b></p>

                    <div class="progress">
                    <div class="progress-bar progress-bar-primary progress-bar-striped" role="progressbar"
                        aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $width; ?>;">
                    </div>
                      </div>
</br>
                       <center>
                         <!-- here when add subsription is clicked that months and add subscription are removed and an input to receive no is shown -->
                         <?php echo (empty($button)?  "<div style='font-size: small;'>
                            <form method='POST' action=''>  
                                <label>Months</label>
                                <input type='number' name='months' value='1' min='1' max='12' placeholder='Months' style='width:40px; margin-right: 7px;'/>
                                <button type='submit' name='add_subscription' class='btn btn-danger btn-sm' style='font-size: small;'>Add subscription</button>
                              </form>
                        </div>"    :  "<p style='font-size:small;  margin:0 ;padding:0;'><b>Confirm pay: $due_amount KSH for $_SESSION[months] month(s)</b></p>
                        <p style='font-size:small;  '>Enter paying phone number ;07XX XXXXXX</p>
                        <form method='POST' action='' style='font-size: small;'>
                        <input type='tel' name='phone_no' placeholder='Enter phone number' pattern='[0-9]{10}' required/></br></br>
                        <input type='submit' name='pay_subscription' value='Pay' class='btn btn-success btn-sm'/>

                    </form>"     );?>
                        
                        
                        
                       </center>
</br>
                   

                    <div class='bg-gray' style="width:100%; background:rgba(160, 160, 160, 0.548);">
                    <p class='text-dark' style='font-size:x-small; '><b>Total Time Remaining-><b>days:<u> <?php echo (!empty($diff)? $diff->format('%R%a'): ''); ?> </u>days remaining</b></p>
                    </div>

                    
                </div>
            </div>
        </div>
      </div> </br>

</div>

<center>
  <p>Experiencing any problems paying? Contact me:</p>
  <a href="administrator.php" style="text-decoration: none;"><button class="btn btn-primary mx-4 btn-sm">Back to home page</button></a>
  <a href="#" style="text-decoration: none;" ><button class="btn btn-danger btn-sm">Contact Developer</button></a>
</center>

</br>
<?php include "footer.php"; ?>
</body>
</html>