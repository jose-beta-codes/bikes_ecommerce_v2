<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
if($conn==false){
    die("Error: can not connect bana; ".mysqli_connect_error());
}
?>