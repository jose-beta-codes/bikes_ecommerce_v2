<?php
session_start();
require "piccsz.php";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: admin_login");
        exit;
    }

}else{
    header("location:  admin_login");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>  -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>User Guide bicycle shop Kenya</title>
</head>
<body>
    <?php include "admin_header.php"; ?>
</br>
<center>
    <h2 class="text-danger">
        <u>User Guide <i class="fas fa-book-open-reader"></i></u>
    </h2>
</center>
<p>Know how to use this web application to manipulate its full potential! </p>

<div class="container">
        
        <div class="row gy-3 ">

        <div class="col-lg-6 col-md-12 col-12">
            <div class="box h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
              <!-- <img src="..\zbikess\pics\zbikess.ke-20220811-0077.jpg" alt="image test" > -->
              <h4 class="text-danger"><u>In a brief</u></h4>
              
              <p>This page contains descriptions and instructions of features that are intergrated here to make everything a success.</p>
              <b><u>Strength:</u></b>
              <ul>
              <li>Very easy to use - high automation has made it user friendly</li>
              <li>Accountancy and record keeper -transactions are clearly recorded for any future reference</li>
              <li>Search Engine Optimized(SEO) -good for search engines</li>
              <li>Strong Security -database is well protected from unauthorised access or attacks</li>
              <li>Constant maintainance - we will be checking on this site regulary to ensure everything is running as expected and propably incorporate updates.
                </li>
              </ul>
            </div>
          </div>

          <div class="col-lg-6 col-md-12 col-12">
            <div class="box  h-100 d-flex p-3 flex-column rounded" style='background-image:linear-gradient(to right, rgba(30, 143, 255, 0.569) , rgba(128, 128, 128, 0.549));'>
              <h4>Our Terms</h4>
              <p>Please read the following terms:</p>
              <ol type="1">
                <!-- <li><b>Business Data access -</b><b>NOTE: </b>we will <b>NOT</b> have any access to <b>administrator mode.</b> This is according to our terms; we do not have any direct access to 
                data of your business. Do not share the link or passkey to the administrator page with anyone. We will only access the database via the host AND we will stringly not tamper with any data in it.
                our only job is to check the status of the database to prevent errors that may make the site non-functional.</li> -->
                <li><b>Business Data Privacy- </b>privacy is first step towards big achievements and knowing that we guarantee maximum data protection from any third parties.</li>
                <li><b>Transparency -</b>everything is done clearly with no manupulation or unethical practices, no data from the business should be leaked.</li>
                <li><b>Permission of maintainance -</b>during maintainance if any access to administrator mode is needed we will seek your permission first by you giving us the admin username and passkey. Keep these credentials strong and private</li>
                <li><b>Our Goal -</b>we have a big vision about this site, inspired by many similar bigger sites; it is our co-target to grow this site country-wide at first. This site is search engine optimized which means that we 
                have incorporated features that enable the site to reach many by just google search and others such as Bing, Yahoo, Duckduckgo etc. Other trending features will be added to ensure we meet this goal.
                <b>Customers feel- </b> it is our wish that customers have a trustable platform to see, like, order items and perform other interations with items.</p></li>
            </ol>
            </div>
          </div>


          <div class="col-lg-6 col-md-12 col-12">
            <div class="box  h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
              <h4 class="text-success"> <b>1.</b><u>Add new product</u></h4>
              <p>You can either add a bike or a ball at the moment but if you want to add other types of items , you just have to write down the key features about the item and send the list to us then we shall add the product configaration</p>
               <p>Make sure you fill in every field of this form and kindly ensure you follow the instructions given per field.</p> 

            </div>
          </div>


          <div class="col-lg-6 col-md-12 col-12">
            <div class="box  h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
            <h4 class="text-success"> <b>2.</b><u>Orders page</u></h4>
              <p>New orders page shows new orders that customers has placed while complete orders shows the orders that have been attended to i.e you have ticked them as complete ; this action is reversible -
                 if you tick an order as complete you can head over to complete orders page and reverse it back to new order if needed.</p>
               <p><u><b>About online payment</b></u></p>
               <p>Payment is via mpesa facilitated by <b>tinypesa</b> - this is an intermediate that allows funds to be received to the business code (till / paybill). We chose tinypesa with significant reasons: <b>Security of data online</b> and <b>Reliability (in terms of STK push success).</b> </p> 

            </div>
          </div>


          <div class="col-lg-6 col-md-12 col-12">
            <div class="box h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
            <h4 class="text-success"> <b>3.</b><u>Stock manager</u></h4>
              <p>This feature allows you to too see everything that is in the shop (items in the shop)</p>
               <p>You will also be able to search items and perform actions such as <b>delete items</b> if needed.</p>
               <p>You control what items are displayed to the customers.</p>
</br>
               <h4 class="text-success"> <b>3.</b><u>Send notification</u></h4>
               <p>You can send offer notifications to all customers or send a customer-specific notification</p>

               <h4 class="text-success"> <b>4.</b><u>Add Happy customer</u></h4>
               <p>Here you can add a picture and a description about a customer who has made a purchase. Customers will view this data in the satisfied customers page.</p>

               <h4 class="text-success"> <b>5.</b><u>Customer accounts</u></h4>
               <p>All the details of the registered customers can be accessed on this page</p>

            </div>
          </div>


          <!-- <div class="col-lg-6 col-md-12 col-12">
            <div class="box h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
            <h4 class="text-danger"> <b><u>Subscription</u></b></h4>
              <p>A monthly subscription of 1500 Ksh will be incurred</p>
              <p><b>The first 2 months will be free of charge.</b></p>
              <p>You can also subscribe for more than one month and make payment at once.</p>
               <p>If the subcription is not done, the site will automatically stop diplaying items to the customers and will be almost non-functional.</p>
               <p>Contact me for any additional info. Thank you!</p> 
               <a href="subscription.php" class="btn btn-primary rounded-pill mt-auto">Go to subscription page</a>

            </div>
          </div> -->


        </div>
</div>

</br>
<?php
include "footer.php";
?>
    
</body>
</html>