<?php
session_start();
require "piccsz.php";


$sql="SELECT deadline, warning_date FROM subscription ORDER BY id DESC LIMIT 1;";
if($stmt=mysqli_prepare($conn, $sql)){
    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt)>0){
            mysqli_stmt_bind_result($stmt, $param_deadline, $param_warning);
            mysqli_stmt_fetch($stmt);
            $deadline=$param_deadline;
            $warning_date=$param_warning;
            $deadline_check=new DateTime($deadline);
            $warning_check=new DateTime($warning_date);
            $currentt=date("Y-m-d");
            $current=new DateTime($currentt);
            if($current>$deadline_check){
                header("location: error.php");
            }

        }else{
            header("location:  error.php");
        }
    }
    mysqli_stmt_close($stmt);
}



?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>account bicycle shop</title>
    <style>
    .flex-container_order {
  display: flex;
  justify-content: center;
  align-items: center;
}

.flex-box{
    display: flex;
  justify-content: space-around;
}

    </style>

</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Offcanvas navbar large">
        <div class="container-fluid">

        <a class="navbar-brand">
            <img src="logo.jpg" alt="Logo" style="width:50px;" class="rounded-pill">
        </a>

        <span class="text-light " style="font-weight: bold;"><i class="fas fa-bicycle"></i> Bicycle shop</span>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="offcanvas offcanvas-end text-white bg-dark" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
            <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Bicycle shop <i class="fas fa-bicycle"></i></h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
            <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="home"> <button class="btn btn-outline-primary"><i class="fas fa-house-user"></i> Home</button></a>
                </li>
                <li class="nav-item">
                <a class="nav-link " href="cart"><button type="button" class="btn  btn-primary"  data-bs-toggle="tooltip" title="Programming career and projects"> <i class="fas fa-cart-arrow-down"></i> My Cart</button></a>
                </li>

                <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="orders"> <button class="btn btn-outline-danger"  style="text-decoration: underline double dodgerblue;"><i class="fas fa-truck-fast"></i> My Orders</button></a>
                </li>

               
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="offcanvasNavbarLgDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                    <button class="btn btn-danger"> <i class="fas fa-bars"></i> Menu</button>
                </a>
                <ul class="dropdown-menu" aria-labelledby="offcanvasNavbarLgDropdown" style="background-image:linear-gradient(to bottom, dodgerblue , grey);">
                <li><a href="account"  style="text-decoration:none ;"><button style="border:none;" type="button"  data-bs-toggle="modal" data-bs-target="#mylife" class="dropdown-item btn" ><i class="fas fa-user"></i> My account</button></a></li>
                <li><a href="https://maps.app.goo.gl/3NTeE3XcAgUJQo3BA" style="text-decoration: none;"><button style="border:none;" type="button"  data-bs-toggle="modal" data-bs-target="#mylife" class="dropdown-item btn" ><i class="fas fa-map-location-dot"></i> Shop location and directions</button></a></li>
                    <!-- <li><button type="button" data-bs-toggle="modal" data-bs-target="#education" class="dropdown-item btn">Contacts</button></li> -->
                    <li><a href="happy_customers" style="text-decoration: none;"><button type="button" class="dropdown-item"><i class="fas fa-circle-check"></i> Happy customers</button></a></li>

                    <li>
                    <hr class="dropdown-divider">
                    </li>
                    <li><a href="notifications_and_offers" style="text-decoration: none;"><button  class="dropdown-item btn" ><i class="fas fa-star-half" style="color:orange;"></i>Offers and notifications</button></a></li>
                    <li><a href="about"  style="text-decoration:none ;"><button type="button"  class="dropdown-item btn" >About Us</button></a></li>
                    <li><button type="button" data-bs-toggle="modal" data-bs-target="#contact" class="dropdown-item btn" >Contact</button></li>
                    <?php echo (isset($_SESSION["username"])? "<li><form method='post' action='logout'><button type='submit' name='logout'data-bs-toggle='modal' data-bs-target='contact' class='dropdown-item btn' ><i class='fas fa-door-open'></i> Logout</button></form></li>": ""); ?>
                </ul>
                </li>
            </ul>
            </div>
        </div>
        </div>
    </nav>

<center>
<div class="container">
    <h2 style="text-decoration:underline double ; color: orange;"><b>My Orders</b></h2>
</div>
</center>
<div class="container-fluid">
    <p>Riding is fun and healthy</p>
</div>

<div class="container">

<?php
// here check whether the user is logged in or not dispaly a login form if the user is not logged in else sisplay his account details''
if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){

    $qry="SELECT id FROM customers WHERE username=?;";
    if($stmt=mysqli_prepare($conn, $qry)){
        mysqli_stmt_bind_param($stmt, "s", $param_user);
        $param_user=$_SESSION['username'];
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_bind_result($stmt, $param_id);
            mysqli_stmt_fetch($stmt);
            $id=$param_id;

            mysqli_stmt_close($stmt);

            // next query
            $qryy="SELECT item_key FROM orders WHERE customer_id=?;";
            if($stmtt=mysqli_prepare($conn, $qryy)){
                mysqli_stmt_bind_param($stmtt, "s", $paramm_id);
                $paramm_id=$id;
                if(mysqli_stmt_execute($stmtt)){
                    $result=mysqli_stmt_get_result($stmtt);
                    $result_rows=mysqli_fetch_all($result, MYSQLI_ASSOC);
                    $total_rows=count($result_rows);
                    if($total_rows>0){
                    $quantity='1';
                    for($i=0;$i<$total_rows;$i++){
                    $row = $result_rows[$i];
                    $item_id=$row['item_key'];

                    // next query
                    $qryyy="SELECT product_name, images, unique_key, key_features, product_condition, bike_color, price, bike_size, product_weight FROM  products WHERE unique_key=?;";
                    if($stmttt=mysqli_prepare($conn, $qryyy)){
                        mysqli_stmt_bind_param($stmttt, "s", $parammm_key);
                        $parammm_key=$item_id;
                        if(mysqli_stmt_execute($stmttt)){
                                mysqli_stmt_bind_result($stmttt, $param_name, $param_image, $param_itemkey, $param_keyf, $param_condition, $param_color, $param_price, $param_size, $param_weight);
                                mysqli_stmt_fetch($stmttt);
                                
                                $name_product=$param_name;
                                $image=$param_image;
                                $unique_key=$param_itemkey;
                                $key_features=$param_keyf;
                                $condition=$param_condition;
                                $color=$param_color;
                                $price=$param_price;
                                $size=$param_size;
                                $weight=$param_weight;

                                $keyf=explode("##", $key_features);
                                $count=count($keyf);
                                $key1=($count>0? $keyf[0]." ": "");
                                $key2=($count>1? $keyf[1]." ": "");
                                $key3=($count>2? $keyf[2]." ": "");
                                $key4=($count>3? $keyf[3]." ": "");
                                $allkeyf=$key1.$key2.$key3.$key4;
                    
                                mysqli_stmt_close($stmttt);
                    
                                echo "<div class='flex-container_order'>
                                <div class='card' style='max-width: 500px;'>
                                <div class='row g-0'>
                                    <div class='col-5'>
                                        <img src='$image' class='card-img-top h-100' alt='bike on sale photo' style='object-fit:fill;'>
                                    </div>
                                    <div class='col-7' style='background: #868e9630;'>
                                        <div class='card-body'>
                                            <h5 class='card-title' style='margin:0;padding:0;'>$name_product</h5>
                                            <small style='text-decoration: underline;'>Key features</small>
                                            <p class='card-text ' style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis; font-size:x-small; margin:0 ;padding:0;'>$allkeyf </p>
                                            <p style='font-size:x-small; margin:0 ;padding:0;'><b>Color: </b>$color  
                                            <b>  Condition: </b>$condition</p>
                                            <p style='font-size:x-small; margin:0 ;padding:0;'><b>Size: </b>$size inches 
                                            <b>  Weight(kg): </b> $weight</p>
                                            <p style='font-size:x-small; margin:0 ;padding:0;'><b>no. of pieces:  </b>$quantity</p>
                                            <p style='font-size:x-small; margin:0 ;padding:0;'><b>Payment: </b><span class='bg-success p-1 text-white rounded'><i class='fas fa-circle-check'></i> Completed</span></p></br>
                    
                                        </div>
                                    </div>
                                </div>
                            </div> </div></br>";
                
                        }
                    }

                }
               
                mysqli_stmt_close($stmtt);

                echo " <center><p style='font-size:x-small;'><p>We will give you a call shortly to arrange a delivery for you</p></p>
                <p style='font-size:x-small;'>Thank you for your recent purchase from us</p></center>";

                    }else{
                        echo "<center>
                        <div class='container' style='width:95%;'>
                        <div class='alert alert-primary alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong>No order yet!</strong> we could not find your order. Select an item from the home page to order  <a href='home' class='alert-link'><button class='btn btn-danger rounded-pill'>home page</button></a>
                      </div>
                        </div>
                    </center>";
                    }
                }
            }

        }
    }

}else{
    echo "<center>
    <div class='container' style='width:95%;'>
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login!</strong> login here see your order details  <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
    </div>
</center>";
}



?>

</div>

<div class="modal" id="contact">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Contact Us</h4>
        
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <center>
        <b>You can reach us through the following contacts</br>call us: <u>0717734372</u></b>
</br><small>use this links to see our social media </small><h1>&#128578</h1>

              <a  href="https://www.instagram.com/invites/contact/?i=zwvi3q5xee6j&utm_content=nr51ctr" ><b><i class="fab fa-instagram" style="color:rgba(245, 34, 118, 0.67);""></i><span style="color:rgba(245, 34, 118, 0.67);"> Instagram</span></b></a></br>
              <a  href="https://m.facebook.com/story.php?story_fbid=pfbid02aAzTopvwhrQVxJcdih7cLLko9GtyfG4Gqcm9iS2xLtcMCvJ3Qsw3sfWELmrnZBWAl&id=100075273326784"><b><i class="fab fa-facebook text-primary"></i><span style="color:dodgerblue"> Facebook</span></b></a></br>
              <a href="https://wa.me/+254717734372?text=Hello%20ZBIKESS%20i%20saw%20this%20on%20your%20site," class=""><b><i class="fab fa-whatsapp text-success"></i><span class="text-success"> Whatsapp</span></b></a></br>
              <a href="tel:0717734372" class="text-primary"><b><i class="fas fa-phone-volume"></i><span> Call us</span></b></a></br>
        </center>
      </div>

    </div>
  </div>
</div>



</br>
<?php include "footer.php" ?>
</body>
</html>