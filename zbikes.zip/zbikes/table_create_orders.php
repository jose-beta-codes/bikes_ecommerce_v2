<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE orders(
    id INT(25) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    product_name VARCHAR(25) NOT NULL,
    customer_id VARCHAR(25) NOT NULL,
    customer_name VARCHAR(50) NOT NULL,
    customer_location VARCHAR(50) NOT NULL,
    quantity VARCHAR(25) NOT NULL,
    resultcode VARCHAR(25) NOT NULL,
    amount VARCHAR(255) NOT NULL,
    transaction_code VARCHAR(255) NOT NULL,
    transaction_date VARCHAR(25) NOT NULL,
    phone_no VARCHAR(25) NOT NULL,
    item_key VARCHAR(255) NOT NULL,
    transaction_status VARCHAR(25) NOT NULL,
    order_status VARCHAR(25)NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes orders successifully created!";
}
else{
    echo "Error creating table bana! ";
}