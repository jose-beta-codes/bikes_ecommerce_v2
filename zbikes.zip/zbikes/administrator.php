<?php
session_start();
require "piccsz.php";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: admin_login");
        exit;
    }

    //check deadline
    $deadline_messo="";
    $sql="SELECT deadline, warning_date FROM subscription ORDER BY id DESC LIMIT 1;";
    if($stmt=mysqli_prepare($conn, $sql)){
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt)>0){
                mysqli_stmt_bind_result($stmt, $param_deadline, $param_warning);
                mysqli_stmt_fetch($stmt);
                $deadline=$param_deadline;
                $warning_date=$param_warning;
                $deadline_check=new DateTime($deadline);
                $warning_check=new DateTime($warning_date);
                $currentt=date("Y-m-d");
                $current=new DateTime($currentt);
                if($current>=$warning_check){

                    $deadline_messo="<center>
                    <div class='container' style='width:70% ;'>
                    <div class='alert alert-danger alert-dismissible fade show'>
                    <strong>Subscription ending soon!</strong> your monthly subscription is about to expire. please make another subscription soon
                    <a href='subscription.php'><button class='btn btn-primary btn-sm rounded-pill'>Subscription page</button></a> 
                </div>
                    </div>
                </center>";

                    if($current>=$deadline_check){
                        header("location: subscription");
                    }
                }else{
                    
                }

            }else{
                header("location:  subscription");
            }
        }
        mysqli_stmt_close($stmt);
    }



    if(isset($_POST['see_actions'])){
        $unique_ky=$_POST['unique_key'];
        
        $_SESSION['clicked_item_admin']=$unique_ky;
        header("location: admin_product");
       
       
    }


}else{
    header("location:  admin_login");
}




?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>bicycle shop header</title>
</head>
<body>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Offcanvas navbar large">
        <div class="container-fluid">

        <a class="navbar-brand" href="logo.jpg">
            <img src="logo.jpg" alt="Logo" style="width:50px;" class="rounded-pill">
        </a>

        <span class="text-danger " style="font-weight: bold;"> Administrator mode <i class="fas fa-gears"></i></span>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="offcanvas offcanvas-end text-white bg-dark" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
            <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Bicycle shop <i class="fas fa-bicycle"></i></h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="administrator"> <button class="btn btn-outline-primary" style="text-decoration:underline double Red"><i class="fas fa-house-user"></i> Home page</button></a>
                </li>
                <li class="nav-item">
                <a class="nav-link " href="product_add"><button type="button" class="btn  btn-primary"  data-bs-toggle="tooltip"> <i class="fas fa-plus"></i> Add Product</button></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="customer_orders"><button type="button" class="btn  btn-outline-danger"  data-bs-toggle="tooltip" > <i class="fas fa-cart-arrow-down"></i> Orders</button></a>
                    </li>
               
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="offcanvasNavbarLgDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                    <button class="btn btn-danger"> <i class="fas fa-bars"></i> More Options </button>
                </a>
                <ul class="dropdown-menu bg-primary" aria-labelledby="offcanvasNavbarLgDropdown" style="background-image:linear-gradient(to bottom, dodgerblue , grey);">
                <li><a href="stock_manager" style="text-decoration: none;"><button style="border:none;" type="button"  class="dropdown-item btn" > Stock Manager</button></a></li>
                <li><a href="send_notification" style="text-decoration: none;"><button style="border:none;" type="button"   class="dropdown-item btn" > Send Notifications</button></a></li>
                    
                    <li><a href="satisfied_clients" style="text-decoration: none;"><button type="button"  class="dropdown-item">Add Happy customer</button></a></li>
                    <li><a href="customer_accounts" style="text-decoration: none;"><button type="button"  class="dropdown-item btn" >Customer Accounts</button></a></li>
                    <!-- <li><button type="button"  class="dropdown-item btn">Customer Messages</button></li> -->
                    <li><a href="home" style="text-decoration: none;"><button type="button"  class="dropdown-item">Go to Customer mode</button></a></li>

                    <li>
                    <hr class="dropdown-divider">
                    </li>
                    <!-- <li><a href="subscription.php" style="text-decoration: none;"><button type="button"  class="dropdown-item btn">My Subscription</button></a></li> -->
                    <li><form method="POST" action=""><button type="submit" name="exit" class="dropdown-item"><i class="fas fa-door-open "></i>Exit admin mode</button></form></li>
                    <li><a href="user_guide" style="text-decoration: none;"><button type="button"  class="dropdown-item btn">User Guide <i class="fas fa-book-open-reader"></i></button></a></li>
                </ul>
                </li>
            </ul>
            </div>
        </div>
        </div>
    </nav>
    
   
    
    <div>
        <p>Welcome back, <b><?php echo($_SESSION['usernameadmn']); ?></b> this page will show the items that  appear in the customer's page.</p>
    </div>
    
    <div class="container">
        <?php echo(!empty($deadline_messo)? $deadline_messo: ''); ?>
    </div>

    <div class="container-fluid">
    <p class="text-white" style="padding-left:8px;background-image:linear-gradient(to right, dodgerblue , grey);"><b>Top new</b><span style="float: right;padding-right:10px; color:gold;"><i class="fas fa-bicycle"></i></span></p>
</div>


    <section class="d-flex justify-content-center align-items-center h-100 min-vh-100">


<div class="container" >
        
        <div class="row gy-3 ">




        <?php
      if(isset($_SESSION["loggedinadmn"]) && !empty($_SESSION["idadmn"])){
            //load the data from db and display in cards: name, image, key-features (3) , condition, price, stock
         $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size FROM products ORDER BY id DESC LIMIT 8;";
         $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
        if($rows > 0){
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                
                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;


                //check for clicks
                $clicks="SELECT username FROM clicks WHERE unique_key='$unique_key';";
                $result_click=mysqli_query($conn, $clicks);
                $actual_clicks=mysqli_num_rows($result_click);

                $clicks="SELECT SUM(number_clicks) AS total_clicks FROM clicks WHERE unique_key='$unique_key';";
                $result_click=mysqli_query($conn, $clicks);
                $data=mysqli_fetch_assoc($result_click);
                $total_clicks=$data['total_clicks'];

                $stock_out=(!($stock=="in stock")? "Sold out": "");
                $padding=(!($stock=="in stock")? "padding:3px;": "");

            
            echo "
            
            <div class='col-6 col-md-4 col-lg-3 '>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo' class='rounded-top'>
                <$tag class='px-2'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>
                        <div class='mt-auto pb-3'>
                        <center>
                            <form method='POST' action=''>
                            <input type='hidden' name='unique_key' value='$unique_key'/> 
                            <input type='submit' name='see_actions' value='Actions' class='btn btn-primary rounded-pill'/>
                            </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , gold); font-size:x-small;'><small  style='padding:5px; float:left;'><b>Actual clicks: </b>$actual_clicks</small> <small style='padding:5px; float:right;'><b>Total clicks: </b>$total_clicks</small></div>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;' class='rounded-bottom'><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";   
            }
            }else{
                echo " <div class='alert alert-danger'>
                <strong><i class='fas fa-xmark'></i> No data!! </strong> Oops! nothing is uploaded here yet, come back later
                </div>";
            }

        }else{
            $login_err= "<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Login!</strong> to access this page you must be logged in  <a href='admin entry.php' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
          </div>
            </div>
        </center>";
        }
?>





           
        </div>
        
    </div>
    </section>
        </br>
    <div class="container-fluid">
    <p class="text-white" style="padding-left:8px; background-image:linear-gradient(to right, dodgerblue, rgba(220, 35, 35, 0.82))"><b>Top selling</b></p>

    <section class="d-flex justify-content-center align-items-center h-100 min-vh-100">


    <div class="container" >
        
        <div class="row gy-3 ">
        <?php
        if(isset($_SESSION["loggedinadmn"]) && !empty($_SESSION["idadmn"])){
            //load the data from db and display in cards: name, image, key-features (3) , condition, price, stock
         $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size FROM products ORDER BY   RAND();";
         $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
        if($rows > 0){
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                
                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;

                   //check for clicks
                   $clicks="SELECT username FROM clicks WHERE unique_key='$unique_key';";
                   $result_click=mysqli_query($conn, $clicks);
                   $actual_clicks=mysqli_num_rows($result_click);
   
                   $clicks="SELECT SUM(number_clicks) AS total_clicks FROM clicks WHERE unique_key='$unique_key';";
                   $result_click=mysqli_query($conn, $clicks);
                   $data=mysqli_fetch_assoc($result_click);
                   $total_clicks=$data['total_clicks'];

                   $stock_out=(!($stock=="in stock")? "Sold out": "");
                   $padding=(!($stock=="in stock")? "padding:3px;": "");

            
            echo "
            
            <div class='col-6 col-md-4 col-lg-3 '>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo'  class='rounded-top'>
                <$tag class='px-2'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>
                        <div class='mt-auto pb-3'>
                        <center>
                        <form method='POST' action=''>
                        <input type='hidden' name='unique_key' value='$unique_key'/> 
                        <input type='submit' name='see_actions' value='Actions' class='btn btn-primary rounded-pill'/>
                        </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , gold); font-size:x-small;'><small  style='padding:5px; float:left;'><b>Actual clicks: </b>$actual_clicks</small> <small style='padding:5px; float:right;'><b>Total clicks: </b>$total_clicks</small></div>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;' class='rounded-bottom'><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";   
            }
            }else{
                echo " <div class='alert alert-danger'>
                <strong><i class='fas fa-xmark'></i> No data!! </strong> Oops! nothing is uploaded here yet, come back later
                </div>";
            }

        }else{
            $login_err= "<center>
            <div class='container' style='width:70% ;'>
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Login!</strong> to access this page you must be logged in  <a href='admin entry.php' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
          </div>
            </div>
        </center>";
        }
?>



        </div>
        
    </div>
    </section>
    

</div>
</br>
</br>
    <?php  include "footer.php"; ?>
</body>
</html>