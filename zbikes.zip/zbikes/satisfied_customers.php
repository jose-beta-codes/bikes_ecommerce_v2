<?php
session_start();
require "piccsz.php";



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Happy customers bicycle shop kenya </title>
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
}

    </style>
</head>
<body>
    <?php include "customer_header.php"; ?>

<center>
    <div class="container">
        <h2 class="text-success"><u><i class="fas fa-circle-check"></i> Happy Customers</u></h2>
    </div>
</center>
<div class="container" style="font-size: small;">
    <p>We have a good reputation of legit business, we always ensure our customers needs are satisfied.</p>
    <p>See some of our satisfied customers here</p>
</div>


<div class="flex-container">
    

    <!-- get the data -->
    <?php
    $sql="SELECT customer_image, remarks FROM satisfied_customers;";
    $result=mysqli_query($conn, $sql);
    $rows=mysqli_num_rows($result);
    if($rows>0){
        for($i=0; $i<$rows; $i++){
            $row=mysqli_fetch_assoc($result);
            $customer_image=$row['customer_image'];
            $remarks=$row['remarks'];

            echo "<div class='card' style='max-width: 500px;'>
                    <div class='row g-0'>
                        <div class='col-5' style='background: #868e96;'>
                            <img src='$customer_image' class='card-img-top h-100' alt='customer photo'>
                        </div>
                        <div class='col-7'>
                            <div class='card-body'>
                                <small class='card-text'>$remarks</small>
                                <div class='card-footer mt-3'>
                                <p class='text-muted' style='font-size:x-small;'>It was an honour doing business with you</p>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div> <br>";
        }
        
    }else{
        echo "<div class='alert alert-primary alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>No data yet!</strong> Oops! we could not find any information on this page, come back later.
                </div>";
    }


?>

</div>



</br>
<?php include "footer.php"; ?>
    
</body>
</html>