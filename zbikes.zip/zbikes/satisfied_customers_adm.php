<?php
session_start();
require "piccsz.php";
$sati_customer_messo=$image_err="";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: home");
        exit;
    }

    //contents

if(isset($_POST['add_remark'])){

    $customer_desc=$_POST['customer_descr'];

    $filename=$_FILES['image']['name'];
    $filetmp_name=$_FILES['image']['tmp_name'];
    $filesize=$_FILES['image']['size'];
    $fileerror=$_FILES['image']['error'];
    $filetype=$_FILES['image']['type'];
    if(empty($filesize)){
        $image_err="Please select the image of the product";
    }else{
        

        if( $fileerror=="0"){
            //check where the file is an image use xplode function
            $filetypecheck=explode("/",$filetype);
            if($filetypecheck[0]=="image"){
                $filename_ar=explode(".", $filename);
                $file_ext=strtolower(end($filename_ar));//ready
                // $Actual_file_ext=".".$file_ext;
                $actual_filename=preg_replace('/.'.$file_ext.'/','${1}', $filename);
                //use actual_file_name and cartinate with username(this to be the location of the file in the db -> this is the name of the file in the folder)
                //but actual file name to be in separate coloumn in the db(refer to this when displaying its name and while downloading file)
                $unique_key=uniqid();
                $file_in_folder_name=$unique_key.".".$actual_filename.".".$file_ext;

                $file_destination="satisfied customers/".$file_in_folder_name;
                $return=move_uploaded_file($filetmp_name, $file_destination);
                if($return== true){
                    //success...indert the product
//here the file_destination is ready now
                    $file_destination_final=$file_destination;
                    

                        //now ready to feed in  the db
                        if(empty($image_err)){
                            $sql="INSERT INTO satisfied_customers(customer_image, remarks) VALUES (?,?)";
                            if($stmt=mysqli_prepare($conn, $sql)){
                                mysqli_stmt_bind_param($stmt, "ss", $param_image, $param_remarks);
                                $param_image=$file_destination_final;
                                $param_remarks=$customer_desc;
                                if(mysqli_stmt_execute($stmt)){
                                    $sati_customer_messo="
                                                <div class='alert alert-success alert-dismissible fade show'>
                                                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                                                <strong>success!</strong> added to satisfied customer page
                                            </div>
                                                ";

                                }else{
                                $sati_customer_messo="
                                <div class='alert alert-danger alert-dismissible fade show'>
                                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                                <strong>Failed!</strong> Oops! could not add the data, try again later or contact the developer
                            </div>
                                ";
                                }
                                mysqli_stmt_close($stmt);
                            }
                           
                        }

                }else{
                    $image_err="Failed to upload the image, try again later";
                }
            }else{
                $image_err="Only image files are accepted";
            }

        }else{
            $image_err="Error retrieving the selected file. please try another file";
        }
    }

}



}else{
    header("location:  admin_login");
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Satisfied customers bicycle shop Kenya</title>
</head>
<body>
    <?php
    include "admin_header.php";
    ?>
</br>
    <center>
        <div class="container">
            <h2 class="text-success"><u><i class="fas fa-circle-check"></i>Satisfied Customers</u></h2>
            <?php echo(!empty($sati_customer_messo)? $sati_customer_messo: ''); ?>
        </div>
    </center>
    <p>Add a picture and a brief remark about a customer that has already bought the item. This information will be displayed at the customers page as Satisfied clients.</p>
</br>
<div class="container">
    <p>You can see all the data/ info added to satisfied customers page here; you will be able to edit the data if needed, click the button below</p>
    <a href="happy_clients_all"><button class="btn btn-primary btn-sm">see all added remarks</button></a>
</div>
<div class="container">
<h6>Fill in the form below</h6>
</div>

<center>
    <div class="container">
    <form method="post" action=""  enctype="multipart/form-data">

        <div class="form-floating mb-3 mt-3">
            <input type="file" class="form-control <?php echo (!empty($image_err)) ? 'is-invalid' : ''; ?>" value="" id="file" placeholder="customer image"  name="image" required>
            <label for="file">Select an image of the client </label>
            <span class="invalid-feedback"><?php echo $image_err; ?></span>
            </div>


        <div class="form-group mb-3 mt-3">
            <textarea class="form-control" value="" id="textarea" rows="3" placeholder="A brief description or your remarks"  name="customer_descr" required></textarea>
            <span class="invalid-feedback"></span>
            </div>

            <input type="reset" value="Reset" class="btn btn-danger mx-5"/>
            <input type="submit" value="Done" class="btn btn-success" name="add_remark"/>
    </form>
    </div>
</center>


</br>
    <?php 
    include "footer.php";
    ?>
    
</body>
</html>