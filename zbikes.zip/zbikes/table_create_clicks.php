<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE clicks(
    id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    username VARCHAR(255) NOT NULL,
    unique_key VARCHAR(255) NOT NULL,
    number_clicks VARCHAR(255) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes clicks successifully created!";
}
else{
    die ("Error creating table bana! ");
}