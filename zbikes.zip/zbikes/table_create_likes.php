<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE likes(
    id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    username VARCHAR(255) NOT NULL,
    unique_key VARCHAR(255) NOT NULL,
    date_liked VARCHAR(50) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes likes successifully created!";
}
else{
    die ("Error creating table bana! ");
}