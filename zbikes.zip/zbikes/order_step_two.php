<?php
session_start();
require "piccsz.php";
require_once "envtext.php";
$login_err = $general_err= "";
$phone_no= $tmessage="";
$phone_no_err=  $transaction_st="";
if (isset($_SESSION["loggedin"]) && isset($_SESSION["username"])) {

    
    $customer_name=$_SESSION['final_order_step_fullname'];
    $customer_location=$_SESSION['final_order_step_location'];
    $item_key=$_SESSION['final_order_step_itemkey'];
    $quantity=$_SESSION['final_order_step_quantity'];



        //check the item cost
        $sql="SELECT product_name, unique_key, price FROM products WHERE unique_key='$item_key';";
        $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
            if($rows > 0){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $unique_key=$row['unique_key'];
                $price=$row['price'];


                    
                $price_int=explode(",",$price);
                $price2=(isset($price_int[1])? $price_int[1]: "");
                $price3=(isset($price_int[2])? $price_int[2]: "");
                $price_alll= $price_int[0].$price2.$price3;
                $price_all=$price_alll*$quantity;


                $sql="SELECT id FROM customers WHERE username='$_SESSION[username]';";
                $result=mysqli_query($conn, $sql);
                $data=mysqli_fetch_assoc($result);
                $customer_id=$data['id'];

                $trans_desc=$unique_key."##".$customer_id;

                //dooh
                $pre_orderkey=uniqid();
                    if(isset($_POST['pay'])){


                    if(empty(trim($_POST['phoneno']))){
                        $phone_no_err="<small class='text-danger'><i class='fas fa-exclamation'></i> please input your phone number to receive stk push</small></br>";
                    }elseif(!is_numeric($_POST['phoneno'])){
                        $phone_no_err="<small class='text-danger'><i class='fas fa-exclamation'></i> only numeric values are accepted, please try again</small></br>";
                    }else{
                        $phone_no=$_POST['phoneno'];

                        $sql="SELECT product_name FROM products WHERE unique_key='$item_key';";
                        $result=mysqli_query($conn, $sql);
                        $data=mysqli_fetch_assoc($result);
                        $product_name=$data['product_name'];

                        

                        $sql="INSERT INTO pre_orders(full_name, customer_location, customer_id, pre_order_key, product_name, quantity, product_key)
                        VALUES(?,?,?,?,?,?,?)";

                        if($stmt=mysqli_prepare($conn, $sql)){
                            mysqli_stmt_bind_param($stmt,"sssssss", $param_name, $param_location, $param_id, $param_pre_orderkey, $param_product_name, $param_quantity, $param_productkey);
                            $param_name=$customer_name;
                            $param_location= $customer_location;
                            $param_id=$customer_id;
                            $param_pre_orderkey=$pre_orderkey;
                            $param_product_name=$product_name;
                            $param_quantity=$quantity;
                            $param_productkey= $item_key;

                            mysqli_stmt_execute($stmt);
                        }
                    }




                    if(empty($phone_no_err)){

                    $amount = $price_all; //Amount to transact 
                    $phonenumber = $phone_no; // Phone number paying
                    
                    $Account_no = $pre_orderkey; // Enter account number optional
                    $url = 'https://tinypesa.com/api/v1/express/initialize';
                    $data = array(    
                        'amount' => $amount,
                        'msisdn' => $phonenumber,
                        'account_no'=>$Account_no
                    );
                    $headers = array(
                        "Content-Type: application/x-www-form-urlencoded",
                        "ApiKey: $_ENV[SUBSCRIPTION_API_KEY]"
                    );
                    $info = http_build_query($data);
                    
                    $curl = curl_init();
                    curl_setopt($curl, CURLOPT_URL, $url);
                    curl_setopt($curl, CURLOPT_POST, true);
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $info);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
                    $resp = curl_exec($curl);
                    $msg_resp = json_decode($resp);
                    
                    
                    
                    if ($msg_resp ->success == 'true') {
                        $tmessage= "<div class='alert alert-success alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong><i class='fas fa-check'></i> Success!</strong> stk push sent to your phone, enter your mpesa pin to complete the transaction, thank you for shopping with us
                        </div>";
                        
                    } else {
                        $tmessage= "
                        <div class='alert alert-danger  alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong><i class='fas fa-xmark'></i> Failed!</strong> An error occurred, please try again
                        </div>
                        ";
                    
                    
                            }
                        }
                    }



                
                
            }else{
            $general_err="<center>
            <div class='container' style='width:95% ;'>
            <div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>Not found! <i class='fas fa-xmark'></i></strong> the item you requested cannot be found, kindly try again later  <a href='home' class='alert-link'><button class='btn btn-danger rounded-pill'>Go to home</button></a>
        </div>
            </div>
        </center>";
        }


        if(isset($_POST['check_status']) ){
            $sql="SELECT transaction_code FROM orders WHERE item_key='$item_key';";
            $result=mysqli_query($conn, $sql);
            $rows=mysqli_num_rows($result);
            if($rows>0){
                $data=mysqli_fetch_assoc($result);
                $code=$data['transaction_code'];
                $transaction_st="<center>
                <div class='container' style='width:95% ;'>
                <div class='alert alert-primary alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Completed! <i class='fas fa-check'></i></strong> the transaction was successiful , transaction code: $code . Thankyou for shopping with us!   <a href='orders' class='alert-link'><button class='btn btn-danger rounded-pill'>See your order here</button></a>
              </div>
                </div>
            </center>";
            }else{
                $transaction_st="<center>
                <div class='container' style='width:95% ;'>
                <div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Not found! <i class='fas fa-xmark'></i></strong> the transaction is yet to be processed or was cancelled. Please wait a few minutes then try again, if problem persists please contact us for assistance <i class='fas fa-phone'></i> 0717734372
            </div>
                </div>
            </center>";

            }
        }



} else {
    $login_err = "<center>
    <div class='container' style='width:95% ;'>
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login! <i class='fas fa-cart-arrow-down'></i></strong> login here see your cart contents  <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
    </div>
</center>";
}









?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon" />
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Order step 2 bicycle shop KENYA</title>
</head>

<body>

    <?php include "customer_header.php" ?>

    <div class="container mt-2">
        <?php echo (isset($login_err) ? $login_err  : ""); ?>
        <?php echo (!empty($general_err) ? $general_err  : ""); ?>
        <?php echo (!empty($tmessage) ? $tmessage : ""); ?>
        <?php echo (!empty($transaction_st) ? $transaction_st : ""); ?>
    </div>

    <center>
        <h2 style="text-decoration: underline double; font-weight:bolder;" class="text-danger">Final Step: 2/2 <i class="fas fa-truck-fast"></i></h2>
    </center>
    <div class="container"><small>Complete the payment to order the item.</small></div>
    <center>
    <h4>Payment is done through <b class="text-success">M<i class="fas fa-mobile text-danger"></i>PESA</b></h4>

    <div class="container" style="border-radius:20px;">
                <?php
                    if(isset($_POST['pay']) && empty($phone_no_err)){
                        echo "<div class='container' style='width:95% ;'>
                        <div class='alert alert-primary alert-dismissible fade show'>
                        <strong>Check transaction status </strong> click the button below after you are done transacting
                        </br>
                        <form method='POST' action=''>
                        <button type='submit' name='check_status' class='btn btn-danger  mb-3'>Check status</button>
                        </form>
                      </div>
                        </div>";
                    }

?>
                </div>
            
        <div class="container">
        <div  style="border-radius: 20px; border-style: solid; border-color:grey; padding:10px; margin-left:10px; margin-right:10px;">
                <form method="POST" action="">
                    <fieldset class="text-grey">
                        
                        <p>The confirmation Mpesa name should be: <b>SOKO NDOGO LTD-MOMBASA</b> (through <u>tinypesa</u>)</p>
                        <p><b>note that-the stk push will display <u>tinypesa</u></b></p>
                        <div class="form-floating mb-3 mt-3">
                            <input type="tel" class="form-control <?php echo(!empty($phone_no_err)? 'is-invalid':""); ?>" value="<?php echo(empty($phone_no_err)? $phone_no:""); ?>" id="tell" placeholder="Enter the paying phone number e.g 07xx xxxxxx" name="phoneno" pattern="[0-9]{10}" required>
                            <label for="tell">Enter the paying phone number e.g 07xx xxxxxx </label>
                            <span class="invalid-feedback"><?php echo $phone_no_err; ?></span>
                        </div>
                        <span style="font-size: small;">(we will call you through this phone number)</span></br></br>

                        <input type="reset" value="Cancel" class="btn btn-primary mx-5 <?php echo (!empty($login_err) ? "disabled" : ""); ?>" />
                        <input type="submit" name="pay" class="btn btn-success <?php echo (!empty($login_err) ? "disabled" : ""); ?>" value="Pay" />

                </form>
                </br></br>
             
            </div> 
            </div>      
                <b>NOTE:</b> the amount paid here do not include the delivery fees. We will contact you to inform you on how to make the delivery payment.
                <p><i class="fas fa-phone-volume"></i>Tel: <u>0717734372</u> Call us if you experience any challenge. Thankyou</p>
        
        </br>
      
    </center>


    </br>
    <?php include "footer.php" ?>

</body>

</html>