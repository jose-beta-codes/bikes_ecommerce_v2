<?php
session_start();
require "piccsz.php";

if(isset($_SESSION["loggedin"]) && isset($_SESSION["id"]) && isset($_SESSION["username"])){

}







?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>account bicycle shop</title>
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
}


        </style>
</head>
<body>
<?php include "customer_header.php" ?>

</br>

<center><div><h2 style="text-decoration: underline double;" class="text-success"><b>My Account</b></h2></div></center>
<div class="container">
    <p>Welcome back, <?php echo (isset($_SESSION["username"])? $_SESSION["username"]: "customer" ); ?></p>
</div>
<div class="container">
<?php
// here check whether the user is logged in or not dispaly a login form if the user is not logged in else sisplay his account details''
if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
    $sql="SELECT id from $_SESSION[username];";
    $result=mysqli_query($conn, $sql);
    $rows_cart=mysqli_num_rows($result);
   


    $sql="SELECT id from customers WHERE username='$_SESSION[username]';";
    $result=mysqli_query($conn, $sql);
    $data=mysqli_fetch_assoc($result);
    $id=$data['id'];

    $sql_order="SELECT id FROM orders WHERE customer_id='$id';";
    $result_order=mysqli_query($conn, $sql_order);
    $rows_order=mysqli_num_rows($result_order);

    $sql="SELECT id FROM likes WHERE username='$_SESSION[username]';";
    $result_likes=mysqli_query($conn, $sql);
    $rows_likes=mysqli_num_rows($result_likes);


    echo "
    <div class='flex-container' style='margin:8px;'>
    <div class='card' style='max-width:500px; '>
        <div class='row g-0'>
            <div class='col-5' style='background: #868e96;'>
                <img src='logo.jpg' class='card-img-top h-100' alt='profile photo'>
            </div>
            <div class='col-7'>
                <div class='card-body'>
                    <center><p class='card-text'  style='margin:0 ;padding:0;'><u><b>$_SESSION[username]</b></u></p></center>
                    <p style='font-size: small; margin:0 ;padding:0;'>Dear customer we have quality bikes and accessories for you</p>
                    <p style='font-size: small; margin:0 ;padding:0;'><b><a href='home'>Go to home page</a></b></p>

                    <div style='font-size:small'>
                        <p style='margin:0 ;padding:0;'><b>Items in cart: $rows_cart</b></p>
                        <p style='margin:0 ;padding:0;'><b>Orders : $rows_order</b></p>
                        <p style='margin:0 ;padding:0;'><b>Total liked items: $rows_likes</b></p>
                    </div>
                      </div>

                     <center>
                    <div class='card-footer mt-3' style='width:100%; background:rgba(160, 160, 160, 0.548);'>
                    <p class='text-danger' style='font-size:small; '>cycle with us <b>@Zbikess</b></p>
                    </div>
                    </center>

                    
                </div>
            </div>
        </div>
      </div> </div><br>
      ";

   
      echo "<center>
      <div class='container d-flex justify-content-center'>
      <span style='float:left;'><form method='post' action='logout.php'>
          <button type='submit' name='logout' class='btn btn-danger mx-5'>Logout</button></form>
          </span
          <span style='float:right;'>
          <a href='home'><button class='btn btn-primary mx-5'><i class='fas fa-left-long'></i>Go home</button></a>
          </span>
      </div>
      </center>";

}else{
    echo "<center>
    <div class='container' style='width:95% ;'>
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login!</strong> login here see your account details and have a personalised experience  <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
    </div>
</center>";
}



?>



</div>



</br>
<?php include "footer.php" ?>
</body>
</html>