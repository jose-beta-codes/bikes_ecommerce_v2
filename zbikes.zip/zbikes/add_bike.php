<?php

$product_name= $image= $key_features= $description= $bike_size =$bike_weight = $bike_color= $condition= $price= $add_product="";
$product_name_err= $image_err= $key_features_err= $description_err= $bike_size_err=  $bike_weight_err =$bike_color_err= $condition_err= $price_err= $add_product_err="";
require "piccsz.php";

if(isset($_POST['submit'])){
    if(empty(trim($_POST["product_name"]))){
        $product_name_err="Please fill in the products name";
    }else{
        $product_name=trim($_POST['product_name']);
    }




    //next
    if(empty($_POST['key_features'])){
        $key_features_err="Input the product's key features";
    }else{
        $key_features=trim($_POST['key_features']);
    }

    if(empty($_POST['description'])){
        $description_err="Input the product description";
    }else{
        $description=trim($_POST['description']);
    }

    if(empty(trim($_POST['bike_size']))){
        $bike_size_err="Fill in the bike sizes available";
    }else{
        $bike_size=trim($_POST['bike_size']);
    }

    if(empty(trim($_POST['bike_weight']))){
        $bike_weight_err="Fill in the bike's total weight";
    }else{
        $bike_weight=trim($_POST['bike_weight']);
    }
   
    if(empty(trim($_POST['bike_color']))){
        $bike_color_err="Fill in the bike color";
    }else{
        $bike_color=trim($_POST['bike_color']);
    }

    if(empty($_POST['condition'])){
        $condition_err="Select the bikes condition";
    }else{
        $condition=$_POST['condition'];
    }

    if(empty(trim($_POST['price']))){
        $price_err="Enter the bikes price";
    }else{
        $price=trim($_POST['price']);
    }

    $stock="in stock";
    $product_likes="1";
    $ball_size="N/A";


    $filename=$_FILES['image']['name'];
    $filetmp_name=$_FILES['image']['tmp_name'];
    $filesize=$_FILES['image']['size'];
    $fileerror=$_FILES['image']['error'];
    $filetype=$_FILES['image']['type'];
    if(empty($filesize)){
        $image_err="Please select the image of the product";
    }else{
        

        if( $fileerror=="0"){
            //check where the file is an image use xplode function
            $filetypecheck=explode("/",$filetype);
            if($filetypecheck[0]=="image"){
                $filename_ar=explode(".", $filename);
                $file_ext=strtolower(end($filename_ar));//ready
                // $Actual_file_ext=".".$file_ext;
                $actual_filename=preg_replace('/.'.$file_ext.'/','${1}', $filename);
                //use actual_file_name and cartinate with username(this to be the location of the file in the db -> this is the name of the file in the folder)
                //but actual file name to be in separate coloumn in the db(refer to this when displaying its name and while downloading file)
                $unique_key=uniqid();
                $file_in_folder_name=$unique_key.".".$actual_filename.".".$file_ext;

                $file_destination="images/".$file_in_folder_name;
                $return=move_uploaded_file($filetmp_name, $file_destination);
                if($return== true){
                    //success...indert the product
//here the file_destination is ready now
                    $file_destination_final=$file_destination;
                    

                        //now ready to feed in  the db

                    if(empty($product_name_err) && empty($image_err) && empty($key_features_err) && empty($description_err) && empty($bike_size_err) && empty($bike_color_err) && empty($condition_err) && empty($price_err)){
                        $sql="INSERT INTO products(product_name, images, unique_key, key_features, description, price, product_condition,  bike_color, stock, product_likes, bike_size, ball_size, product_weight) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
                        if($stmt=mysqli_prepare($conn,$sql)){
                            mysqli_stmt_bind_param($stmt, "sssssssssssss", $param_name, $param_images, $param_unique, $param_keyf, $param_descr, 
                            $param_price, $param_condition,  $param_color, $param_stock, $param_productlikes, $param_bikesize, $param_ballsize, $param_bikeweight);
                            $param_name=$product_name;
                            $param_images=$file_destination_final;
                            $param_unique=$unique_key;
                            $param_keyf=$key_features;
                            $param_descr=$description;
                            $param_price=$price;
                            $param_condition=$condition;
                            $param_color=$bike_color;
                            $param_stock=$stock;
                            $param_productlikes=$product_likes;
                            $param_bikesize=$bike_size;
                            $param_ballsize=$ball_size;
                            $param_bikeweight=$bike_weight;


                            if(mysqli_stmt_execute($stmt)){
                            $add_product="
                            <div class='alert alert-success'>
                                <strong><i class='fas fa-check'></i> Success!</strong> Bike added to the customers page
                                </div>";
                                
                            }else{
                                $add_product_err="
                                <div alert alert-danger'>
                                <strong><i class='fas fa-xmark'></i> Failed!</strong> An error occurred, try again later
                                </div>";
                            }
                            mysqli_stmt_close($stmt);
                        }

                    }



                }else{
                    $image_err="Failed to upload the image, try again later";
                }


            }else{
                $image_err="Only image files are accepted";
            }
        

        }else{
            $image_err="Error retrieving the selected file. please try another file";
        }



    }




}else{
    echo "";
}

?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Add bike</title>
    <style>
        .text{
            display: flex;
            justify-content: flex-start;
            font-size: small;
        }
    </style>
</head>
<body>
    <?php include "admin_header.php";?>
    <center>
<div class="container">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"  enctype="multipart/form-data">
        <legend class="text-danger" style="text-decoration:underline double;"><h2>New Bike <i class="fas fa-bicycle"></i></h2></legend>
        <span class="text">add a new bike to the shop; fill in all fields</span>
        <h5 class="text-danger"><?php echo (!empty($add_product_err)) ? $add_product_err : ''; ?></h5>
        <h5 class="text-success"><?php echo (!empty($add_product)) ? $add_product : ''; ?></h5>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($product_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $product_name; ?>" id="product_name" placeholder="Enter product name"  name="product_name">
            <label for="product_name">Product name  NOTE: try to use not more than 3 words</label>
            <span class="invalid-feedback"><?php echo $product_name_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="file" class="form-control <?php echo (!empty($image_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $image; ?>" id="file" placeholder="product image"  name="image">
            <label for="file">Product image</label>
            <span class="invalid-feedback"><?php echo $image_err; ?></span>
            </div>


        <div class="form-group mb-3 mt-3">
            <textarea class="form-control <?php echo (!empty($key_features_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $key_features; ?>" id="textarea" rows="3" placeholder="key features of the bike (Use ## to represent bullets)"  name="key_features"></textarea>
            <span class="invalid-feedback"><?php echo $key_features_err; ?></span>
            </div>

        <div class="form-group mb-3 mt-3">
            <textarea  class="form-control <?php echo (!empty($description_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $description; ?>" id="textarea" rows="4" placeholder="product description (Use ## to represent bullets)"  name="description"></textarea>
            <span class="invalid-feedback"><?php echo $description_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($bike_size_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $bike_size; ?>" id="username" placeholder="Enter the bike size e.g 29 "  name="bike_size">
            <label for="username">Bike size e.g 26   NOTE:only numbers and decimals are allowed</label>
            <span class="invalid-feedback"><?php echo $bike_size_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($bike_weight_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $bike_weight; ?>" id="username" placeholder="Enter the total bike weight"  name="bike_weight">
            <label for="username">Bike weight (kg) e.g 15</label>
            <span class="invalid-feedback"><?php echo $bike_weight_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($bike_color_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $bike_color; ?>" id="color" placeholder="Enter the bike's color"  name="bike_color">
            <label for="color">Bike color</label>
            <span class="invalid-feedback"><?php echo $bike_color_err; ?></span>
            </div>

        <div class="form-group mb-3 mt-3">
            <select class="form-select <?php echo (!empty($condition_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $condition; ?>" id="condition" placeholder="Enter product condition i.e Brand new or used"  name="condition">
            <option>Brand new</option>
            <option>Used</option>
            </select>
            <span class="invalid-feedback"><?php echo $condition_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($price_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $price; ?>" id="price" placeholder="Enter price in Ksh"  name="price">
            <label for="price">Price in Ksh E.g 18,000</label>
            <span class="invalid-feedback"><?php echo $price_err; ?></span>
            </div>
         
        <input type="reset" class="btn btn-danger"  value="Reset" style="margin-right: 50px;">
        <input type="submit" class="btn btn-primary" name="submit" value="Add product">    

    </form>

</div>



</center>
 
</br>
<?php include "footer.php"; ?>
</body>
</html>