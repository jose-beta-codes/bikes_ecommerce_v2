<?php
header("Content-Type: application/json");

$stkCallbackResponse = file_get_contents('php://input');
$logFile = "stkResponse.json";
$log = fopen($logFile, "a");
fwrite($log, $stkCallbackResponse);



$callbackContent = json_decode($stkCallbackResponse);

$ResultCode = $callbackContent->Body->stkCallback->ResultCode;
$CheckoutRequestID = $callbackContent->Body->stkCallback->CheckoutRequestID;
$Amount = $callbackContent->Body->stkCallback->CallbackMetadata->Item[0]->Value;
$Transactioncode = $callbackContent->Body->stkCallback->CallbackMetadata->Item[1]->Value;
$PhoneNumber = $callbackContent->Body->stkCallback->CallbackMetadata->Item[4]->Value;
$TransactionDate = $callbackContent->Body->stkCallback->CallbackMetadata->Item[3]->Value;
$trans_ref = $callbackContent->Body->stkCallback->ExternalReference;



$transaction_status="failed";
    if ($ResultCode == 0) {
        $transaction_status="completed";
        $order_status="0";
        require "piccsz.php";  

    $sql="SELECT full_name, customer_location, customer_id, pre_order_key, product_name, quantity, product_key FROM pre_orders WHERE pre_order_key=?";
    if($stmt=mysqli_prepare($conn, $sql)){
       
        mysqli_stmt_bind_param($stmt, "s", $param_key);
        $param_key=$trans_ref;
        if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_bind_result($stmt, $param_name, $param_location, $param_id, $param_pre_key, $param_product_name, $param_quantity, $param_item_key);
                mysqli_stmt_fetch($stmt);
                $full_name=$param_name;
                $location=$param_location;
                $customer_id=$param_id;
                $preorderkey=$param_pre_key;
                $product_name=$param_product_name;
                $quantity=$param_quantity;
                $item_key=$param_item_key;

                mysqli_stmt_close($stmt);
            $sql="INSERT INTO orders(product_name, customer_id, customer_name, customer_location, quantity, resultcode, amount, transaction_code, transaction_date, phone_no, item_key, transaction_status, order_status) 
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
            if($stmtt=mysqli_prepare($conn, $sql)){
                mysqli_stmt_bind_param($stmtt,"sssssssssssss", $param_name, $param_order_details, $param_full_name, $param_location, $param_quantity, $param_resultcode, $param_amount, $param_transactioncode, $param_transactiondate, $param_phoneno, $param_orderdetail_key, $param_transaction_status, $param_order_status);
                $param_name=$product_name;
                $param_order_details=$customer_id;
                $param_full_name=$full_name;
                $param_location=$location;
                $param_quantity=$quantity;
                $param_resultcode=$ResultCode;
                $param_amount=$Amount;
                $param_transactioncode=$Transactioncode;
                $param_transactiondate= $TransactionDate;
                $param_phoneno=$PhoneNumber;
                $param_orderdetail_key=$item_key;
                $param_transaction_status=$transaction_status;
                $param_order_status=$order_status;

                
            if(mysqli_stmt_execute($stmtt)){
                
                $sql="UPDATE products SET stock='sold out' WHERE unique_key=?";
                if($stmttt=mysqli_prepare($conn, $sql)){
                mysqli_stmt_bind_param($stmttt, 's', $param_key);
                $param_key=$item_key;
                if(mysqli_stmt_execute($stmttt)){

                    $sql="DELETE FROM pre_orders WHERE pre_order_key='$preorderkey';";
                    mysqli_query($conn, $sql);
                  
                    
                    mysqli_stmt_close($stmttt);
                        }
                    }
                }mysqli_stmt_close($stmtt);
            }
        

  
    }else{
    echo "Error recording the transaction";
    }
    }

}else{
    

}
fclose($log);
