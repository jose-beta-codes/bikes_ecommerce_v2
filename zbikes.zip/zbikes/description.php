<?php
session_start();
require "piccsz.php";


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Description</title>
</head>
<body>

<?php include "customer_header.php"; ?> 
<center>
<div class="container">
    <h2 class="text-primary" style="text-decoration:underline double"><b>Description</b></h2>
</div>
</center>
</br>
<div class="container">
<?php
$sql="SELECT product_name, description FROM products  WHERE unique_key='$_SESSION[clicked_item]';";
$result=mysqli_query($conn, $sql);
$data=mysqli_fetch_assoc($result);
$name=$data['product_name'];
$description=$data['description'];


$str = $description;
$arr= explode("##",$str);
$count= count($arr);

echo "<h3 class='mx-3'><u><i>$name</i></u></h3>";

if(isset($arr)){
    echo "<ul>";
    $arr_count=-1;
    for($i=0;$i<$count;$i++){
        $arr_count++;
		if(empty($arr[$arr_count])){
          	echo "";
        }else{
        echo "<li>".$arr[$arr_count];
        echo "</br>";
        }
        echo "</ul>";
        
    }

}

?>

</div>
</br>

<div class="container">
</div>
</br>
<center>
    <a href="product" class="mx-5"><button class="btn btn-primary"> <i class="fas fa-left-long"></i> Go back </button></a>
    <a href="happy_customers"><button class="btn btn-outline-success"><i class="fas fa-circle-check text-success"></i> See our satisfied customers</button></a>

</center>

</br>
<?php include "footer.php"; ?>
</body>
</html>