<?php
session_start();
require "piccsz.php";
//unset($_SESSION['clicked']);

$login_err= $login_true="";

    $sql="SELECT deadline, warning_date FROM subscription ORDER BY id DESC LIMIT 1;";
    if($stmt=mysqli_prepare($conn, $sql)){
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt)>0){
                mysqli_stmt_bind_result($stmt, $param_deadline, $param_warning);
                mysqli_stmt_fetch($stmt);
                $deadline=$param_deadline;
                $warning_date=$param_warning;
                $deadline_check=new DateTime($deadline);
                $warning_check=new DateTime($warning_date);
                $currentt=date("Y-m-d");
                $current=new DateTime($currentt);
                if($current>$deadline_check){
                    header("location: error.php");
                }

            }else{
                header("location:  error.php");
            }
        }
        mysqli_stmt_close($stmt);
    }


if(isset($_POST['see_product'])){
    $serial=$_POST['serial'];
    $unique_key=$_POST['unique_key'];
    
    $_SESSION['clicked_item']=$unique_key;
    header("location: product");
   
   
}

if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
    $login_true="<i class='fas fa-circle-check text-success'> </i> <span style='font-size:x-small'>  logged in</span>";
}else{
    $login_err="
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login!</strong> please login here  <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
      ";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>bicycle shop index</title>
    <style>
.flex-container {
  display: flex;
  justify-content: space-between;
}

.flex-container > div {
  text-align: center; 
}

.text{
    display: flex;
font-size: small;
  
    letter-spacing: 0.2rem;
}

.text >div {
    animation: bounce 0.5s ease-in-out alternate infinite;
    animation-delay: calc(0.1s * var(--i));
}

@keyframes bounce{
    to{
        transform: translateY(0.5rem);
    }
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark" aria-label="Offcanvas navbar large">
        <div class="container-fluid">

        <a class="navbar-brand">
            <img src="logo.jpg" alt="Logo" style="width:50px;" class="rounded-pill">
        </a>

        <span class="text-light " style="font-weight: bold;"><i class="fas fa-bicycle"></i> Bicycle shop</span>

        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="offcanvas offcanvas-end text-white bg-dark" tabindex="-1" id="offcanvasNavbar2" aria-labelledby="offcanvasNavbar2Label">
            <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbar2Label">Bicycle shop <i class="fas fa-bicycle"></i></h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="home"> <button class="btn btn-outline-primary" style="text-decoration: underline double red;"><i class="fas fa-house-user"></i> Home</button></a>
                </li>
                <li class="nav-item">
                <a class="nav-link " href="cart"><button type="button" class="btn  btn-primary"  data-bs-toggle="tooltip" title="Programming career and projects"> <i class="fas fa-cart-arrow-down"></i> My Cart</button></a>
                </li>

                <li class="nav-item">
                <a class="nav-link active  " aria-current="page" href="orders"> <button class="btn btn-outline-danger"><i class="fas fa-truck-fast"></i> My Orders</button></a>
                </li>

               
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="offcanvasNavbarLgDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="true">
                    <button class="btn btn-danger"> <i class="fas fa-bars"></i> Menu</button>
                </a>
                <ul class="dropdown-menu" aria-labelledby="offcanvasNavbarLgDropdown" style="background-image:linear-gradient(to bottom, dodgerblue , grey);">
                <li><a href="account"  style="text-decoration:none ;"><button style="border:none;" type="button"  data-bs-toggle="modal" data-bs-target="#mylife" class="dropdown-item btn" ><i class="fas fa-user"></i> My account</button></a></li>
                <li><a href="https://maps.app.goo.gl/3NTeE3XcAgUJQo3BA" style="text-decoration: none;"><button style="border:none;" type="button"  data-bs-toggle="modal" data-bs-target="#mylife" class="dropdown-item btn" ><i class="fas fa-map-location-dot"></i> Shop location and directions</button></a></li>
                    <!-- <li><button type="button" data-bs-toggle="modal" data-bs-target="#education" class="dropdown-item btn">Contacts</button></li> -->
                    <li><a href="happy_customers" style="text-decoration: none;"><button type="button" class="dropdown-item"><i class="fas fa-circle-check"></i> Happy customers</button></a></li>

                    <li>
                    <hr class="dropdown-divider">
                    </li>
                    <li><a href="notifications_and_offers" style="text-decoration: none;"><button  class="dropdown-item btn" ><i class="fas fa-star-half" style="color:orange;"></i>Offers and notifications</button></a></li>
                    <li><a href="about"  style="text-decoration:none ;"><button type="button"  class="dropdown-item btn" >About Us</button></a></li>
                    <li><button type="button" data-bs-toggle="modal" data-bs-target="#contact" class="dropdown-item btn" >Contact</button></li>
                    <?php echo (isset($_SESSION["username"])? "<li><form method='post' action='logout'><button type='submit' name='logout'data-bs-toggle='modal' data-bs-target='contact' class='dropdown-item btn' ><i class='fas fa-door-open'></i> Logout</button></form></li>": ""); ?>
                </ul>
                </li>
            </ul>
            </div>
        </div>
        </div>
    </nav>

<div class="container-fluid">
<p>welcome to our bicycle shop, located at <b>Hospital Street at pantaloon ent, Mombasa Kenya</b></p>
</div>

<div class="container" >
<form method="post" action="" class="d-flex">
<?php echo (!empty($login_true)? $login_true." ": ""); ?>
    <input class="form-control me-2" type="search" placeholder="Search" name="saka">
    <button class="btn btn-outline-success" type="submit" name="seek">Search</button>
 </form>
</div>

<?php 
if(isset($_POST['seek'])){
    $search=mysqli_real_escape_string($conn,$_POST['saka']);

    $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products WHERE product_name LIKE ?;";
    if($stmt=mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "s", $param_search);
        $param_search='%'.$search.'%';
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt)>0){
                $rows=mysqli_stmt_num_rows($stmt);
                echo "</br>
                <div class='container-fluid bg-danger' style='background-image:linear-gradient(to right, dodgerblue, rgba(220, 35, 35, 0.82))'>
                <p class='text-white' style='padding-left:8px;'><b>Results from your search</b></p>
                </div>
                
                <div class='container'>
        
                <div class='row gy-3'>
               
                
                ";
                for($i=0; $i<$rows; $i++){
                mysqli_stmt_bind_result($stmt, $par_name, $par_image, $par_key, $par_features, $par_desc, $par_condition, $par_color, $par_price, $par_stock, $par_size, $par_weight);
                mysqli_stmt_fetch($stmt);

                $name=$par_name;
                $image_path=$par_image;
                $unique_key=$par_key;
                $key_features=$par_features;
                $description=$par_desc;
                $product_condition=$par_condition;
                $color=$par_color;
                $price=$par_price;
                $stock=$par_stock;
                $size=$par_size;
                $weight=$par_weight;

                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;

                $stock_out=(!($stock=="in stock")? "Sold out": "");
                $padding=(!($stock=="in stock")? "padding:3px;": "");

               
             
            
            echo "
            
            <div class='col-6 col-md-4 col-lg-3'>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo'  class='rounded-top'>
                <$tag class='px-2 mt-1'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>
                        <div class='mt-auto pb-3'>
                        <center>
                            <form method='POST' action=''>
                                <input type='hidden' name='unique_key' value='$unique_key'/>
                                <input type='submit' name='see_product' value='See more' class='btn btn-danger rounded-pill'/>
                            </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;' class='rounded-bottom' ><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";
            }
            echo "</div> </div>";

            }else{
                echo "</br><center>
                <div class='container' style='width:95%;'>
                <div class='alert alert-primary alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>No results! </strong> we could not find the item you searched, try another search
              </div>
                </div>
            </center>";
            }
        }mysqli_stmt_close($stmt);
    }

}

?>



<!-- modal -->
<div class="modal" id="contact">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Contact Us</h4>
        
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <center>
        <b>You can reach us through the following contacts</br>call us: <u>0717734372</u></b>
</br><small>use this links to see our social media </small><h1>&#128578</h1>

              <a  href="https://www.instagram.com/invites/contact/?i=zwvi3q5xee6j&utm_content=nr51ctr" ><b><i class="fab fa-instagram" style="color:rgba(245, 34, 118, 0.67);""></i><span style="color:rgba(245, 34, 118, 0.67);"> Instagram</span></b></a></br>
              <a  href="https://m.facebook.com/story.php?story_fbid=pfbid02aAzTopvwhrQVxJcdih7cLLko9GtyfG4Gqcm9iS2xLtcMCvJ3Qsw3sfWELmrnZBWAl&id=100075273326784"><b><i class="fab fa-facebook text-primary"></i><span style="color:dodgerblue"> Facebook</span></b></a></br>
              <a href="https://wa.me/+254717734372?text=Hello%20ZBIKESS%20i%20saw%20this%20on%20your%20site," class=""><b><i class="fab fa-whatsapp text-success"></i><span class="text-success"> Whatsapp</span></b></a></br>
              <a href="tel:0717734372" class="text-primary"><b><i class="fas fa-phone-volume"></i><span> Call us</span></b></a></br>
        </center>
      </div>

    </div>
  </div>
</div>

<!-- end modal -->

</br>
<center>
<div class="container" style="width:95% ;">
<?php echo (isset($login_err)? $login_err: ""); ?>
<?php
// here check whether the user is logged in or not dispaly a login form if the user is not logged in else sisplay his account details''




?>
</div>
</center>

<!-- <div class="container-fluid">
    <p class="text-white" style="padding-left:8px;background-image:linear-gradient(to right, dodgerblue , grey);"><center><span style="float:middle;">notification</span></center><span style="float: right;padding-right:10px; color:gold;"><i class="fas fa-bicycle"></i></span></p>
</div> -->
<div class="flex-container text-light" style="padding-left:8px;background-image:linear-gradient(to right, dodgerblue , grey);">
  <div style="padding-left:8px; "><b>Top new</b></div>
  <div>
    <a href="notifications_and_offers" style="text-decoration: none;">
  <div class="text text-light">
        <div style="--i:1 ;color:red;"><i class="fas fa-paper-plane"></i></div>
        <div style="--i:2;">& </div>
        <div style="--i:3;">offers</div>
        
    </div></a>
</div>
  <div><span style="float: right;padding-right:10px; color:gold;"><i class="fas fa-bicycle"></i></span></div>  
</div>

</br>
<section class="d-flex justify-content-center align-items-center h-100 min-vh-100">


<div class="container" >
        
        <div class="row gy-3 ">




        <?php
            //load the data from db and display in cards: name, image, key-features (3) , condition, price, stock
         $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products ORDER BY id DESC LIMIT 8;";
         $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
       
        if($rows > 0){
            $serial=0;
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                $weight=$row['product_weight'];
           
                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;

                $stock_out=(!($stock=="in stock")? "Sold out": "");
                $padding=(!($stock=="in stock")? "padding:3px;": "");

                $price=number_format($price);
             
            
            echo "
            
            <div class='col-6 col-md-4 col-lg-3'>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo'  class='rounded-top'>
                <$tag class='px-2 mt-1'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>
                        <div class='mt-auto pb-3'>
                        <center>
                            <form method='POST' action=''>
                                <input type='hidden' name='serial' value='$serial'/>
                                <input type='hidden' name='unique_key' value='$unique_key'/>
                                <input type='submit' name='see_product' value='See more' class='btn btn-danger rounded-pill'/>
                            </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;' class='rounded-bottom' ><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";
               
            }
            }else{
                echo " <div class='alert alert-danger'>
                <strong><i class='fas fa-xmark'></i> No data!! </strong> Oops! nothing is uploaded here yet, come back later
                </div>";
            }
?>





           
        </div>
        
    </div>
    </section>
        </br>
    <div class="container-fluid" style="background-image:linear-gradient(to right, dodgerblue, rgba(220, 35, 35, 0.82))">
    <p class="text-white" style="padding-left:8px; "><b>Top selling</b></p>
    </div>
    <section class="d-flex justify-content-center align-items-center h-100 min-vh-100">


    <div class="container" >
        
        <div class="row gy-3 ">
        <?php
            //load the data from db and display in cards: name, image, key-features (3) , condition, price, stock
         $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products ORDER BY   RAND();";
         $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
        if($rows > 0){
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                $weight=$row['product_weight'];
                
                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;

                $stock_out=(!($stock=="in stock")? "Sold out": "");
                $padding=(!($stock=="in stock")? "padding:3px;": "");

                $price=number_format($price);
                
            echo "
            
            <div class='col-6 col-md-4 col-lg-3 '>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo'  class='rounded-top'>
                <$tag class='px-2 mt-1'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>
                        <div class='mt-auto pb-3'>
                        <center>
                            <form method='POST' action=''>
                                <input type='hidden' name='unique_key' value='$unique_key'/>
                                <input type='submit' name='see_product' value='See more' class='btn btn-danger rounded-pill'/>
                            </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;'  class='rounded-bottom'><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";   
            }
            }else{
                echo " <div class='alert alert-danger'>
                <strong><i class='fas fa-xmark'></i> No data!! </strong> Oops! nothing is uploaded here yet, come back later
                </div>";
            }
?>



        </div>
        
    </div>
    </section>
    



    </br>
<?php include "footer.php"; ?>
</body>
</html>