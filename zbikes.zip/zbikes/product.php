<?php
Session_start();
require "piccsz.php";

$no_session= $liked= $likes=$like_message="";

        if(isset($_SESSION['clicked_item'])){
            if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
            //record the clicks
            $click="SELECT username FROM clicks WHERE unique_key='$_SESSION[clicked_item]' AND username='$_SESSION[username]';";
            $resultant=mysqli_query($conn, $click);
            $rowzz=mysqli_num_rows($resultant);
            if($rowzz>0){
                $click_update="UPDATE clicks SET number_clicks=number_clicks +1 WHERE username='$_SESSION[username]' AND unique_key='$_SESSION[clicked_item]';";
                $result_up=mysqli_query($conn, $click_update);


            }else{
                $click_first_value="1";
                $click_first="INSERT INTO clicks(username, unique_key, number_clicks)
                VALUES('$_SESSION[username]', '$_SESSION[clicked_item]', '$click_first_value');";
                mysqli_query($conn, $click_first);
            }
        }
            
            //load the data from db and display in cards: name, image, key-features (3) , condition, price, stock
         $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products WHERE unique_key='$_SESSION[clicked_item]' ORDER BY id DESC LIMIT 8;";
         $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
       
        if($rows > 0){
            $serial=0;
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                $weight=$row['product_weight'];

                $price=number_format($price);


              }
            
    
    
                }

                
            if(isset($_POST['see_product'])){
                $serial=$_POST['serial'];
                $unique_key=$_POST['unique_key'];
                
                $_SESSION['clicked_item']=$unique_key;
                header("location: product");
               
               
            }else{
                echo "";
            }

            if(isset($_POST['Add_to_cart'])){
                $item_key=$_POST['item_key'];
                $quantity=$_POST['quantity'];
                $_SESSION['add_to_cart']=$item_key;
                $_SESSION['quantity']=$quantity;
                header("location: cart");
            }

            if(isset($_POST['Order_now'])){
                $_SESSION['clicked_item_order_now']=$_POST['item_key'];
                $_SESSION['clicked_item_quantity_order_now']=$_POST['quantity'];
                $_SESSION['page']="1";
                header("location: order-now");
            }



            if(isset($_POST['like'])){
                $date_liked=date("l jS \of F Y h:i:s A");
                if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){

                $sqll="SELECT username FROM likes WHERE unique_key='$_SESSION[clicked_item]' AND username='$_SESSION[username]';";
                $results=mysqli_query($conn, $sqll);
                $rowz=mysqli_num_rows($results);
                if($rowz>0){
                    $like_message="<div class='alert alert-success alert-dismissible fade show'>
                    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                    <strong><i class='fas fa-thumbs-up text-danger'></i> Already Liked!</strong> You already liked this product earlier. Thanks for your time!
                    </div>";

                }else{
                    $sql="INSERT INTO likes (product_name, username, unique_key, date_liked)
                    VALUES('$name', '$_SESSION[username]', '$_SESSION[clicked_item]', '$date_liked');";
                    $result=mysqli_query($conn, $sql);
                    if($result){
                        $like_message="<div class='alert alert-success alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong><i class='fas fa-thumbs-up text-danger'></i> Liked!</strong> Hooray! item liked successifully.
                        </div>";
                    }
                }
            }else{
                $like_message="
                <div class='alert alert-primary alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Login!</strong> please login here first to be able to like items <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
              </div>
                  ";
            }
        }
            
            }else{
               $no_session="Error no item is clicked go to index page and click see more button on the available products";
            }


?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <title><?php echo (isset($_POST['see_product'])? $_POST['product_name']: 'bicycle shop'); ?></title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script> 

    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">

    <style>
  .flex-container{
    display: flex;
  flex-flow: row nowrap;
  overflow-x: auto ;
  }
  .flex-container > div {
    margin: 10px;
  }
</style>
</head>
<body>
    <?php
    include "customer_header.php";
    ?>
    </br>
    <div class="container" >
<form method="post" action="" class="d-flex">
<?php echo (!empty($login_true)? $login_true." ": ""); ?>
    <input class="form-control me-2" type="search" placeholder="Search" name="saka">
    <button class="btn btn-outline-success" type="submit" name="seek">Search</button>
 </form>
</div>

<?php 
if(isset($_POST['seek'])){
    $search=mysqli_real_escape_string($conn,$_POST['saka']);

    $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products WHERE product_name LIKE ?;";
    if($stmt=mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, "s", $param_search);
        $param_search='%'.$search.'%';
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt)>0){
                $rows=mysqli_stmt_num_rows($stmt);
                echo "</br>
                <div class='container-fluid bg-danger' style='background-image:linear-gradient(to right, dodgerblue, rgba(220, 35, 35, 0.82))'>
                <p class='text-white' style='padding-left:8px;'><b>Results from your search</b></p>
                </div>
                
                <div class='container'>
        
                <div class='row gy-3'>
               
                
                ";
                for($i=0; $i<$rows; $i++){
                mysqli_stmt_bind_result($stmt, $par_name, $par_image, $par_key, $par_features, $par_desc, $par_condition, $par_color, $par_price, $par_stock, $par_size, $par_weight);
                mysqli_stmt_fetch($stmt);

                $name=$par_name;
                $image_path=$par_image;
                $unique_key=$par_key;
                $key_features=$par_features;
                $description=$par_desc;
                $product_condition=$par_condition;
                $color=$par_color;
                $price=$par_price;
                $stock=$par_stock;
                $size=$par_size;
                $weight=$par_weight;

                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;

                $stock_out=(!($stock=="in stock")? "Sold out": "");
                $padding=(!($stock=="in stock")? "padding:3px;": "");

                $price=number_format($price);
             
            
            echo "
            
            <div class='col-6 col-md-4 col-lg-3'>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo'  class='rounded-top'>
                <$tag class='px-2 mt-1'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>
                        <div class='mt-auto pb-3'>
                        <center>
                            <form method='POST' action=''>
                                <input type='hidden' name='unique_key' value='$unique_key'/>
                                <input type='submit' name='see_product' value='See more' class='btn btn-danger rounded-pill'/>
                            </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;' class='rounded-bottom' ><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";
            }
            echo "</div> </div>";

            }else{
                echo "</br><center>
                <div class='container'>
                <div class='alert alert-primary alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>No results! </strong> we could not find the item you searched, try another search
              </div>
                </div>
            </center>";
            }
        }mysqli_stmt_close($stmt);
    }

}

?>
</br>   
<center>
<div class="container">
    <?php echo(!empty($like_message)? $like_message: ""); ?>
    <?php echo(!empty($no_session)? $no_session: ""); ?>
</div>
</center>

    <!-- two cards here  ; 1. image 2. name, keyf, price, stock, condition-->
   <section class="d-flex justify-content-center align-items-center">

    
    <div class="container">
        <div class="row g-3">

            <div class="col-12 col-md-6 col-lg-6">
                <center>
                    <div class="box h-100 d-flex  flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
                       
                        
                        <div id="product" class="carousel slide" data-bs-ride="carousel">

                        <!-- Indicators/dots -->
                        <div class="carousel-indicators">
                        <button type="button" data-bs-target="#product" data-bs-slide-to="0" class="active"></button>
                        <?php 
                            $dir="add_images/".$_SESSION['clicked_item'];
                            $corousel_img=glob($dir."/*" );
                            $count=0;
                            foreach($corousel_img as $imgs){
                              $count++;  
                            echo "<button type='button' data-bs-target='#product' data-bs-slide-to='$count'></button> ";     
                            }
                        ?>
                        <!-- <button type="button" data-bs-target="#product" data-bs-slide-to="1"></button>
                        <button type="button" data-bs-target="#product" data-bs-slide-to="2"></button> -->
                        </div>

                        <!-- The slideshow/carousel -->
                        <div class="carousel-inner">
                        <div class="carousel-item active">
                        <img src="<?php echo(isset($_SESSION['clicked_item'])? $image_path: '');?>"  alt="product photo" class="d-block" style="width:100%">
                        </div>

                        <!-- here a loop to get the other images if there is -->
                        <?php
                        if(isset($_SESSION['clicked_item'])){
                            $dir="add_images/".$_SESSION['clicked_item'];
                            
                            $corousel_img=glob($dir."/*" );

                           // echo $corousel_img;
                            foreach($corousel_img as $imgs){
                                    echo "<div class='carousel-item'>
                                    <img src='$imgs' alt='Chicago' class='d-block' style='width:100%'>
                                </div>";
                                
                            }

                        }
                       



                        ?>
                      
                        <!-- <div class="carousel-item">
                            <img src="corousel images\zbikess.ke-20220811-0095.jpg" alt="New York" class="d-block" style="width:100%">
                        </div> -->
                        <!-- <div class="carousel-item">
                            <video src="corousel images\zbikess.ke-20220811-0002.mp4" alt="New York" class="d-block" style="width:100%"></video>
                        </div> -->
                        </div>

                        <!-- Left and right controls/icons -->
                        <button class="carousel-control-prev" type="button" data-bs-target="#product" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#product" data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span>
                        </button>
                        </div>




                        </div>
                </center>
                </div>

                <div class="col-12 col-md-6 col-lg-6 ">
                    <div class="box h-100 d-flex p-3 flex-column rounded" style='background-color: rgba(103, 100, 100, 0.274);'>
                        
                        <h3><?php echo(isset($_SESSION['clicked_item'])? $name: '');?></h3>
                        <p class="mb-0">
                        <p><h5><u> Features</u></h5></p>
                    <?php
                        $str=$key_features;
                                
                        $arr= explode("##",$str);
                        $count= count($arr);

                        if($count>=3){
                            $show=3;
                        }else{
                            $show=$count;
                        }
                        if(isset($arr)){
                            echo "<ul>";
                            $arr_count=-1;
                            for($i=0;$i<=$show;$i++){
                                $arr_count++;
                                if(empty($arr[$arr_count])){
                                        echo "";
                                }else{
                                echo "<li>".$arr[$arr_count];
                        
                                }
                                
                            }
                            echo "</ul>";
                        
                        }
                
                    ?>
                     
                            <small style='background-image:linear-gradient(to right, dodgerblue , grey); padding:5px; width:fit-content;' class="rounded-pill"><b>Colour: </b><?php echo(isset($_SESSION['clicked_item'])? $color : '');?> <b>Size: </b> <?php echo(isset($_SESSION['clicked_item'])? $size." inches": ""); ?> <b>Weight: </b> <?php echo(isset($_SESSION['clicked_item'])? $weight." KGs": ""); ?></small> </br>
                        <h4><b>Ksh <?php echo(isset($_SESSION['clicked_item'])? $price: '');?></b></h4>
                        <div><p>


                            <div class="rounded-end" style="width: fit-content; padding-right: 3px; float:left;background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;">
                                    <p class="text-white"> <?php echo(isset($_SESSION['clicked_item'])? "<i class='fas fa-star ms-2' style='padding-right:5px;color:gold;'></i>".$product_condition."  ". $stock: ''); ?>
                                    
                                </p>
                            </div>
                            <div style="float:right;padding-inline-end: 10%;">
                            <?php
                                $sql="SELECT id FROM likes WHERE unique_key='$_SESSION[clicked_item]';";
                                $result=mysqli_query($conn, $sql);
                                $rows=mysqli_num_rows($result);
                                if($rows>0){
                                    $likes=$rows;
                                    //check if the user had liked the item ? else allow him to like add him in db
                                    if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
                                    $sqll="SELECT username FROM likes WHERE unique_key='$_SESSION[clicked_item]' AND username='$_SESSION[username]';";
                                    $results=mysqli_query($conn, $sql);
                                    $rowz=mysqli_num_rows($results);
                                    if($rowz>0){
                                        $liked="true";
                                    }else{
                                        $liked="";
                                    }
                                    }
                                    
                                }else{
                                    $likes="";
                                }

                                ?>
                                <span  class="ml-2">
                                
                                    <label class="text-danger" style="font-weight: bold;">like<?php echo(!empty($liked)? 'd': ''); ?> </label>
                                    <button  class="btn  btn-<?php echo(!empty($liked)? '': 'outline-');?>danger" data-bs-toggle="modal" data-bs-target="#like"> <i class="fas fa-thumbs-up" ></i></button><?php echo(isset($likes)? " ".$likes : ""); ?>
                                
                                </span>
                            </div>
                            </p>
                    </div>

                            <center class="mt-auto"><p>

                                <div>
                                    <span style="float:right; padding-inline-end: 1%;">
                                    <form method="POST" action="">
                                    <input type='hidden' name='item_key' value='<?php echo (isset($_SESSION['clicked_item'])? $unique_key: ''); ?>'/>
                                    <input type="hidden" name="quantity" value="1"/>
                                        <button type="submit" name="Order_now" class="btn btn-success btn-sm"><b>Order now</b></button>
                                    </form>
                                    </span>
                                </div>

                                <div>
                                    <span style="float:left; padding-inline-start: 1%;">
                                    <form method="POST" action="">  
                                    <input type='hidden' name='item_key' value='<?php echo (isset($_SESSION['clicked_item'])? $unique_key: ''); ?>'/>
                                    <label>pieces</label>
                                    <input type='number' name='quantity' value='1' min="1" placeholder="no. of pieces" style="width:40px; margin-right: 7px;"/>
                                    <button type="submit" name="Add_to_cart" class="btn btn-danger btn-sm"><i class="fas fa-cart-plus" ></i> <b>Add to cart</b></button>
                                    </form>
                                    </span>
                                </div>  
                                </p>
                            </center>
                   
                        </p >
                        </div>
                        

                </div>
            </div>

        </div>


    
    </section>



    <div class="modal" id="like">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Like this item</h4>
        
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <center>
        <form method="POST" action="">
            <label class="text-danger">Like </label>
            <button type="submit" name="like" class="btn btn-outline-danger"><i class="fas fa-thumbs-up"></i></button>
        </form>
        </center>
      </div>

    </div>
  </div>
</div>






                </br>
    <div class="container" style="width: 95%; background-color:rgba(103, 100, 100, 0.274);">
        <h4>Description</h4>
        <div style="margin-bottom:15px;">
        <span style="float:right;">
                        <a href="description" class="mb-3"> <button class="btn btn-primary btn-sm"> <b>more description</b></button></a>
                    </span>
                </div>
                    <div>
                        <?php

                $str=$description;
                                            
                $arr= explode("##",$str);
                $count= count($arr);

                if($count>=3){
                    $show=1;
                }else{
                    $show=$count;
                }   
                if(isset($arr)){
                    echo "<ul>";
                    $arr_count=-1;
                    for($i=0;$i<=$show;$i++){
                        $arr_count++;
                        if(empty($arr[$arr_count])){
                                echo "";
                        }else{
                        echo "<li style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;'>".$arr[$arr_count];

                        }
                        
                    }
                    echo "</ul>";

                }

                ?>
                    </div>


    </div>

    <div class="container" style="width: 95%; background-color:rgba(103, 100, 100, 0.274); padding:7px;">
        <p><b>Delivery services:</b> Delivery is done across the country; it takes 1 day.</p>
    </div>
</br>
    <div class="container" >
        <p class="bg-success text-white px-2"><b>Recommended</b></p>
    </div>
    <div class="container">
        <div class="flex-container">

        <?php
        //script to get 4 card filled up
        $sql="SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products  ORDER BY   RAND()  LIMIT 8;";
        $result=mysqli_query($conn, $sql);
        $rows=mysqli_num_rows($result);
        if($rows > 0){
            for($i=0; $i<$rows; $i++){
                $row=mysqli_fetch_assoc($result);
                $name=$row['product_name'];
                $image_path=$row['images'];
                $unique_key=$row['unique_key'];
                $key_features=$row['key_features'];
                $description=$row['description'];
                $product_condition=$row['product_condition'];
                $color=$row['bike_color'];
                $price=$row['price'];
                $stock=$row['stock'];
                $size=$row['bike_size'];
                $weight=$row['product_weight'];

                $tag="";
                $final_name=strlen($name);
                if($final_name<=16){
                    $tag="h4";
                }else{
                    $tag="h5";
                }
                $keyf=explode("##", $key_features);
                $count=count($keyf);
                $key1=($count>0? $keyf[0]." ": "");
                $key2=($count>1? $keyf[1]." ": "");
                $key3=($count>2? $keyf[2]." ": "");
                $key4=($count>3? $keyf[3]." ": "");
                $allkeyf=$key1.$key2.$key3.$key4;

                $stock_out=(!($stock=="in stock")? "Sold out": "");
                $padding=(!($stock=="in stock")? "padding:3px;": "");
                $price=number_format($price);
            
            echo "
            
            <div class='col-6 col-md-3 col-lg-3 '>
            <div class='card h-100 d-flex flex-column rounded' style='background-color: rgba(103, 100, 100, 0.274);'>
                <img src='$image_path' alt='product photo' >
                <$tag class='px-2 mt-1'>$name</$tag>
                        <p style='white-space: nowrap;overflow: hidden;text-overflow: ellipsis;' class='px-4'><small>$allkeyf</small></p>


                        <p class='px-2'><b>Ksh $price</b></p>
                        <span class'mx-auto'><p class='text-white' style='background-image:linear-gradient(to right, dodgerblue , red); font-size: x-small;'><b><i class='fas fa-star' style='padding-right:5px;color:gold; float:left; padding-left:8px;'></i> $stock</b> <span style='float:right; padding-right: 8px;'><i class='fas fa-bicycle' style='color:gold;'></i> $product_condition</span></p></span>                        <div class='mt-auto pb-3'>
                        <center>
                        <form method='POST' action=''>
                            <input type='hidden' name='serial' value='$serial'/>
                            <input type='hidden' name='unique_key' value='$unique_key'/>
                            <input type='submit' name='see_product' value='See more' class='btn btn-danger rounded-pill'/>
                        </form>
                            </center>
                            </div>
                            <small class='bg-danger text-light' style=' float:left; font-size:x-small;width:fit-content;$padding'><b>$stock_out</b></small>

                            <div style='background-image:linear-gradient(to right, dodgerblue , grey); font-size:x-small;'  class='rounded-bottom'><small  style='padding:5px; float:left;'><b>Colour: </b>$color</small> <small style='padding:5px; float:right;'><b>Size: </b>$size inches</small></div>
                        

                </div>
            </div>
            ";   
            }
            }else{
                echo " <div class='alert alert-danger'>
                <strong><i class='fas fa-xmark'></i> No data!! </strong> Oops! nothing is uploaded here yet, come back later
                </div>";
            }





        ?>

        
     
    </div>
    </div>
    </br>
    <?php
    include "footer.php";
    ?>
</body>
</html>