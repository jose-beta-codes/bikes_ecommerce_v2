<?php
session_start();
require_once "piccsz.php";
$full_name= $username= $email= $passkey= $confirm_passkey="";
$full_name_err= $username_err= $email_err= $passkey_err= $confirm_passkey_err="";

if($_SERVER["REQUEST_METHOD"]=="POST"){


    if(empty(trim($_POST['full_name']))){
        $full_name_err="Please enter your full name!";

    }
    else{
        $full_name=trim($_POST['full_name']);
    }

    if(empty(trim($_POST["username"]))){
        $username_err="Please enter a username.";
    }
    elseif(!preg_match('/^[a-zA-Z0-9_]+$/',trim($_POST["username"]))){
        $username_err="Full name can only contain letters, numbers and underscores.";
    }
    else{
       
        $sql="SELECT id from customers WHERE username =?";
        if($stmt=mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s",$param_username);
            $param_username=trim($_POST["username"]);
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt)==1){
                    $username_err="This username is already taken.";
                }else{
                    
                    //check the username to prevent name conflicts with the table names
                    if(strcmp(trim($_POST["username"]),"admins")==0 || strcmp(trim($_POST["username"]),"products")==0 || strcmp(trim($_POST["username"]),"orders")==0 || strcmp(trim($_POST["username"]),"customers")==0 ||
                    strcmp(trim($_POST["username"]),"one_notification")==0 || strcmp(trim($_POST["username"]),"all_notifications")==0 || strcmp(trim($_POST["username"]),"likes")==0 || strcmp(trim($_POST["username"]),"clicks")==0 || strcmp(trim($_POST["username"]),"subscription")==0
                    || strcmp(trim($_POST["username"]),"pre_orders")==0 ||strcmp(trim($_POST["username"]),"satisfied_customers")==0 ){
                        $username_err="This username is not permitted, try another username";
                    }else{
                        $username=trim($_POST["username"]);
                    }
                }
            }else{
                echo "<h3 class='text-danger'>Oops! Something went wrong. Please try again later.</h3>";
                
            }
        }mysqli_stmt_close($stmt);
    }
    if(empty(trim($_POST["email"]))){
        $email_err="Email is required.";
    }    
    elseif(filter_var($email, FILTER_VALIDATE_EMAIL)){
        $email_err="Please enter a valid email address.";
    }
    else{
        $qry="SELECT id FROM customers WHERE email=?;";
        if($stato=mysqli_prepare($conn, $qry)){
            mysqli_stmt_bind_param($stato, "s", $param_check_email);
            $param_check_email=trim($_POST['email']);
            
            if(mysqli_stmt_execute($stato)){
                mysqli_stmt_store_result($stato);
            
            if(mysqli_stmt_num_rows($stato)>0){
                $email_err="This email is already registered";
            }else{
                $email=trim($_POST["email"]);
            }
        }
        mysqli_stmt_close($stato);
        }
       
      
    }
    if(empty(trim($_POST["passkey"]))){
        $passkey_err="Please enter a password.";
    }elseif(strlen(trim($_POST["passkey"])) < 6){
        $passkey_err="Password must have atleast 6 characters.";
    }else{
        $passkey=trim($_POST["passkey"]);
    }

    if(empty(trim($_POST["confirm_passkey"]))){
        $confirm_passkey_err="Please confirm your password.";
    }else{
        $confirm_passkey=trim($_POST["confirm_passkey"]);
        if(empty($confirm_passkey_err) && ($passkey !=$confirm_passkey)){
            $confirm_passkey_err="Password didn't match.";
        }
    }

    $cart="0";
    $order="0";
 
    if(empty($username_err)&& empty($email_err)&&  empty($passkey_err)&& empty($confirm_passkey_err)){
        
        $sql="INSERT INTO customers(full_name, username, email, cart, order_table, passkey) VALUES(?,?,?,?,?,?)";
        if($stmt=mysqli_prepare($conn,$sql)){
            mysqli_stmt_bind_param($stmt, "ssssss",$param_full_name, $param_username, $param_email, $param_cart, $param_order, $param_passkey);
            $param_full_name=$full_name;
            $param_username=$username;
            $param_email=$email;
            $param_cart=$cart;
            $param_order=$order;
            $param_passkey=password_hash($passkey, PASSWORD_DEFAULT);

            if(mysqli_stmt_execute($stmt)){
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $id;
                $_SESSION["username"] = $username;

                header("location: home");
                
            }else{
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }

    }
    mysqli_close($conn);

}



?>











<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Register bicycle shop</title>
</head>
<body>
<?php
    include "customer_header.php";
    ?>

</br>
<div class="container">
    <p>Welcome to our bicycle shop. kindly fill the form below to register with us.</p>
</div>
<center>
<div class="container">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <legend class="text-danger" style="text-decoration:underline double;"><h2><i class="fas fa-r"></i>egister  <i class="fas fa-a"></i>ccount</h2></legend>
        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($full_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $full_name; ?>" id="full name" placeholder="Enter full name"  name="full_name">
            <label for="full name">full name</label>
            <span class="invalid-feedback"><?php echo $full_name_err; ?></span>
            </div>
        
        <div class="form-floating mb-3 mt-3">
            <input type="text" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>" id="username" placeholder="Enter username"  name="username">
            <label for="username">username</label>
            <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>" id="email" placeholder="Enter your email"  name="email">
            <label for="email">email</label>
            <span class="invalid-feedback"><?php echo $email_err; ?></span>
            </div>

        <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($passkey_err)) ? 'is-invalid' : ''; ?>" value="" id="security passkey" placeholder="Enter security passkey"  name="passkey">
            <label for="security passkey">Password</label>
            <span class="invalid-feedback"><?php echo $passkey_err; ?></span>
            </div>

            <div class="form-floating mb-3 mt-3">
            <input type="password" class="form-control <?php echo (!empty($confirm_passkey_err)) ? 'is-invalid' : ''; ?>" value="" id="security passkey" placeholder="Enter security passkey"  name="confirm_passkey">
            <label for="security passkey">confirm password</label>
            <span class="invalid-feedback"><?php echo $confirm_passkey_err; ?></span>
            </div>

            <p><small>already have an account? </small><a href="login.php">Login here</a></p>

            <input type="reset" class="btn btn-danger"  value="Cancel" style="margin-right: 50px;">
        <input type="submit" class="btn btn-primary" name="submit" value="Register">    
       </form> 

</div>

</center>


</br>
<?php include "footer.php" ?>
</body>
</html>