<?php
session_start();
require "piccsz.php";

$upload_messo=$delete_message=$counter=$stock_change_messo="";
if(isset($_SESSION['clicked_item_admin'])){

    if(isset($_POST['change_stock_value'])){
        $current_value=$_POST['current_value'];

        if($current_value=="sold out"){
            $input="in stock";
        }elseif($current_value=="in stock"){
            $input="sold out";
        }else{
            $input="";
        }

        // update
        $swali="UPDATE products SET stock='$input' WHERE unique_key=?";
        if($stat=mysqli_prepare($conn, $swali)){
            mysqli_stmt_bind_param($stat, "s", $param_ky);
            $param_ky=$_SESSION['clicked_item_admin'];
            if(mysqli_stmt_execute($stat)){
                $stock_change_messo="<div class='alert alert-success alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Success!</strong> Stock value changed
                </div>";
            }else{
                $stock_change_messo="<div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Failed!</strong> error occured, unable to change the stock value, try again later 
                </div>";

            }
            mysqli_stmt_close($stat);
        }
    }





    if(isset($_POST['delete_item'])){
    $sql="SELECT images FROM products WHERE unique_key=?";
    if($stmtt=mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmtt, "s", $param_ky);
        $param_ky=$_SESSION['clicked_item_admin'];
        if(mysqli_stmt_execute($stmtt)){
            mysqli_stmt_bind_result($stmtt, $param_path);
            mysqli_stmt_fetch($stmtt);
            $image_path=$param_path;
            mysqli_stmt_close($stmtt);
           
            //now delete
                if(!empty($image_path)){
                    unlink($image_path);
                    if(file_exists("add_images/".$_SESSION['clicked_item_admin'])){
                        $files=glob("add_images/".$_SESSION['clicked_item_admin']."/*");
                        foreach($files as $file){
                            if(is_file($file)){
                                unlink($file);
                            }
                        }
                        rmdir("add_images/".$_SESSION['clicked_item_admin']);
                    }

                    $sqll="DELETE FROM products WHERE unique_key=?";
                    if($stmt=mysqli_prepare($conn, $sqll)){
                    mysqli_stmt_bind_param($stmt, "s", $param_k);
                    $param_k=$_SESSION['clicked_item_admin'];
                    if(mysqli_stmt_execute($stmt)){
                        $delete_message="<div class='alert alert-success alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong>Deleted!</strong> the product is permanently removed
                        </div>";
                    }else{
                        $delete_message="<div class='alert alert-danger alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong>Error while deleting!</strong> unable to delete product records from the database
                    </div>";

                    }
            mysqli_stmt_close($stmt);
        }
                

            }else{
                $delete_message="<div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Error while deleting!</strong> unable to delete the product primary image
              </div>";

            }
        
        }
        
    }
}


    if(isset($_POST['upload_img'])){
        if (isset($_FILES['add_images']) && !empty($_FILES['add_images']['name'][0])) {
            $errors = array();

            for ($i = 0; $i < count($_FILES['add_images']['name']); $i++) {
                if (!is_uploaded_file($_FILES['add_images']['tmp_name'][$i])) {
                    $errors[] = "File not uploaded correctly. ";
                }

                $check = getimagesize($_FILES['add_images']['tmp_name'][$i]);
                if ($check === false) {
                    $errors[] = "File is not a valid image. ";
                }
                if ($_FILES['add_images']['size'][$i] > 10000000) {
                    $errors[] = "File size exceeds maximum limit of 10MB. ";
                }
                $fileType = strtolower(pathinfo($_FILES['add_images']['name'][$i], PATHINFO_EXTENSION));
                if ($fileType != "jpg" && $fileType != "png" && $fileType != "jpeg" && $fileType != "gif") {
                    $errors[] = "Invalid file type. ";
                }

               }

            if (count($errors) > 0) {
               $image_errr= implode (" ",$errors);
               $image_err="<div class='alert alert-danger alert-dismissible fade show'>
               <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
               <strong>Error(s)! </strong> ". $image_errr."
             </div>";  
              
            } else {

                $currentdir=getcwd();
                $folderpath = "add_images/".$_SESSION['clicked_item_admin'];
                if (!file_exists($folderpath)){
                if(mkdir($folderpath)){
                    //then upload images here
                foreach ($_FILES["add_images"]["tmp_name"] as $key => $tmp_name) {
                    $fileName = $_FILES["add_images"]["name"][$key];
                    $fileType = $_FILES["add_images"]["type"][$key];
                    $fileSize = $_FILES["add_images"]["size"][$key];
                    $fileError = $_FILES["add_images"]["error"][$key];
                    $fileTmpName = $_FILES["add_images"]["tmp_name"][$key];
                  
                    if ($fileError === 0) {
                      $fileDestination = $folderpath . "/" . $fileName;
                      move_uploaded_file($fileTmpName, $fileDestination);
                      $upload_messo= "<div class='alert alert-success alert-dismissible fade show'>
                      <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                      <strong>uploaded!</strong> image(s) have been uploaded successifully
                    </div>";
                    }else{
                        $upload_messo= "<div class='alert alert-danger alert-dismissible fade show'>
                        <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                        <strong>Error!</strong> an error occurred while uploading the image(s), try again
                      </div>";
                    }

                  }

                }
                
                  
                }else{
                    // just upload on the already existing folder
                    foreach ($_FILES["add_images"]["tmp_name"] as $key => $tmp_name) {
                        $fileName = $_FILES["add_images"]["name"][$key];
                        $fileType = $_FILES["add_images"]["type"][$key];
                        $fileSize = $_FILES["add_images"]["size"][$key];
                        $fileError = $_FILES["add_images"]["error"][$key];
                        $fileTmpName = $_FILES["add_images"]["tmp_name"][$key];
                      
                        if ($fileError === 0) {
                          $fileDestination = $folderpath . "/" . $fileName;
                          move_uploaded_file($fileTmpName, $fileDestination);
                          $upload_messo= "<div class='alert alert-success alert-dismissible fade show'>
                          <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                          <strong>uploaded!</strong> image(s) have been uploaded successifully
                        </div>";
                        }else{
                            $upload_messo= "<div class='alert alert-danger alert-dismissible fade show'>
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong>Error!</strong> an error occurred while uploading the image(s), try again
                          </div>";
                        }
    
                      }

                }


            }

        }
        else{
            $upload_messo= "<div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>No file selected!</strong> you have to selected image(s) to upload
          </div>";
        }
        
    }


if(file_exists("add_images/".$_SESSION['clicked_item_admin'])){
    $dir="add_images/".$_SESSION['clicked_item_admin'];
                            
    $corousel_img=glob($dir."/*" );
    $counter= count($corousel_img);

}else{
    $counter=0;
}

  
    

}else{
    $upload_messo= "<div class='alert alert-danger alert-dismissible fade show'>
                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                <strong>Item not found!</strong> this page was not accessed in a correct manner, kindly go back and try again
                </div>";
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Admin actions zbikes kenya</title>
    <style>
.action{
    border-radius: 20px;
    border-style: outset;
}
.buttons{
    display: flex;
    justify-content: space-around;
}
.files{
    display: flex;
    justify-content: space-between;
}
    </style>
    
</head>
<body>
    <?php include "admin_header.php"; ?>
<p>Choose the action to take on the selected product</p>
<div class="container">
<?php echo(!empty($upload_messo)? $upload_messo : ""); ?> 
<?php echo(!empty($stock_change_messo)? $stock_change_messo : ""); ?>
<?php echo(!empty($delete_message)? $delete_message : ""); ?>
</div>
    <div class="container ">
    <div class="action p-2" >
        <div class="files">
    <div><h4 class="text-success"><u>Add images to the item <i class="fas fa-image"></i></u></h4></div>
    <div><span class="bg-primary p-1 text-light" style="width: fit-content; border-radius:10px; font-size:x-small;">Total images attached: <b><?php echo (!empty($counter)? $counter: "" ); ?></b></span></div>
    </div>
    <form action="" method="POST" enctype="multipart/form-data">
        <div class="form-floating mb-3 mt-3">
            <input type="file" class="form-control <?php echo (!empty($image_err)) ? 'is-invalid' : ''; ?>" value="" id="file" placeholder="product image(s)"  name="add_images[]" multiple/>
            <label for="file">select image(s)</label>
            <span class="invalid-feedback"><?php echo $image_err; ?></span>
            </div>
        <center class="buttons">
            <input type="reset" value="Reset" class="btn btn-danger"/>
            <input type="submit" value="Upload" name="upload_img" class="btn btn-success"/>
        </center>
    </form>
    </div>
    </div>

</br>



<?Php
if(isset($_SESSION['clicked_item_admin'])){
    $qry="SELECT stock FROM products WHERE unique_key=?;";
    if($stato=mysqli_prepare($conn, $qry)){
        mysqli_stmt_bind_param($stato, "s", $param_k);
        $param_k=$_SESSION['clicked_item_admin'];
        if(mysqli_stmt_execute($stato)){
            mysqli_stmt_bind_result($stato, $param_stock);
            mysqli_stmt_fetch($stato);
            $stock_value=$param_stock;
        }
        mysqli_stmt_close($stato);
    }

}


?>

    <div class="container ">
    <div class="action p-2" >
    <h4 class="text-primary"><u>Change stock value (sold out or in stock)</u></h4>
    Change the Availability of this item either from <b>in stock</b> to <b>sold out</b> and vice versa
    <p>The current state is: <b><?php echo $stock_value; ?></b> </p>
    <form action="" method="POST">
        <input type="hidden" name="current_value" value="<?php echo $stock_value; ?>"/>
        <center class="buttons">
            <input type="submit" value="Change stock value" name="change_stock_value" class="btn btn-primary"/>
        </center>
    </form>
    </div>
    </div>

    </br>

    <div class="container ">
    <div class="action p-2" >
    <h4 class="text-danger"><u>Delete this item <i class="fas fa-trash-can"></i></u></h4>
    This action is not reversible, if you accidentally delete an item; then you will have to re-add it again the the <b>add products page</b>
    <form action="" method="POST">
        <center class="buttons">
            <input type="submit" value="Delete" name="delete_item" class="btn btn-danger"/>
        </center>
    </form>
    </div>
    </div>


</br>
<?php include "footer.php"; ?>
    
</body>
</html>