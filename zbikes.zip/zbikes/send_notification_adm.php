<?php
session_start();
require "piccsz.php";
$button_all= $button_one=$all_notice_messo_err=$all_notice_messo=$notify_err= $one_notice_messo= $one_notice_messo_err="";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
    if(isset($_POST['exit'])){
        $_SESSION = array();
        session_destroy();
        header("location: home");
        exit;
    }


//content  code here!!
if(isset($_POST['one_notify'])){
    $button_one="dis";
}
if(isset($_POST['all_notify'])){
    $button_all="dis";
}

if(isset($_POST['send_all_notify'])){
   $notice_all=$_POST['notification_all'];
   //insert in the db now
   $sql="SELECT id FROM all_notifications;";
   $resultr=mysqli_query($conn, $sql);
   if(mysqli_num_rows($resultr)>0){
       //update
       $sql="UPDATE all_notifications SET notification=? WHERE id='1'";
       if($stmt=mysqli_prepare($conn, $sql)){
        mysqli_stmt_bind_param($stmt, 's', $param_key);
        $param_key=$notice_all;
        if(mysqli_stmt_execute($stmt)){
            $all_notice_messo="<div class='alert alert-success alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong><i class='fas fa-circle-check'></i> Success!</strong> notification is sent to all customers.
          </div>";

            mysqli_stmt_close($stmt);
        }
        else{
            $all_notice_messo_err="<div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong><i class='fas fa-circle-xmark'></i> Error!</strong> Oops! could not send notification, try again later.
          </div>";
        }
       }
   }else{
       //insert
       $sql="INSERT INTO all_notifications(notification) VALUES(?)";
        
            if($stmtt=mysqli_prepare($conn, $sql)){
                mysqli_stmt_bind_param($stmtt,"s", $param_notice);
                    $param_notice=$notice_all;
                if(mysqli_stmt_execute($stmtt)){
                    $all_notice_messo="<div class='alert alert-success alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong><i class='fas fa-circle-check'></i> Success!</strong> notification is sent to all customers.
          </div>";

                    mysqli_stmt_close($stmtt);
                }
            }
            else{
                $all_notice_messo_err="<div class='alert alert-danger alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong><i class='fas fa-circle-xmark'></i> Error!</strong> Oops! could not send notification, try again later.
          </div>";
            }
   }


}

if(isset($_POST['send_one_notify'])){
    $notify_id=$_POST['id'];
    $notify_username=$_POST['username'];
    $notification=$_POST['notify_one_messo'];
    $notify_date=date("l jS \of F Y h:i:s A");
        $sql="SELECT id, username FROM customers WHERE id=? AND username=?";
        if($stmt=mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "ss", $param_id, $param_username);
            $param_id=$notify_id;
            $param_username=$notify_username;
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt)>0){
                    $sqll="SELECT id FROM one_notification WHERE customer_id=? AND username=?";
               if($stmtt=mysqli_prepare($conn, $sqll)){
                mysqli_stmt_bind_param($stmtt, "ss", $param_id, $param_username);
                $param_id=$notify_id;
                $param_username=$notify_username;
                if(mysqli_stmt_execute($stmtt)){
                    mysqli_stmt_store_result($stmtt);
                    if(mysqli_stmt_num_rows($stmtt)>0 ){
                       
                        $sqlll="UPDATE one_notification SET notification=?, date=?;";
                        if($stmttt=mysqli_prepare($conn, $sqlll)){
                        mysqli_stmt_bind_param($stmttt, "ss", $param_notification, $param_date);
                        $param_notification=$notification;
                        $param_date=$notify_date;
                        if(mysqli_stmt_execute($stmttt)){
                            $one_notice_messo="<div class='alert alert-success alert-dismissible fade show'>
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong><i class='fas fa-circle-check'></i> Success!</strong> notification is sent to all customers.
                          </div>";

                        }else{
                            $one_notice_messo_err="<div class='alert alert-danger alert-dismissible fade show'>
                                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                                <strong><i class='fas fa-circle-xmark'></i> Error!</strong> Oops! could not send notification to the customer, try again later.
                            </div>";
                        }
                        mysqli_stmt_close($stmttt);
                    }

                    }else{
                        $sql="INSERT INTO one_notification (username, customer_id, notification, date) VALUES(?,?,?,?);";
                        if($stmtt=mysqli_prepare($conn, $sql)){
                        mysqli_stmt_bind_param($stmtt,"ssss", $param_name, $param_id, $param_notification, $param_date);
                        $param_name=$notify_username;
                        $param_id=$notify_id;
                        $param_notification=$notification;
                        $param_date=$notify_date;
                        if(mysqli_stmt_execute($stmtt)){
                            $one_notice_messo="<div class='alert alert-success alert-dismissible fade show'>
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong><i class='fas fa-circle-check'></i> Success!</strong> notification is sent to all customers.
                          </div>";
                            

                        }else{
                            $one_notice_messo_err="<div class='alert alert-danger alert-dismissible fade show'>
                                <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                                <strong><i class='fas fa-circle-xmark'></i> Error!</strong> Oops! could not send notification to the customer, try again later.
                            </div>";

                        }

                        }
                    }
                }
               mysqli_stmt_close($stmtt);
            }

                }else{
                    $notify_err="<div class='alert alert-danger alert-dismissible fade show'>
                    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                    <strong><i class='fas fa-circle-xmark'></i> Error!</strong> incorrect input, either the username and id are not correct, please check and try again.
                  </div>";
                }
            }
            mysqli_stmt_close($stmt);
        }



}

}else{
    header("location:  admin_login");
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>Send notifications Zbikes KE</title>
</head>
<body>
<?php
    include "admin_header.php";
    ?>
    </br>
    <center>
    <div class="container">
        <h2 class="text-danger"><b><u>Send notification</u></b></h2>
    </div>
    </center>
    <p>Notify your customers of any current changes or available offers</p>
    <div class="container">
        <?php echo(!empty($all_notice_messo)? $all_notice_messo : '');?>
        <?php echo(!empty($all_notice_messo_err)? $all_notice_messo_err : '');?>
        <?php echo(!empty($notify_err)? $notify_err : '');?>
        <?php echo(!empty($one_notice_messo)? $one_notice_messo : '');?>
        <?php echo(!empty($one_notice_messo_err)? $one_notice_messo_err : '');?>

    </div>
    
<div class="container">
    <div class="row g-3">
    <div class="col-12 col-md-6 col-lg-6 ">
            <div class="box h-100 d-flex flex-column rounded border border-grey "  style="background-image: linear-gradient(to right, yellow, gray);">
                
                <div class="p-2">
                    <h4 class="card-title">Notify all Customers</h4>
                    <p class="card-text">
                      All customers will receive the notification that you will post.
                       <p>Click <span class="text-danger">continue</span> to prepare and post the notification.</p>
                       <div class=" pb-3">
                       <form method="POST" action="">
                        <input type="submit" value="Continue" name="all_notify" class="btn btn-primary <?php echo(!empty($button_all)? 'd-none':'');?>"/>
                       </form>
                       <?php 
                       if(isset($_POST['all_notify'])){
                        $button_all="dis";
                        echo "
                        <form method='POST' action=''>
                        <div class='form-group mb-3 mt-3'>
                         <textarea  rows='3'  class='form-control' value='' id='username' placeholder='Enter the notification message'  name='notification_all'></textarea>
                         <span class='invalid-feedback'></span>
                         </div>
                         <input type='submit' name='send_all_notify' value='Send now' class='btn btn-primary'/>
                         </form>
                         ";
                     }
                       ?>
                       </div>
                    </p>
                </div>
                    

                </div>
            </div>

            <div class="col-12 col-md-6 col-lg-6 ">
            <div class="box h-100 d-flex flex-column rounded border border-grey " style="background-image: linear-gradient(to right, gray, white);" >
                
                <div class="p-2">
                    <h4 class="card-title">Notify only one choosen customer</h4>
                    <div class="card-text">
                        only the customer that you choose with a given username will receive the notification                       
                        <p>Click <span class="text-danger">continue</span> to start</p>
                        <div class="mt-auto pb-3">
                       <form method="POST" action="">
                        <input type="submit" value="Continue" name="one_notify" class="btn btn-danger <?php echo(!empty($button_one)? 'd-none':'');?>"/>
                       </form>

                       <?php 
                       if(isset($_POST['one_notify'])){
                           $button_one="dis";
                        echo "
                        <div class='bg-warning p-2 rounded'>
                        visit the customer accounts page to see the serial no and username of customers you want to send notification
                        <a href='customer_accounts' style='font-size:x-small' class='btn btn-success btn-sm'>Customer accounts</a> 
                        </div>
                        <form method='POST' action=''>
                        <input type='text' name='id' placeholder='serial no. of customer' pattern='[0-9]' required/>
                        <input type='text' name='username' placeholder='username of customer' required/>
                        <div class='form-group mb-3 mt-3'>
                         <textarea  rows='3'  class='form-control' value='' id='username' placeholder='Enter the notification message'  name='notify_one_messo' required></textarea>
                         
                         </div>
                         <input type='submit' name='send_one_notify' value='Send now' class='btn btn-danger'/>
                         </form>
                         ";
                     }
                       ?>
                       </div>
                    </div>
                </div>
                    

                </div>
            </div>
    </div>
</div>


</br>
<?php
include "footer.php";
?>  
    
</body>
</html>