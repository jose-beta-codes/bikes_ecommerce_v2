<?php
session_start();
require "piccsz.php";
$login_err="";
if($_SESSION["loggedinadmn"]== true && $_SESSION["idadmn"]=="2_5_4"){
  if(isset($_POST['exit'])){
      $_SESSION = array();
      session_destroy();
      header("location: admin_login");
      exit;
  }


}else{
  header("location:  admin_login");
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>stock manager Zbikes KE</title>
</head>
<body>
    <?php include "admin_header.php" ?>
<center>
    <div class="container">
        <h2 class="text-primary"><u><b>My Stock </b></u></h2>
</br>
<?php
if(isset($_SESSION["loggedinadmn"]) && !empty($_SESSION["idadmn"])){
  $login_err="true";


}else{
    echo "<center>
    <div class='container' style='width:70% ;'>
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login!</strong> login here see your account details and have a personalised experience  <a href='login.php' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
    </div>
</center>";
}
?>
    </div>

</center>

<div class="container">
        <div class="row gy-3">


        <div class="col-lg-6 col-md-6 col-12 ">
            <div class="box h-100 d-flex p-3 flex-column rounded" style="background-color: rgba(103, 100, 100, 0.274);">
              <!-- <img src="..\zbikess\pics\zbikess.ke-20220811-0077.jpg" alt="image test" > -->
              <h4 class="text-danger"><u>All Items</u></h4>
            <p>Here you get to see either all the items that you have added to the e-shop or you select the 'items out of stock' option  to see items that are bought out. </p>
            <p>Item delection is also supported in 'All items' option.</p>
              <div class="mt-auto">
                <span style="float:left; padding-left:10px;"><a href="all_items" class="btn btn-danger rounded-pill mt-auto <?php echo(!empty($login_err)? '': 'disabled'); ?>" >All items</a></span>
                <span style="float:right; padding-right:10px;"><a href="out_stock" class="btn btn-primary rounded-pill mt-auto <?php echo(!empty($login_err)? '': 'disabled'); ?>" style="float:left">Items out of stock</a></span>
              </div>

            </div>
          </div>
          
          <div class="col-lg-6 col-md-6 col-12">
            <div class="box h-100 d-flex p-3 flex-column rounded" style="background-color:gold;">
              <h4><u>Search Items</u> <i class="fab fa-searchengin"></i></h4>
              <p>You have all the control! you can search for the products with certain feature to see how many are added to the e-shop, this will help to reduce under-adding items. Read the <a href="user_guide.php">User Guide</a></p>

              <div class="mt-auto">
              <center>
                <span style=" padding-left:10px;"><a href="search" class="btn btn-success rounded-pill mt-auto <?php echo(!empty($login_err)? '': 'disabled'); ?>" >Search items</a></span>
                </center>
              </div>


            </div>
          </div>

        </div>
</div>

</br>
<?php include "footer.php" ?>
</body>
</html>