<?php
require_once "envtext.php";
$servername=$_ENV['DB_HOST'];
$dbusername=$_ENV['DB_USERNAME'];
$dbpassword=$_ENV['DB_PASSWORD'];
$dbname=$_ENV['DB_NAME'];

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE password_reset(
    id INT(255) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    email VARCHAR(255) NOT NULL,
   reset_key VARCHAR(255) NOT NULL,
    time_generated VARCHAR(255) NOT NULL,
    expirely_date VARCHAR(50) NOT NULL);";

if(mysqli_query($conn, $sql)){
    echo "Table zbikes password reset successifully created!";
}
else{
    die ("Error creating table bana! ");
}