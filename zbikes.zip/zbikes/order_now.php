<?php
session_start();
require "piccsz.php";

$login_err = $full_name = $location = $order_now_err = $availability_messo=$availability_err="";

if (isset($_SESSION["loggedin"]) && isset($_SESSION["username"])) {


    if (isset($_SESSION['clicked_item_order_now']) && $_SESSION['page']=="1") {
        $item_key = $_SESSION['clicked_item_order_now'];
        $quantity = $_SESSION['clicked_item_quantity_order_now'];

        unset($_SESSION['clicked_item_order_now_cart']);
        unset($_SESSION['clicked_item_quantity_order_now_cart']);
        unset($_SESSION['page']);

    }

        if(isset($_SESSION['clicked_item_order_now_cart']) && $_SESSION['page']=="2"){
            $item_key = $_SESSION['clicked_item_order_now_cart'];
            $quantity = $_SESSION['clicked_item_quantity_order_now_cart'];

            unset($_SESSION['clicked_item_order_now']);
            unset($_SESSION['clicked_item_quantity_order_now']);
            unset($_SESSION['page']);
        }


        // check availability of the item
        $sql="SELECT stock FROM products WHERE unique_key=?";
        if($stmt=mysqli_prepare($conn, $sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_k);
            $param_k=$item_key;
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_bind_result($stmt, $param_st);
                mysqli_stmt_fetch($stmt);
                $availability=$param_st;
                if($availability=="sold out"){
                    $availability_err="out of stock";
                    $availability_messo= "<center>
                            <div class='container' style='width:95% ;'>
                            <div class='alert alert-danger alert-dismissible fade show'>
                            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                            <strong>Item is Sold out!</strong> go back and select a similar item that is not sold out already <a href='home' class='alert-link'><button class='btn btn-danger rounded-pill'>home page</button></a>
                        </div>
                            </div>
                        </center>";
                }else{
                }
            }mysqli_stmt_close($stmt);

        }

        


        $sql = "SELECT product_name, images, unique_key, key_features, description, product_condition, bike_color, price, stock, bike_size, product_weight FROM products WHERE unique_key='$item_key' ORDER BY id DESC LIMIT 1;";
        $result = mysqli_query($conn, $sql);
        $rows = mysqli_num_rows($result);

        if ($rows > 0) {
            $row = mysqli_fetch_assoc($result);
            $name = $row['product_name'];
            $image = $row['images'];
            $unique_key = $row['unique_key'];
            $size = $row['bike_size'];
            $color = $row['bike_color'];
        } else {
            $order_now_err = "The selected item do not exist in our shop, kindly try another item.";
        }

        // unset($_SESSION['clicked_item_order_now_cart']);
        // unset($_SESSION['clicked_item_quantity_order_now_cart']);

        // unset($_SESSION['clicked_item_order_now']);
        // unset($_SESSION['clicked_item_quantity_order_now']);
    


    if (isset($_POST['personal_details'])) {
        $full_name = $_POST['full_name'];
        $location = $_POST['location'];
        $item_key = $_POST['item_key'];
        $quantity = $_POST['quantity'];
      
        $_SESSION['final_order_step_fullname']=$full_name;
        $_SESSION['final_order_step_location']=$location;
        $_SESSION['final_order_step_itemkey']=$item_key;
        $_SESSION['final_order_step_quantity']=$quantity;

        

        header("location: complete_order");



    }



} else {
    $login_err = "<center>
    <div class='container' style='width:95%;'>
    <div class='alert alert-primary alert-dismissible fade show'>
    <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
    <strong>Login! <i class='fas fa-cart-arrow-down'></i></strong> login here to continue with your order  <a href='login' class='alert-link'><button class='btn btn-danger rounded-pill'>Login here</button></a>
  </div>
    </div>
</center>";
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon" />
    <title>Order now bicycle shop KENYA</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <style>
    .flex-container {
  display: flex;
  flex-direction: column;
  margin-left: 8px;
margin-right: 8px;

  justify-content: center;
  align-items: center;
}

    </style>
</head>

<body>
    <?php include "customer_header.php" ?>
<div class="container mt-2">
    <?php echo (!empty($login_err) ? $login_err : ""); ?>
    <?php echo (!empty($availability_messo) ? $availability_messo : ""); ?>
    </div>
    <div class="container">
        <center>
            <h2 style="text-decoration: underline ;" class="text-danger"><b>Order now</b></h2>
        </center>
        <p style="font-size:smaller;">Our buyers are protected by guaranteeing the delivery of item ordered in time and exactly as they were described. </p>
    </div>

<div class="container">
    <div  style="border-radius: 20px; border-style: solid; border-color:grey; padding:10px; margin:10px;">
        <div class="flex-container">
            <?php
            if (isset($_SESSION["loggedin"]) && isset($_SESSION["username"])) {
                if (isset($_SESSION['clicked_item_order_now']) || isset($_SESSION['clicked_item_order_now_cart'])) {

        echo "<div class='card' style='max-width: 400px;'>
        <div class='row g-0'>
            <div class='col-5'>
                <img src='$image' class='card-img-top h-100' alt='bike image kenya Mombasa' style='object-fit:fill;'>
            </div>
            <div class='col-7' style='background: rgba(150, 141, 141, 0.301);'>
                <div class='card-body'>
                    <center><h5 class='card-title' style='margin:0;padding:0;'>$name</h5></center>
                    <small style=' margin:0 ;padding:0;'><b>Size: </b>$size inches </small></br>
                    <small><b>Colour: </b> $color</small></br>
                    <small style=' margin:0 ;padding:0;'><b>no. of pieces:  </b>$quantity</small>

                </div>
            </div>
        </div>
    </div>";
                }
            }

            ?>

        </div>
   
    <center>
       
            <form method="POST" action="">
                <div class="form-floating mb-3 mt-3">
                    <fieldset class="text-grey">
                        <legend style="margin-top:-15px;">Order details- <small><b>Step: </b>1/2</small></legend>
                        <input type="text" class="form-control" value="<?php echo $full_name; ?>" placeholder="Enter your full name" name="full_name" required />
                </div>

                

                <div class=" mb-3 mt-3">
                    <input type="text" class="form-control" value="<?php echo $location; ?>" required id="location" placeholder="Enter your nearest fargo courier branch location" name="location">
                </div>


                <input type="hidden" name="item_key" value="<?php echo ( $unique_key); ?>" />
                <input type="hidden" name="quantity" value="<?php echo ($quantity); ?>" />

                Click here to see fargo courier branches: <a href="https://www.fargocourier.co.ke/branches">FARGO COURIER BRANCHES</a></br></br>

                <input type="reset" value="Cancel" class="btn btn-danger mx-5 <?php echo (!empty($login_err) || !empty($availability_err) ? "disabled" : ""); ?>" />
                <input type="submit" name="personal_details" class="btn btn-success <?php echo (!empty($login_err) || !empty($availability_err) ? "disabled" : ""); ?>" />
                </fieldset>
            </form>
        
    </center>


    </div>
    </div>

    </br>
    <?php include "footer.php" ?>
</body>

</html>