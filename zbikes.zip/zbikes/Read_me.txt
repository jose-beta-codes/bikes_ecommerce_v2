Tables to create first:
        admins
        products
        orders
        customers
        one_notification
        all_notifications
        likes
        clicks
        subscription
        pre_orders
        satisfied_customers

        [users carts: names usernames]


CAUTION:
        perform a check to prevent users from creating usernames that resemble the table names...
        PREVENT THIS CONFLICT|||||::::SOLVED

BUG:
	when ordering , if i go back without paying and select another product which i then buy, the system
	still retain the product key of the earlier item...unset the variables at the last step to avoid 
	this drag of values in session |||||::::BUG NOT FOUND AGAIN


CONFIGURATION DB DETAILS: 
	<?php
	$servername="sbg108.truehost.cloud";
	$dbusername="fastqash_zbikes_jose";
	$dbpassword="Josemaish2#";
	$dbname="fastqash_zbikes";

	$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
	if($conn==false){
    	die("Error: can not connect bana; ".mysqli_connect_error());
	}
	?>


FINALISING THE PROJECT: 
	make sure u temporarily mute the subscription feature there
	when a product is marked "sold out" then no one else should be able to order it
	the on recommended area when a product is clicked, recommended items shud be close to the item in debate, else return random items
	check email fuctions && if possible add email features for marketing.
	when a user signs in, they will receive an email of welcome together marketing some products , if possible attach pictures