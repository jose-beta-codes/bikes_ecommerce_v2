<?php
session_start();
require "piccsz.php";
$notification_one=$notification_all="";

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="logo.jpg" type="image/x-icon"/>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script> -->
    <link rel="stylesheet" href="bootstrap/css/all.css">
    <link rel="stylesheet" href="bootstrap/bootstrap.min.css">
    <title>offers and notification bicycle shop kenya </title>
</head>
<body>
    <?php
   include "customer_header.php";
?>
<center>
<div class="container">
    <h2 style="color:orange;"><u><b><i class="fas fa-star-half" style="color:orange;"></i>Offers and Notifications</b></u></h2>
</div>
</center>
<div class="container">
    <p><i class="fas fa-paper-plane" style="color:red;"></i><b>Notifications</b></p>
    <!-- check for notifications start with the private ones then public once -->
    <?php
    if(isset($_SESSION["loggedin"]) && isset($_SESSION["username"])){
        //private
        $sql="SELECT notification FROM one_notification WHERE username='$_SESSION[username]';";
        $results=mysqli_query($conn, $sql);
        if(mysqli_num_rows($results)>0){
            $data=mysqli_fetch_assoc($results);
            $notification_one1=$data['notification'];
            $notification_one="
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>New notification for you!</strong> $notification_one1
          </div>
              ";

              $sql="SELECT notification FROM all_notifications;";
              $resultz=mysqli_query($conn, $sql);
              if(mysqli_num_rows($resultz)>0){
                  $data=mysqli_fetch_assoc($resultz);
                  $notification_all1=$data['notification'];
                  $notification_all="<div class='alert alert-primary alert-dismissible fade show'>
                  <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
                  <p><strong>New notification for you!</strong> $notification_all1</p>
                </div>";
              }

        }else{
            $notification_one="
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>No notification!</strong> could not find any notification specially dedicated to you yet, check later.
          </div>";

          $sql="SELECT notification FROM all_notifications;";
          $resultz=mysqli_query($conn, $sql);
          if(mysqli_num_rows($resultz)>0){
              $data=mysqli_fetch_assoc($resultz);
              $notification_all1=$data['notification'];
              $notification_all="<div class='alert alert-primary alert-dismissible fade show'>
              <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
              <strong>New notification for you!</strong> $notification_all1
            </div>";
          }

        }

    }else{
        //public
        $sql="SELECT notification FROM all_notifications;";
        $resultz=mysqli_query($conn, $sql);
        if(mysqli_num_rows($resultz)>0){
            $data=mysqli_fetch_assoc($resultz);
            $notification_all1=$data['notification'];
            $notification_all="<div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>New notification for you!</strong> $notification_all1
          </div>";
        }else{
            $notification_all="
            <div class='alert alert-primary alert-dismissible fade show'>
            <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
            <strong>No notification found!</strong> come back later.
          </div>";

        }

    }

    echo(!empty($notification_one)? $notification_one: '');
    echo(!empty($notification_all)? $notification_all: '');

    ?>

</div>
</br>
<div class="container-fluid " style="background-image: linear-gradient(to right, dodgerblue, gray);">
    <h6 style="color:black;">Special offers <i class="fas fa-cart-shopping" style="color:red;"></i></h6>
</div>
  </br>
  <div class="container">
  <center>
      <div class='container' style='width:85%;'>
      <div class='alert alert-primary alert-dismissible fade show'>
      <button type='button' class='btn-close' data-bs-dismiss='alert'></button>
      <strong>No offers at the moment! </strong> come back later.
      </div>
      </div>
  </center>
  </div>


</br>
<?php
include "footer.php";
?>
    
</body>
</html>